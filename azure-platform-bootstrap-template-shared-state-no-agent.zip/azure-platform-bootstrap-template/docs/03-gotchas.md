# Gotchas

## 1. The bootstrap deadlock is solved by creating the self-hosted agent early

The IT-managed self-hosted agent VM is created in `platform_bootstrap`, before the Databricks workspaces exist.
That lets the first Databricks `foundation` pipeline run from the self-hosted agent.
Afterward, `agent_runtime` adds the VNet peerings and DNS links that give the same agent private-path access to the workspaces.

## 2. Azure DevOps PAT storage

The PAT used to register the self-hosted agent is sensitive. Do not hard-code it into committed Terraform variables.
For a quick sandbox you can pass it once through local tfvars, but the better pattern is to store it in Key Vault and rotate it after bootstrap.

## 3. Microsoft Entra permissions

Creating app registrations and service principals is an Entra operation, not just an Azure subscription operation.
Being Owner on the subscription alone may not be enough in a locked-down enterprise tenant.

## 4. Role-assignment propagation delay

RBAC assignments in Azure and Key Vault can take time to become effective.
That is why the bootstrap root includes a short wait before writing secrets, and the VM bootstrap script retries Key Vault reads.
If your tenant is slow, the first apply may still need a second run.

## 5. Self-hosted agent outbound internet

The VM needs outbound connectivity to Azure DevOps and package/download sources.
For a dev sandbox, coordinate any public IP or private access pattern with the IT-owned agent VM configuration.
For production, prefer controlled egress through NAT Gateway, Azure Firewall, or another central egress path.

## 6. Non-transitive peering

Azure VNet peering is not transitive.
Even if the Databricks hub is peered to the spokes, your agent VNet does not automatically gain spoke access through the hub.
That is why this repo optionally creates direct agent-to-spoke peerings.

## 7. Key Vault private networking

If you later make Key Vault private-only, make sure your self-hosted agent VNet has the required DNS and network path. Do not assume Azure DevOps cloud-side features like Key Vault-linked variable groups will still work in that model.
