# Local edits made for shared Terraform state and IT-managed agent VM

## State backend

- The backend storage account is now treated as pre-existing infrastructure.
- Shared state storage account:
  - Resource group: `rg-tdp-shared-tfstate`
  - Storage account: `sttdpterraformstate`
- Existing containers used:
  - `tfstate-dev`
  - `tfstate-qa`
  - `tfstate-prod`
- Backend keys are unique blob paths such as `platform-bootstrap/dev.tfstate`.

## Agent VM

- Removed Terraform management of the self-hosted Azure DevOps agent VM.
- Removed the `modules/azure/self_hosted_agent_vm` module from this archive.
- Removed the `module "self_hosted_agent_vm"` block from `roots/platform_bootstrap`.
- Removed the `self_hosted_agent` variable and sample tfvars blocks.
- Kept the agent network resources and outputs. If IT also owns the VNet/subnet, convert those to `data` lookups separately.
