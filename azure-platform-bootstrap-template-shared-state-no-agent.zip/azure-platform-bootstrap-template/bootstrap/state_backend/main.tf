data "azurerm_resource_group" "this" {
  name = var.resource_group_name
}

data "azurerm_storage_account" "this" {
  name                = var.storage_account_name
  resource_group_name = data.azurerm_resource_group.this.name
}

# The storage account and containers are intentionally pre-existing.
# This module only validates the shared state account can be read and returns
# backend values for the real root modules.
