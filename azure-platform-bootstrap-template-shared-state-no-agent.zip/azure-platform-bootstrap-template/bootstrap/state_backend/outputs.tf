output "resource_group_name" {
  value = data.azurerm_resource_group.this.name
}

output "storage_account_name" {
  value = data.azurerm_storage_account.this.name
}

output "storage_account_id" {
  value = data.azurerm_storage_account.this.id
}

output "container_names" {
  value = sort(tolist(var.container_names))
}

output "backend_examples" {
  value = {
    for name in var.container_names : name => {
      resource_group_name  = data.azurerm_resource_group.this.name
      storage_account_name = data.azurerm_storage_account.this.name
      container_name       = name
      use_azuread_auth     = true
    }
  }
}
