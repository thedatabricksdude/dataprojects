variable "subscription_id" {
  description = "Optional subscription ID. Leave null to use the current Azure CLI context."
  type        = string
  default     = null
}

variable "location" {
  description = "Azure region retained for compatibility. The state storage account is pre-existing and is not created here."
  type        = string
}

variable "resource_group_name" {
  description = "Existing resource group containing the shared Terraform state storage account."
  type        = string
}

variable "storage_account_name" {
  description = "Existing shared Terraform state storage account name."
  type        = string
}

variable "container_names" {
  description = "Existing blob containers used for Terraform state. They are validated/returned, not created."
  type        = set(string)
}

variable "allow_public_network_access" {
  description = "Retained for backwards-compatible tfvars files. This module no longer changes storage account network settings."
  type        = bool
  default     = true
}

variable "tags" {
  description = "Common tags."
  type        = map(string)
  default     = {}
}
