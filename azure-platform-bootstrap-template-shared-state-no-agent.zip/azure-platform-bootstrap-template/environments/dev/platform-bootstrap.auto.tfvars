platform_name = "dbxlab"
environment   = "dev"
location      = "westus2"

state_backend = {
  resource_group_name  = "rg-tdp-shared-tfstate"
  storage_account_name = "sttdpterraformstate"
}

resource_groups = {
  shared_services = "rg-dbxlab-shared-dev"
  hub_network     = "rg-dbxlab-hub-dev"
  web_auth        = "rg-dbxlab-webauth-dev"
  agent           = "rg-dbxlab-agent-dev"
  workspaces = {
    analytics = "rg-dbxlab-analytics-dev"
  }
}

key_vault = {
  name                          = "kv-dbxlab-dev"
  sku_name                      = "standard"
  public_network_access_enabled = true
  purge_protection_enabled      = true
}

deployment_identity = {
  display_name           = "spn-dbxlab-dev-terraform"
  password_rotation_days = 180
}

agent_network = {
  vnet_name         = "vnet-dbxlab-agent-dev"
  address_space     = ["10.10.0.0/24"]
  subnet_name       = "snet-ado-agent"
  subnet_prefixes   = ["10.10.0.0/26"]
  allowed_ssh_cidrs = ["203.0.113.10/32"]
}

# The self-hosted Azure DevOps agent VM is created and managed by IT.
# This bootstrap package no longer creates or controls that VM.

key_vault_secret_names = {
  arm_client_id          = "arm-client-id"
  arm_client_secret      = "arm-client-secret"
  arm_tenant_id          = "arm-tenant-id"
  arm_subscription_id    = "arm-subscription-id"
  databricks_account_id  = "databricks-account-id"
}

databricks_account_id = null

tags = {
  environment = "dev"
  owner       = "your-name"
  cost_center = "sandbox"
}
