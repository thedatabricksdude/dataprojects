location            = "westus2"
resource_group_name = "rg-tdp-shared-tfstate"
storage_account_name = "sttdpterraformstate"
container_names = [
  "tfstate-dev",
  "tfstate-qa",
  "tfstate-prod",
]
allow_public_network_access = true

tags = {
  managed_by = "terraform"
  purpose    = "remote-state-reference"
}
