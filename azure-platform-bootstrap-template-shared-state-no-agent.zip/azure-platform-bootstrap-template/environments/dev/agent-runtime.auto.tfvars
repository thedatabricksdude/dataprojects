location    = "westus2"
environment = "dev"

platform_bootstrap_remote_state = {
  resource_group_name  = "rg-tdp-shared-tfstate"
  storage_account_name = "sttdpterraformstate"
  container_name       = "tfstate-dev"
  key                  = "platform-bootstrap/dev.tfstate"
}

databricks_foundation_remote_state = {
  resource_group_name  = "rg-tdp-shared-tfstate"
  storage_account_name = "sttdpterraformstate"
  container_name       = "tfstate-dev"
  key                  = "foundation/dev.tfstate"
}

create_spoke_peerings = true

tags = {
  environment = "dev"
  owner       = "your-name"
  cost_center = "sandbox"
}
