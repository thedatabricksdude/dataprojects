resource_group_name  = "rg-tdp-shared-tfstate"
storage_account_name = "sttdpterraformstate"
container_name       = "tfstate-qa"
key                  = "agent-runtime/qa.tfstate"
use_azuread_auth     = true
