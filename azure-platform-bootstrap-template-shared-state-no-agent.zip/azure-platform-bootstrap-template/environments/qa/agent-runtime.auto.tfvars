location    = "westus2"
environment = "qa"

platform_bootstrap_remote_state = {
  resource_group_name  = "rg-tdp-shared-tfstate"
  storage_account_name = "sttdpterraformstate"
  container_name       = "tfstate-qa"
  key                  = "platform-bootstrap/qa.tfstate"
}

databricks_foundation_remote_state = {
  resource_group_name  = "rg-tdp-shared-tfstate"
  storage_account_name = "sttdpterraformstate"
  container_name       = "tfstate-qa"
  key                  = "foundation/qa.tfstate"
}

create_spoke_peerings = true

tags = {
  environment = "qa"
  owner       = "your-name"
  cost_center = "sandbox"
}
