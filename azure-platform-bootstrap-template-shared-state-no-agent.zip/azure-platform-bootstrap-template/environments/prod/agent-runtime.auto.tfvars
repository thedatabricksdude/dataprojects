location    = "westus2"
environment = "prod"

platform_bootstrap_remote_state = {
  resource_group_name  = "rg-tdp-shared-tfstate"
  storage_account_name = "sttdpterraformstate"
  container_name       = "tfstate-prod"
  key                  = "platform-bootstrap/prod.tfstate"
}

databricks_foundation_remote_state = {
  resource_group_name  = "rg-tdp-shared-tfstate"
  storage_account_name = "sttdpterraformstate"
  container_name       = "tfstate-prod"
  key                  = "foundation/prod.tfstate"
}

create_spoke_peerings = true

tags = {
  environment = "prod"
  owner       = "your-name"
  cost_center = "sandbox"
}
