resource_group_name  = "rg-tdp-shared-tfstate"
storage_account_name = "sttdpterraformstate"
container_name       = "tfstate-prod"
key                  = "platform-bootstrap/prod.tfstate"
use_azuread_auth     = true
