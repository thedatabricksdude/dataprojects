resource_group_name  = "rg-tdp-shared-tfstate"
storage_account_name = "sttdpterraformstate"
container_name       = "tfstate-prod"
key                  = "agent-runtime/prod.tfstate"
use_azuread_auth     = true
