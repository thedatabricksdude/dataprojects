resource "azurerm_resource_group" "this" {
  for_each = local.resource_group_names

  name     = each.value
  location = var.location
  tags     = local.common_tags
}

resource "azurerm_virtual_network" "agent" {
  name                = var.agent_network.vnet_name
  address_space       = var.agent_network.address_space
  location            = var.location
  resource_group_name = azurerm_resource_group.this["agent"].name
  tags                = local.common_tags
}

resource "azurerm_subnet" "agent" {
  name                 = var.agent_network.subnet_name
  resource_group_name  = azurerm_resource_group.this["agent"].name
  virtual_network_name = azurerm_virtual_network.agent.name
  address_prefixes     = var.agent_network.subnet_prefixes
}

resource "azurerm_key_vault" "platform" {
  name                          = var.key_vault.name
  location                      = var.location
  resource_group_name           = azurerm_resource_group.this["shared_services"].name
  tenant_id                     = local.effective_tenant_id
  sku_name                      = var.key_vault.sku_name
  purge_protection_enabled      = var.key_vault.purge_protection_enabled
  public_network_access_enabled = var.key_vault.public_network_access_enabled
  soft_delete_retention_days    = 90
  enable_rbac_authorization     = true
  tags                          = local.common_tags
}

module "deployment_identity" {
  source = "../../modules/azure/deployment_identity"

  display_name           = var.deployment_identity.display_name
  password_rotation_days = try(var.deployment_identity.password_rotation_days, 180)
}

resource "azurerm_role_assignment" "current_user_key_vault_admin" {
  scope                = azurerm_key_vault.platform.id
  role_definition_name = "Key Vault Administrator"
  principal_id         = data.azurerm_client_config.current.object_id
}

resource "time_sleep" "key_vault_rbac_propagation" {
  depends_on      = [azurerm_role_assignment.current_user_key_vault_admin]
  create_duration = "30s"
}

resource "azurerm_key_vault_secret" "arm_client_id" {
  name         = var.key_vault_secret_names.arm_client_id
  value        = module.deployment_identity.application_id
  key_vault_id = azurerm_key_vault.platform.id
  depends_on   = [time_sleep.key_vault_rbac_propagation]
}

resource "azurerm_key_vault_secret" "arm_client_secret" {
  name         = var.key_vault_secret_names.arm_client_secret
  value        = module.deployment_identity.client_secret
  key_vault_id = azurerm_key_vault.platform.id
  depends_on   = [time_sleep.key_vault_rbac_propagation]
}

resource "azurerm_key_vault_secret" "arm_tenant_id" {
  name         = var.key_vault_secret_names.arm_tenant_id
  value        = local.effective_tenant_id
  key_vault_id = azurerm_key_vault.platform.id
  depends_on   = [time_sleep.key_vault_rbac_propagation]
}

resource "azurerm_key_vault_secret" "arm_subscription_id" {
  name         = var.key_vault_secret_names.arm_subscription_id
  value        = local.effective_subscription_id
  key_vault_id = azurerm_key_vault.platform.id
  depends_on   = [time_sleep.key_vault_rbac_propagation]
}

resource "azurerm_key_vault_secret" "databricks_account_id" {
  count        = var.databricks_account_id == null ? 0 : 1
  name         = var.key_vault_secret_names.databricks_account_id
  value        = var.databricks_account_id
  key_vault_id = azurerm_key_vault.platform.id
  depends_on   = [time_sleep.key_vault_rbac_propagation]
}


resource "azurerm_role_assignment" "deployment_rg_contributor" {
  for_each = azurerm_resource_group.this

  scope                = each.value.id
  role_definition_name = "Contributor"
  principal_id         = module.deployment_identity.service_principal_object_id
}

resource "azurerm_role_assignment" "deployment_rg_user_access_administrator" {
  for_each = azurerm_resource_group.this

  scope                = each.value.id
  role_definition_name = "User Access Administrator"
  principal_id         = module.deployment_identity.service_principal_object_id
}

resource "azurerm_role_assignment" "deployment_state_blob_data_contributor" {
  scope                = data.azurerm_storage_account.state.id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = module.deployment_identity.service_principal_object_id
}

resource "azurerm_role_assignment" "deployment_key_vault_secrets_officer" {
  scope                = azurerm_key_vault.platform.id
  role_definition_name = "Key Vault Secrets Officer"
  principal_id         = module.deployment_identity.service_principal_object_id
}

