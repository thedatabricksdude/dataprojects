output "resource_groups" {
  value = {
    shared_services = azurerm_resource_group.this["shared_services"].name
    hub_network     = azurerm_resource_group.this["hub_network"].name
    web_auth        = azurerm_resource_group.this["web_auth"].name
    agent           = azurerm_resource_group.this["agent"].name
    workspaces      = { for key, value in var.resource_groups.workspaces : key => azurerm_resource_group.this["workspace_${key}"].name }
  }
}

output "state_backend" {
  value = var.state_backend
}

output "key_vault" {
  value = {
    id   = azurerm_key_vault.platform.id
    name = azurerm_key_vault.platform.name
  }
}

output "key_vault_secret_names" {
  value = var.key_vault_secret_names
}

output "deployment_identity" {
  value = {
    display_name                = module.deployment_identity.display_name
    client_id                   = module.deployment_identity.application_id
    service_principal_object_id = module.deployment_identity.service_principal_object_id
  }
}

output "agent_network" {
  value = {
    resource_group_name = azurerm_resource_group.this["agent"].name
    vnet_id             = azurerm_virtual_network.agent.id
    vnet_name           = azurerm_virtual_network.agent.name
    subnet_id           = azurerm_subnet.agent.id
    subnet_name         = azurerm_subnet.agent.name
    allowed_ssh_cidrs   = var.agent_network.allowed_ssh_cidrs
  }
}

