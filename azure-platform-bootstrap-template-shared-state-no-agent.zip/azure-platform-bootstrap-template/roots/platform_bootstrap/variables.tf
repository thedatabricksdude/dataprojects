variable "subscription_id" {
  description = "Optional subscription ID. Leave null to use the current Azure CLI context."
  type        = string
  default     = null
}

variable "tenant_id" {
  description = "Optional tenant ID. Leave null to use the current Azure CLI context."
  type        = string
  default     = null
}

variable "platform_name" {
  type = string
}

variable "environment" {
  type = string
}

variable "location" {
  type = string
}

variable "state_backend" {
  description = "Existing Terraform state backend created by bootstrap/state_backend."
  type = object({
    resource_group_name  = string
    storage_account_name = string
  })
}

variable "resource_groups" {
  description = "Shared resource groups that the Databricks platform repository will target."
  type = object({
    shared_services = string
    hub_network     = string
    web_auth        = string
    agent           = string
    workspaces      = map(string)
  })
}

variable "key_vault" {
  description = "Key Vault configuration used to hold deployment and bootstrap secrets."
  type = object({
    name                          = string
    sku_name                      = optional(string, "standard")
    public_network_access_enabled = optional(bool, true)
    purge_protection_enabled      = optional(bool, true)
  })
}

variable "deployment_identity" {
  description = "Microsoft Entra app registration and service principal settings for Terraform deployments."
  type = object({
    display_name           = string
    password_rotation_days = optional(number, 180)
  })
}

variable "agent_network" {
  description = "Network that can be used by the IT-managed self-hosted Azure DevOps agent."
  type = object({
    vnet_name         = string
    address_space     = list(string)
    subnet_name       = optional(string, "snet-ado-agent")
    subnet_prefixes   = list(string)
    allowed_ssh_cidrs = optional(list(string), [])
  })
}

variable "key_vault_secret_names" {
  description = "Secret names used in Key Vault for deployment identity and Databricks account bootstrap values."
  type = object({
    arm_client_id          = string
    arm_client_secret      = string
    arm_tenant_id          = string
    arm_subscription_id    = string
    databricks_account_id  = string
  })
}

variable "databricks_account_id" {
  description = "Optional Databricks account ID to store in Key Vault. Leave null and add it later if you do not know it yet."
  type        = string
  default     = null
}

variable "tags" {
  type    = map(string)
  default = {}
}
