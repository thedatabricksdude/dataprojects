# Databricks notebook source
# MAGIC %md
# MAGIC ### UC work with Volume to store temp files

# COMMAND ----------

from tempfile import TemporaryDirectory
import logging
import os
import pandas as pd

logger = logging.getLogger(__name__)

class UcTempVolume:
    def __init__(self, catalog_name:str,volume_name:str):
        self.volume_name = volume_name
        self.catalog_name = catalog_name

    def __enter__(self):
        self.tmp_dir = TemporaryDirectory()
        self.tmp_path = f'/Volumes/de_dev/volume/{self.volume_name}/tmp/'
        dbutils.fs.mkdirs(self.tmp_path)
        return self

    def write_file(self, filename, extension, content):
        file_path = os.path.join(self.tmp_path, f'{filename}{extension}')
        with open(file_path, 'wb+') as file:
            file.write(content)
        logger.info(os.listdir(self.tmp_path))

    def __exit__(self, exc_type, exc_value, traceback):
        self.tmp_dir.cleanup()
