import requests
import os
from pprint import pprint
import sys
import json
import re
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, from_json, lit
from pyspark.sql.types import *
from delta.tables import DeltaTable
from pyspark.sql import Row
from pyspark.dbutils import DBUtils
from delta.tables import DeltaTable

# Switch the Python executable path
sys.executable = '/usr/local/lib/python3.12'

class DatabricksBaseAPI:
    def __init__(
        self,
        databricks_instance=None,
        token=None,
        account_id = None,
        client_id=None,
        client_secret=None,
        tenant_id=None,
        resource=None,
        scope=None,
        scope2=None,
        client_id_secret_key=None,
        client_secret_secret_key=None,
        ):
        
        self.account_id = account_id
        self.client_id = client_id
        self.client_secret = client_secret
        self.tenant_id = tenant_id
        self.resource = resource
        self.scope = scope
        self.scope2 = scope2
        self.client_id_secret_key = client_id_secret_key
        self.client_secret_secret_key = client_secret_secret_key
        self.DATABRICKS_INSTANCE = databricks_instance
        
        # Get or create the Spark session
        self._spark = SparkSession.getActiveSession() or SparkSession.builder.getOrCreate()
        
        self._dbutils =  DBUtils(self._spark)
        self.TOKEN =  token if token else self._get_client_token() 
        self.HEADERS = {
            "Authorization": f"Bearer {self.TOKEN}",
            "Content-Type": "application/json"
        }

        ctx = self._dbutils.notebook.entry_point.getDbutils().notebook().getContext()
        self._HOST = None
        self.ACCOUNT_ID = account_id


        if 'WORKSPACE' in os.environ:
            self._HOST = os.environ['WORKSPACE']
        else:
            try:
                api_url = ctx.apiUrl().get()
                host = api_url.split("://", 1)[-1]
            except Exception:
                try:
                    self._HOST = ctx.tags().apply("browserHostName")
                except Exception:
                    self._HOST = None

        self._WORKSPACE_ID = None
        if self._HOST:
            m = re.search(r"adb-(\d+)", self._HOST)
            if m:
                self._WORKSPACE_ID = m.group(1)

        print(self._HOST,self._WORKSPACE_ID)

    def set_account_id(self, account_id):

        self.ACCOUNT_ID = account_id

    def set_databricks_instance(self, databricks_instance=None, token=None):
        self.DATABRICKS_INSTANCE = databricks_instance             


    def _get(self, endpoint,params=None,service_principal: bool = False, debug: bool = False):
        url = f"{self.DATABRICKS_INSTANCE}{endpoint}"

        if service_principal == True and self.SP_HEADERS is not None:
            api_header = self.SP_HEADERS
        else:
            api_header = self.HEADERS

        if debug:
            print(url)            
            print('PARAMS:',params)
            print('SP:',service_principal,self.SP_HEADERS)
            print('GET API HEADER: ',api_header)

        response = requests.get(url, headers=api_header, params=params)
        response.raise_for_status()
        if isinstance(type(response), dict):
           return response
        else:
            return response.json()

    
    def _post(self, endpoint, data, service_principal: bool = False):
      try:
        url = f"{self.DATABRICKS_INSTANCE}{endpoint}"
        print(url,data)
        if service_principal == True and self.SP_HEADERS is not None:
            api_header = self.SP_HEADERS
        else:
            api_header = self.HEADERS
        response = requests.post(url, headers=api_header, json=data)
        response.raise_for_status()
        return response.json()
      except requests.exceptions.HTTPError as e:
        print("Response Text:", response.text)
        raise e

    def _put(self, endpoint, data, service_principal: bool = False):
      try:
        url = f"{self.DATABRICKS_INSTANCE}{endpoint}"
        print(url,data)
        if service_principal == True and self.SP_HEADERS is not None:
            api_header = self.SP_HEADERS
        else:
            api_header = self.HEADERS
        response = requests.put(url, headers=api_header, json=data)
        response.raise_for_status()
        return response.json()
      except requests.exceptions.HTTPError as e:
        print("Response Text:", response.text)
        raise e    

    
    def _patch(self, endpoint, data, service_principal: bool = False):
      try:
        url = f"{self.DATABRICKS_INSTANCE}{endpoint}"
        if service_principal == True and self.SP_HEADERS is not None:
            api_header = self.SP_HEADERS
        else:
            api_header = self.HEADERS
        response = requests.patch(url, headers=api_header, json=data)
        response.raise_for_status()
        print(response.raise_for_status())
        return response.json()
      except requests.exceptions.HTTPError as e:
        print("Response Text:", response.text)
        raise e

    
    def _delete(self, endpoint, service_principal: bool = False):
        url = f"{self.DATABRICKS_INSTANCE}{endpoint}"
        if service_principal == True and self.SP_HEADERS is not None:
            api_header = self.SP_HEADERS
        else:
            api_header = self.HEADERS
        response=requests.delete(url, headers=api_header)        
        response.raise_for_status()
        return response.json()
    
    def _write_table(self, full_table_name: str, data_to_write, primary_key, schema, service_principal: bool = False, add_workspace: bool = False):

            spark = self._spark

            if schema:
                df = self._spark.createDataFrame(data_to_write, schema=schema)
            else:
                df = self._spark.createDataFrame(data_to_write)

            if add_workspace:
                df = df.withColumn('workspace_id',lit(self._WORKSPACE_ID)).withColumn('workspace_host',lit(self._HOST))

            df.display()

            if isinstance(primary_key, (list, tuple)):
                merge_condition = " AND ".join([f"target.{key} = source.{key}" for key in primary_key])
            else:
                merge_condition = f"target.{primary_key} = source.{primary_key}"

            if self._spark.catalog.tableExists(full_table_name):
                # Table exists: perform merge
                delta_table = DeltaTable.forName(spark, full_table_name)

                delta_table.alias("target").merge(
                    df.alias("source"),
                    merge_condition
                ).whenMatchedUpdateAll() \
                .whenNotMatchedInsertAll() \
                .execute()
            else:
                # Table doesn't exist: create it
                df.write.format("delta").saveAsTable(full_table_name)

    def _get_client_token(self) -> str:
        """
        Acquire an Azure AD access token via client credentials flow,
        store it on the instance, and return the token string.

        :param client_id:        Azure AD Application (client) ID
        :param client_secret:    Azure AD Application secret
        :param tenant_id:        Azure AD tenant ID
        :param resource_id:      Resource/audience for the token (e.g., https://management.azure.com/)
        :return:                 access token string
        :raises ValueError:      if any of the required credentials are missing
        :raises Exception:       if the token endpoint does not return an access_token
        """        

        if self.resource:
            RESOURCE_ID = self.resource
        else:
            try:
                RESOURCE_ID = self._dbutils.secrets.get(scope=self.scope, key="dbk-resource-id")
                #RESOURCE_ID = dbutils.secrets.get(scope=self.scope, key="dbk-resource-id")
            except Exception as e:
                print(f'Resource Error: {e}')
                try:
                    RESOURCE_ID = self._dbutils.secrets.get(scope=self.scope2, key="dbk-resource-id")
                    #RESOURCE_ID = dbutils.secrets.get(scope=self.scope2, key="dbk-resource-id")
                except:
                    RESOURCE_ID = None

        if self.tenant_id:
            TENANT_ID = self.tenant_id
        else:
            try:
                TENANT_ID = self._dbutils.secrets.get(scope=self.scope, key="tenant-id")
                #TENANT_ID = dbutils.secrets.get(scope=self.scope, key="tenant-id")
            except Exception as e:
                print(f'Tenant Error: {e}')
                try:
                    TENANT_ID = self._dbutils.secrets.get(scope=self.scope2, key="tenant-id")
                    #TENANT_ID = dbutils.secrets.get(scope=self.scope2, key="tenant-id")
                except:
                    TENANT_ID = None

        if self.client_id:
            CLIENT_ID = self.client_id
        elif self.client_id_secret_key and self.scope:
            try:
               CLIENT_ID = self._dbutils.secrets.get(scope=self.scope, key=self.client_id_secret_key)
               #CLIENT_ID = dbutils.secrets.get(scope=self.scope, key=self.client_id_secret_key)
            except Exception as e:
                print(f'Client id Error: {e}')
                try:
                    CLIENT_ID = self._dbutils.secrets.get(scope=scope2, key=self.client_id_secret_key)
                except:
                    CLIENT_ID = None
        else:
            CLIENT_ID = None

        if self.client_secret:
            CLIENT_SECRET = self.client_secret
        elif self.client_secret_secret_key and self.scope:
            try:
                CLIENT_SECRET = self._dbutils.secrets.get(scope=self.scope, key=self.client_secret_secret_key)
                #CLIENT_SECRET = dbutils.secrets.get(scope=self.scope, key=self.client_secret_secret_key)
            except Exception as e:
                print(f'Client secret Error: {e}')
                try:
                    #CLIENT_SECRET = dbutils.secrets.get(scope=self.scope2, key=self.client_secret_secret_key)
                    CLIENT_SECRET = self._dbutils.secrets.get(scope=self.scope2, key=self.client_secret_secret_key)
                except:
                    CLIENT_SECRET = None
        else:
             CLIENT_SECRET = None
        if CLIENT_ID is None or TENANT_ID is None or CLIENT_SECRET is None or RESOURCE_ID is None:
            raise ValueError("Client id, tenant id, client secret or resource are not set.")        

        url = f"https://login.microsoftonline.com/{TENANT_ID}/oauth2/token"
        payload = {
            'grant_type': 'client_credentials',
            'client_id': CLIENT_ID,
            'client_secret': CLIENT_SECRET,
            'resource': RESOURCE_ID
        }

        response = requests.post(url, data=payload)
        token = response.json().get('access_token')        
        if not token:
            raise Exception("Unable to get token") 
        else:
            self.SP_TOKEN = token
            self.SP_HEADERS = {
            "Authorization": f"Bearer {self.SP_TOKEN}",
            "Content-Type": "application/json"
            }         
            print(f"HEADERS: {self.SP_HEADERS}")            
        
        return token
 


class ClustersAPI(DatabricksBaseAPI):
    
    def _sanitize(self, name: str) -> str:
        s = re.sub(r'[^A-Za-z0-9]+', '_', name or '')
        s = re.sub(r'_+', '_', s).strip('_').lower()
        return s

    def _scalarize(self,value):
        """Ensure a single scalar per cell:
        - list of scalars -> comma-joined string
        - list with dicts -> compact JSON string
        - dict            -> compact JSON string
        - other           -> str(value)
        """
        if value is None:
            return None
        if isinstance(value, list):
            if all(not isinstance(x, (dict, list)) for x in value):
                return ",".join(map(str, value))            # <-- comma-separated (your preference)
            return json.dumps(value, separators=(",", ":"), sort_keys=True)
        if isinstance(value, dict):
            return json.dumps(value, separators=(",", ":"), sort_keys=True)
        return str(value)

    def _flatten(self, obj, prefix, out):
        """Recursively flatten dicts. Lists of scalars become comma-joined.
        Lists with dicts become JSON (single scalar)."""
        if isinstance(obj, dict):
            for k, v in obj.items():
                new_prefix = f"{prefix}_{self._sanitize(k)}" if prefix else self._sanitize(k)
                if isinstance(v, dict):
                    self._flatten(v, new_prefix, out)
                elif isinstance(v, list):
                    if all(not isinstance(x, (dict, list)) for x in v):
                        out[new_prefix] = ",".join(map(str, v))
                    else:
                        out[new_prefix] = json.dumps(v, separators=(",", ":"), sort_keys=True)
                else:
                    out[new_prefix] = self._scalarize(v)
        else:
            # Non-dict at root (unlikely for policy definitions) -> scalarize it
            out[prefix] = self._scalarize(obj)

    def list_clusters(self, service_principal: bool = False):
        return self._get("/api/2.1/clusters/list", service_principal)

    def write_table_clusters(self, catalog_name: str = 'platform_admin', schema_name: str = 'metadata', table_name: str = 'clusters', service_principal: bool = False):

        results_table = f"{catalog_name}.{schema_name}.{table_name}"

        clusters = self.list_clusters(service_principal=service_principal)

        # Assuming `clusters` is a Python dictionary loaded from your JSON
        clusters_list = clusters['clusters']

        # Flatten each cluster into a simplified dictionary
        flat_clusters = []
        for cluster in clusters_list:
            base = {
                'cluster_id': cluster.get('cluster_id'),
                'cluster_name': cluster.get('cluster_name'),
                'creator_user_name': cluster.get('creator_user_name'),
                'spark_version': cluster.get('spark_version'),
                'state': cluster.get('state'),
                'driver_private_ip': cluster.get('driver', {}).get('private_ip'),
                'driver_public_dns': cluster.get('driver', {}).get('public_dns'),
                'driver_node_type_id': cluster.get('driver', {}).get('node_type_id'),
                'num_executors': len(cluster.get('executors', [])),
                'node_type_id': cluster.get('node_type_id'),
                'driver_healthy': cluster.get('driver_healthy'),
                'start_time': cluster.get('start_time'),
                'last_activity_time': cluster.get('last_activity_time'),
                'cluster_cores': cluster.get('cluster_cores'),
                'cluster_memory_mb': cluster.get('cluster_memory_mb'),
                'runtime_engine': cluster.get('runtime_engine'),
                'data_security_mode': cluster.get('data_security_mode'),
            }

            # Optionally flatten tags
            tags = cluster.get('default_tags', {})
            for key, value in tags.items():
                base[f'tag_{key.replace(" ", "_").lower()}'] = value

            flat_clusters.append(base)        

        if flat_clusters:
            self._write_table(full_table_name=results_table, data_to_write=flat_clusters, primary_key="cluster_id")
            print(f"Data written to table {results_table}")
        else:
            print("No data to write")   

    # Create cluster based on either json payload or some default parameters
    def create_cluster(self, cluster_name=None, spark_version=None, node_type_id=None, num_workers=None, json_data=None, service_principal: bool = False):
        if json_data:
            data = json_data
        elif not all([cluster_name, spark_version, node_type_id, num_workers]):
            raise ValueError("Missing required parameters.")
        else:
            data = {
                "cluster_name": cluster_name,
                "spark_version": spark_version,
                "node_type_id": node_type_id,
                "num_workers": num_workers
            }
        return self._post("/api/2.1/clusters/create", data, service_principal)
    
    def delete_cluster(self, cluster_id, service_principal: bool = False):
        return self._post(f"/api/2.1/clusters/delete", {"cluster_id": cluster_id}, service_principal)
    
    
    def update_cluster_config(self, data:dict, service_principal: bool = False):
        """
        Update the configuration of a cluster.
        :param cluster_id: The ID of the cluster to update.
        :param data: The new configuration for the cluster.
        :return: Response JSON from the API.
        https://docs.databricks.com/api/azure/workspace/clusters/edit
        """
        return self._post(f"/api/2.1/clusters/edit", data, service_principal) 
    
    def list_policies(self, service_principal: bool = False):
        """
        Get a cluster policy by ID.
        https://api-reference.cloud.databricks.com/azure/workspace/clusterpolicies/get
        """        

        return self._get("/api/2.0/policies/clusters/list", service_principal)
    
    def write_table_policies(self, catalog_name: str = 'platform_admin', schema_name: str = 'metadata', table_name: str = 'policies', service_principal: bool = False):

        spark = self._spark
        results_table = f"{catalog_name}.{schema_name}.{table_name}"

        policies = self.list_policies(service_principal=service_principal)

        rows = []
        for p in policies.get("policies", []):
            row = {}

            # carry a few common top-level policy fields (add more if you like)
            for base_key in ("policy_id", "name", "created_at_timestamp", "is_default"):
                row[self._sanitize(base_key)] = self._scalarize(p.get(base_key))

            # parse/normalize the definition (may be a JSON string or already a dict)
            definition_raw = p.get("definition")
            try:
                definition = json.loads(definition_raw) if isinstance(definition_raw, str) else (definition_raw or {})
            except Exception:
                definition = {}

            # recursively flatten the definition under the "definition" namespace
            self._flatten(definition, "definition", row)

            rows.append(row)

        # -------- normalize columns + schema --------
        all_cols = sorted({c for r in rows for c in r.keys()})
        for r in rows:
            for c in all_cols:
                r.setdefault(c, None)

        schema = StructType([StructField(c, StringType(), True) for c in all_cols])
                      
        workspace_id = os.environ.get("WORKSPACE_ID")
        workspace_host = os.environ.get("WORKSPACE_NAME")
        print(f"VAR: {workspace_id},{workspace_host}")
        # pass to spark.createDataFrame
        df = spark.createDataFrame([tuple(r[c] for c in all_cols) for r in rows], schema)
        df = (
            df.withColumn("workspace_id", lit(workspace_id))
              .withColumn("workspace_host", lit(workspace_host))
        )
        df.display()

#        self._spark.sql(f"DROP TABLE IF EXISTS {results_table}")I

        #df.write.format("delta").saveAsTable(results_table)

        print(df.columns)

        column_list = df.columns

        delta_table = DeltaTable.forName(self._spark, results_table)

        (
            delta_table.alias("t")
            .merge(
                df.alias("s"),
                "t.policy_id = s.policy_id"
            )
            .whenMatchedUpdate(
                set={c: f"s.{c}" for c in column_list}
            )
            .whenNotMatchedInsert(
                values={c: f"s.{c}" for c in column_list}
            )
            .execute()
        )

        print(f"Data written to table {results_table}")     

    def get_policy(self, policy_id, service_principal: bool = False):
        """
        Get a cluster policy by ID.
        https://api-reference.cloud.databricks.com/azure/workspace/clusterpolicies/get
        """
        return self._get(f"/api/2.0/policies/clusters/get?policy_id={policy_id}", service_principal)

    def create_policy(self, name, definition, description=None, max_clusters_per_user=None, service_principal: bool = False):
        """
        Create a new cluster policy.
        https://api-reference.cloud.databricks.com/azure/workspace/clusterpolicies/create
        """
        data = {
            "name": name,
            "definition": definition
        }
        if description:
            data["description"] = description
        if max_clusters_per_user:
            data["max_clusters_per_user"] = max_clusters_per_user
        return self._post("/api/2.0/policies/clusters/create", data, service_principal)

    def edit_policy(self, policy_id, name=None, definition=None, description=None, max_clusters_per_user=None, service_principal: bool = False):
        """
        Edit an existing cluster policy.
        https://api-reference.cloud.databricks.com/azure/workspace/clusterpolicies/edit
        """
        data = {
            "policy_id": policy_id
        }
        if name:
            data["name"] = name
        if definition:
            data["definition"] = definition
        if description:
            data["description"] = description
        if max_clusters_per_user:
            data["max_clusters_per_user"] = max_clusters_per_user
        return self._post("/api/2.0/policies/clusters/edit", data, service_principal)

    def delete_policy(self, policy_id, service_principal: bool = False):
        """
        Delete a cluster policy.
        https://api-reference.cloud.databricks.com/azure/workspace/clusterpolicies/delete
        """
        data = {"policy_id": policy_id}
        return self._post("/api/2.0/policies/clusters/delete", data, service_principal)

    def get_policy_permission_levels(self, policy_id, service_principal: bool = False):
        """
        Get permission levels for a cluster policy.
        https://api-reference.cloud.databricks.com/azure/workspace/clusterpolicies/getpermissionlevels
        """
        return self._get(f"/api/2.0/permissions/cluster-policies/{policy_id}/permissionLevels", service_principal)

        # access_control_list should be a list of permission dicts like:
        # [
        #     {"user_name": "someone@example.com", "permission_level": "CAN_MANAGE"},
        #     {"group_name": "admins", "permission_level": "CAN_VIEW"}
        # ]
        # Valid permission levels include: CAN_VIEW, CAN_USE, CAN_MANAGE

    def update_policy_permissions(self, policy_id, access_control_list, service_principal: bool = False):
        """
        Update permissions for a cluster policy.
        https://api-reference.cloud.databricks.com/azure/workspace/clusterpolicies/updatepermissions
        """
        
        data = {"access_control_list": access_control_list}
        return self._patch(f"/api/2.0/permissions/cluster-policies/{policy_id}", data, service_principal)

    def set_policy_permissions(self, policy_id, access_control_list, service_principal: bool = False):
        """
        Set permissions for a cluster policy.
        https://api-reference.cloud.databricks.com/azure/workspace/clusterpolicies/setpermissions
        """
        data = {"access_control_list": access_control_list}
        return self._post(f"/api/2.0/permissions/cluster-policies/{policy_id}", data, service_principal)



class Unity_Catalog_API(DatabricksBaseAPI):
    
    def list_catalog(self, service_principal: bool = False):
        endpoint = "/api/2.1/unity-catalog/catalogs"
        return self._get(endpoint=endpoint, service_principal=service_principal)
    
    def write_table(self, catalog_name: str = 'platform_admin', schema_name: str = 'metadata', table_name: str = 'catalogs', service_principal: bool = False):

        results_table = f"{catalog_name}.{schema_name}.{table_name}"

        catalogs_json = self.list_catalog(service_principal=service_principal)

        catalogs = catalogs_json["catalogs"]

        flat_data = []
        for item in catalogs:
            record = {
                "name": item.get("name"),
                "owner": item.get("owner"),
                "comment": item.get("comment"),
                "catalog_type": item.get("catalog_type"),
                "metastore_id": item.get("metastore_id"),
                "created_at": item.get("created_at"),
                "created_by": item.get("created_by"),
                "updated_at": item.get("updated_at"),
                "updated_by": item.get("updated_by"),
                "isolation_mode": item.get("isolation_mode"),
                "accessible_in_current_workspace": item.get("accessible_in_current_workspace"),
                "browse_only": item.get("browse_only"),
                "id": item.get("id"),
                "full_name": item.get("full_name"),
                "securable_type": item.get("securable_type"),
                "securable_kind": item.get("securable_kind"),
                "resource_name": item.get("resource_name"),
                "metastore_version": item.get("metastore_version"),
                # Flatten nested flags
                "auto_maintenance_value": item.get("effective_auto_maintenance_flag", {}).get("value"),
                "auto_maintenance_inherited_from_type": item.get("effective_auto_maintenance_flag", {}).get("inherited_from_type"),
                "auto_maintenance_inherited_from_name": item.get("effective_auto_maintenance_flag", {}).get("inherited_from_name"),
                "predictive_optimization_value": item.get("effective_predictive_optimization_flag", {}).get("value"),
                "predictive_optimization_inherited_from_type": item.get("effective_predictive_optimization_flag", {}).get("inherited_from_type"),
                "predictive_optimization_inherited_from_name": item.get("effective_predictive_optimization_flag", {}).get("inherited_from_name"),
                # Optional fields for Delta Sharing catalogs
                "provider_name": item.get("provider_name"),
                "share_name": item.get("share_name"),
                "delta_sharing_valid_through_timestamp": item.get("delta_sharing_valid_through_timestamp")
            }
            flat_data.append(record)

        if catalogs:
            self._write_table(full_table_name=results_table, data_to_write=flat_data, primary_key="id", schema=None, service_principal=service_principal)
            print(f"Data written to table {results_table}")
        else:
            print("No data to write")    
    
    def list_catalog_tables(self,catalog_name, service_principal: bool = False):
        url = f"/api/2.0/unity-catalog/tables"
        params = {"catalog_name": catalog_name,
                  "schema_name": "gold"}
        response = self._get(endpoint=url, params=params, service_principal=service_principal)
        return response
    
    # Function to get extended properties of a table
    def get_table_properties(self, catalog_name, schema_name, table_name, service_principal: bool = False):
        response = self._get(f"/api/2.0/unity-catalog/tables/{catalog_name}.{schema_name}.{table_name}", service_principal)
        return response

    # Function to get table lineage
    def get_table_lineage(self, table_name, service_principal: bool = False):
        url = f"/api/2.0/lineage-tracking/table-lineage"
        data = {
                 "table_name": table_name,
                 "include_entity_lineage": True
        }
        response = self._post(endpoint=url, data=json.dumps(data), service_principal=service_principal)
        return response.json()
    
    # Function to get table lineage
    def get_table_lineage(self, catalog_name, schema_name, table_name, service_principal: bool = False):
        url = f"/api/2.0/lineage-tracking/table-lineage"
        data = {
            "table_name": f"{catalog_name}.{schema_name}.{table_name}",
            "include_entity_lineage": True
        }
        response = self._post(endpoint=url, data=json.dumps(data), service_principal=service_principal)
        return response.json()
    
class IdentityAPI(DatabricksBaseAPI):

    def _get_id_url(self):
         
        """
        Generate full URL for the API endpoint.
        """
        return f"/api/2.0/preview/"
    
    def list_users(self):

        """
        List all users workspaces 
        """
        return self._get(self._get_id_url() + "scim/v2/Users")
    
    def get_users_details(self,id):
        """
        List all users workspaces roles and group memberships.
        """
        return self._get(self._get_id_url() + "scim/v2/Users/{id}")

class MetastoresAPI(DatabricksBaseAPI):
    
    def list_metastores(self, service_principal: bool = False):

        return self._get("/api/2.1/unity-catalog/metastores", service_principal)

    def write_table(self, catalog_name: str = 'platform_admin', schema_name: str = 'metadata', table_name: str = 'metastores', service_principal: bool = False):

        results_table = f"{catalog_name}.{schema_name}.{table_name}"

        metastores = self.list_metastores(service_principal=service_principal)

        print(metastores)

        if metastores:
            self._write_table(full_table_name=results_table, data_to_write=metastores, primary_key="metastore_id", schema=None, service_principal=service_principal)
            print(f"Data written to table {results_table}")
        else:
            print("No data to write")      

    
    def create_metastore(self, name, storage_root, service_principal: bool = False):
        data = {
            "name": name,
            "storage_root": storage_root
        }
        return self._post("/api/2.1/unity-catalog/metastores", data, service_principal)

    
    def delete_metastore(self, metastore_id, service_principal: bool = False):
        return self._delete(f"/api/2.1/unity-catalog/metastores/{metastore_id}", service_principal)
    
    
    def get_metastore(self, metastore_id, service_principal: bool = False):
        """Get details of a specific metastore."""
        return self._get(f"/api/2.1/unity-catalog/metastores/{metastore_id}", service_principal)

    
    def update_metastore(self, metastore_id, updates, service_principal: bool = False):
        """Update an existing metastore."""
        return self._patch(f"/api/2.1/unity-catalog/metastores/{metastore_id}", updates, service_principal)

    
    def assign_metastore(self, workspace_id, metastore_id, default_catalog_name, service_principal: bool = False):
        """Assign a metastore to a workspace."""
        data = {
            "workspace_id": workspace_id,
            "metastore_id": metastore_id,
            "default_catalog_name": default_catalog_name
        }
        return self._post("/api/2.1/unity-catalog/metastores/assignments", data, service_principal)

    
    def unassign_metastore(self, workspace_id, service_principal: bool = False):
        """Unassign a metastore from a workspace."""
        return self._delete(f"/api/2.1/unity-catalog/metastores/assignments/workspaces/{workspace_id}", service_principal)

    
    def update_assignment(self, workspace_id, updates, service_principal: bool = False):
        """Update an existing assignment for a workspace."""
        return self._patch(f"/api/2.1/unity-catalog/metastores/assignments/workspaces/{workspace_id}", updates, service_principal)

    
    def current_metastore(self, service_principal: bool = False):
        """Get the current metastore assignment for the workspace."""
        return self._get("/api/2.1/unity-catalog/metastores/current", service_principal)

    
    def get_metastore_summary(self, service_principal: bool = False):
        """Get a summary of the metastore."""
        return self._get("/api/2.1/unity-catalog/metastores/summary", service_principal)



class JobsAPI(DatabricksBaseAPI):
    """
    A client class for managing Azure Databricks Jobs via REST API.

    This class provides methods to create, list, update, delete, and monitor jobs,
    as well as manage job permissions and run history.

    API Overview: https://docs.databricks.com/api/azure/workspace/jobs
    """

    def get_cluster_id_from_job_id(self, job_id, service_principal: bool = False):
        """
        Retrieves the cluster ID associated with a specific job.

        API: https://docs.databricks.com/api/azure/workspace/jobs/get  
        Returns job metadata including cluster configuration.

        Args:
            job_id (str): Unique identifier of the job.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            str: Cluster ID if found, else empty string.
        """
        api_data = self._get(f"/api/2.2/jobs/get?limit=100&job_id={job_id}")
        cluster_data = api_data.get("settings", {})
        try:
            existing_cluster_id = cluster_data.get('tasks', [{}])[0].get('existing_cluster_id', '', service_principal)
        except (IndexError, KeyError, TypeError):
            existing_cluster_id = ''
        return existing_cluster_id

    def list_jobs(self, filter_by_cluster_id=None, service_principal: bool = False):
        """
        Lists jobs, optionally filtering by cluster ID.

        API: https://docs.databricks.com/api/azure/workspace/jobs/list  
        Returns metadata for all jobs in the workspace.

        Args:
            filter_by_cluster_id (str, optional): Cluster ID to filter jobs.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            list: Filtered list of jobs as tuples (name, id, creator).
        """
        response = self._get("/api/2.1/jobs/list", service_principal)
        jobs_data = response.get("jobs", [])
        filtered_jobs = []
        for job in jobs_data:
            job_name = job.get("settings", {}).get("name", "Unnamed Job")
            job_id = job.get("job_id")
            creator = job.get("creator_user_name", "Unknown Creator")
            cluster_id = self.get_cluster_id_from_job_id(job_id, service_principal)
            if filter_by_cluster_id and cluster_id != filter_by_cluster_id:
                continue
            filtered_jobs.append((job_name, job_id, creator))
        filtered_jobs.sort(key=lambda x: x[0].lower())
        return filtered_jobs

    def get_jobs(self, service_principal: bool = False) -> list:
        """
        Retrieves all job metadata from the workspace, handling pagination correctly.

        API: https://docs.databricks.com/api/azure/workspace/jobs/list  
        Returns full job definitions and configurations across all pages.

        Args:
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            list: List of job metadata dictionaries.
        """
        endpoint = "/api/2.1/jobs/list"
        all_jobs = []
        page_token = None

        while True:
            params = {}
            if page_token:
                params["page_token"] = page_token

            response = self._get(endpoint, service_principal=service_principal, params=params)
            jobs = response.get("jobs", [])
            all_jobs.extend(jobs)       

            if response.get("has_more"):
                # Reuse the same page_token value for the next request
                page_token = response.get("next_page_token")
            else:
                break

        return all_jobs





    def write_table(self, catalog_name='platform_admin', schema_name='metadata', table_name='jobs', service_principal: bool = False):
        """
        Writes job metadata to a Delta table.

        This method flattens job metadata and stores it in a structured format.

        Args:
            catalog_name (str): Catalog name.
            schema_name (str): Schema name.
            table_name (str): Table name.
            service_principal (bool): Whether to use service principal authentication.
        """
        results_table = f"{catalog_name}.{schema_name}.{table_name}"
        jobs = self.get_jobs(service_principal=service_principal)
        flat_jobs = [{
            "job_id": str(job.get("job_id")),
            "job_name": job.get("settings", {}).get("name"),
            "creator_user_name": job.get("creator_user_name"),
            "created_time": job.get("created_time"),
            "run_as_user_name": job.get("settings", {}).get("run_as_user_name"),
            "timeout_seconds": job.get("settings", {}).get("timeout_seconds"),
            "max_concurrent_runs": job.get("settings", {}).get("max_concurrent_runs"),
            "schedule_quartz_cron_expression": job.get("settings", {}).get("schedule", {}).get("quartz_cron_expression"),
            "schedule_timezone_id": job.get("settings", {}).get("schedule", {}).get("timezone_id"),
            "job_clusters_count": len(job.get("settings", {}).get("job_clusters", [])),
            "email_notifications": job.get("settings", {}).get("email_notifications", {}).get("on_failure", [])
        } for job in jobs]
        schema = StructType([
            StructField("job_id", StringType(), True),
            StructField("job_name", StringType(), True),
            StructField("creator_user_name", StringType(), True),
            StructField("created_time", LongType(), True),
            StructField("run_as_user_name", StringType(), True),
            StructField("timeout_seconds", LongType(), True),
            StructField("max_concurrent_runs", LongType(), True),
            StructField("schedule_quartz_cron_expression", StringType(), True),
            StructField("schedule_timezone_id", StringType(), True),
            StructField("job_clusters_count", LongType(), True),
            StructField("email_notifications", ArrayType(StringType()), True)
        ])
        if flat_jobs:
            self._write_table(results_table, flat_jobs, "job_id", schema=schema, service_principal=service_principal, add_workspace=True)
            print(f"Data written to table {results_table}")
        else:
            print("No data to write")

    def create_job(self, job_name, notebook_path, service_principal: bool = False):
        """
        Creates a new job.

        API: https://docs.databricks.com/api/azure/workspace/jobs/create  
        Registers a new job with the specified notebook task.

        Args:
            job_name (str): Name of the job.
            notebook_path (str): Path to the notebook.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: API response with job creation details.
        """
        data = {
            "name": job_name,
            "notebook_task": {"notebook_path": notebook_path}
        }
        return self._post("/api/2.1/jobs/create", data, service_principal)

    def delete_job(self, job_id, service_principal: bool = False):
        """
        Deletes a job.

        API: https://docs.databricks.com/api/azure/workspace/jobs/delete  
        Removes the job and its configuration from the workspace.

        Args:
            job_id (str): Unique identifier of the job.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: API response confirming deletion.
        """
        return self._post("/api/2.1/jobs/delete", {"job_id": job_id}, service_principal)
    

    def reset_job(self, job_id, new_settings: dict, service_principal: bool = False):
        """
        Resets (updates) a job with new settings.

        API: https://docs.databricks.com/api/azure/workspace/jobs/reset  
        Overwrites the job’s configuration with the provided settings.

        Args:
            job_id (str): Unique identifier of the job.
            new_settings (dict): New job settings to apply.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: API response with reset confirmation.
        """
        data = {
            "job_id": job_id,
            "new_settings": new_settings
        }
        return self._post("/api/2.1/jobs/reset", data, service_principal)

    def get_job(self, job_id, service_principal: bool = False) -> dict:
        """
        Retrieves the full definition of a specific job, handling pagination if necessary.

        API: https://docs.databricks.com/api/azure/workspace/jobs/get  
        Returns the complete job configuration, including tasks, clusters, and permissions.

        Args:
            job_id (str): Unique identifier of the job.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: Full job definition.
        """
        endpoint = "/api/2.1/jobs/get"
        job_definition = {}
        page_token = None

        while True:
            params = {"job_id": job_id}
            if page_token:
                params["page_token"] = page_token

            response = self._get(endpoint, service_principal=service_principal, params=params)

            # Merge response into job_definition
            for key, value in response.items():
                if key not in job_definition:
                    job_definition[key] = value
                elif isinstance(value, list):
                    job_definition[key].extend(value)
                elif isinstance(value, dict):
                    job_definition[key].update(value)
                else:
                    job_definition[key] = value

            if response.get("has_more"):
                page_token = response.get("next_page_token")
            else:
                break

        return job_definition
    
    
    def update_job_tags(self, tag_spec, job_id, service_principal: bool = False):
        """
        Updates an existing job's tag configuration.

        Args:
            job_id (str): Unique identifier of the job.
            updates (dict): Dictionary of updated job fields.

        Returns:
            dict: API response with updated job details.
        """          

        my_job = self.get_job(job_id, service_principal=service_principal)

        # Ensure 'tags' exists inside spec
        if "tags" not in my_job:
            my_job["tags"] = {}

        # Merge updates['tags'] into existing spec['tags']
        my_job["tags"].update(tag_spec["tags"])        

        # Update job definition using updated definition
        self.reset_job(job_id, my_job, service_principal)    

    def run_now(self, job_id, service_principal: bool = False):
        """
        Triggers an immediate run of a job.

        API: https://docs.databricks.com/api/azure/workspace/jobs/runnow  
        Executes the job outside of its schedule.

        Args:
            job_id (str): Unique identifier of the job.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: Run metadata.
        """
        return self._post("/api/2.1/jobs/run-now", {"job_id": job_id}, service_principal)

    def cancel_run(self, run_id, service_principal: bool = False):
        """
        Cancels a specific job run.

        API: https://docs.databricks.com/api/azure/workspace/jobs/cancelrun  
        Stops the execution of a running job.

        Args:
            run_id (str): Unique identifier of the run.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: Confirmation of cancellation.
        """
        return self._post("/api/2.1/jobs/cancelRun", {"run_id": run_id}, service_principal)

    def cancel_all_runs(self, job_id, service_principal: bool = False):
        """
        Cancels all active runs of a job.

        API: https://docs.databricks.com/api/azure/workspace/jobs/cancelallruns  
        Stops all currently executing instances of the job.

        Args:
            job_id (str): Unique identifier of the job.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: Confirmation of cancellation.
        """
        return self._post("/api/2.1/jobs/cancelAllRuns", {"job_id": job_id}, service_principal)

    def delete_run(self, run_id, service_principal: bool = False):
        """
        Deletes a specific job run.

        API: https://docs.databricks.com/api/azure/workspace/jobs/deleterun  
        Removes the run record from the workspace.

        Args:
            run_id (str): Unique identifier of the run.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: Confirmation of deletion.
        """
        return self._post("/api/2.1/jobs/deleteRun", {"run_id": run_id}, service_principal)

    def export_run(self, run_id, service_principal: bool = False):
        """
        Exports the configuration and results of a job run.

        API: https://docs.databricks.com/api/azure/workspace/jobs/exportrun  
        Returns the run's notebook output and metadata.

        Args:
            run_id (str): Unique identifier of the run.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: Exported run data.
        """
        return self._get("/api/2.1/jobs/exportRun", {"run_id": run_id}, service_principal)

    def get_run(self, run_id, service_principal: bool = False):
        """
        Retrieves metadata for a specific job run.

        API: https://docs.databricks.com/api/azure/workspace/jobs/getrun  
        Returns status, timing, and task details.

        Args:
            run_id (str): Unique identifier of the run.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: Run metadata.
        """
        return self._get("/api/2.1/jobs/getRun", {"run_id": run_id}, service_principal)

    def get_run_output(self, run_id, service_principal: bool = False):
        """
        Retrieves the output logs and results of a completed job run.

        API: https://docs.databricks.com/api/azure/workspace/jobs/getrunoutput  
        Returns stdout, error logs, and result summary.

        Args:
            run_id (str): Unique identifier of the run.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: Run output.
        """
        return self._get("/api/2.1/jobs/getRunOutput", {"run_id": run_id}, service_principal)

    def list_runs(self, job_id=None, active_only=False, completed_only=False, page_token=None, service_principal: bool = False):
        """
        Lists historical and active runs for jobs.

        API: https://docs.databricks.com/api/azure/workspace/jobs/listruns  
        Returns run history with optional filters.

        Args:
            job_id (str, optional): Filter runs by job ID.
            active_only (bool): If True, only return active runs.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: List of job runs.
        """
        params = {}
        if job_id:
            params["job_id"] = job_id
        if active_only:
            params["active_only"] = "true"
        if completed_only:
            params["completed_only"] = "true"
        if page_token:
            params["page_token"] = page_token

        return self._get("/api/2.1/jobs/runs/list", params, service_principal)

    def repair_run(self, run_id, instructions, service_principal: bool = False):
        """
        Repairs a failed or canceled job run.

        API: https://docs.databricks.com/api/azure/workspace/jobs/repairrun  
        Re-executes selected tasks from a previous run.

        Args:
            run_id (str): Unique identifier of the run to repair.
            instructions (dict): Repair instructions specifying which tasks to rerun.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: New run metadata.
        """
        payload = {"run_id": run_id, "instructions": instructions}
        return self._post("/api/2.1/jobs/repairRun", payload, service_principal)

    def submit_run(self, run_config, service_principal: bool = False):
        """
        Submits a one-time run without creating a persistent job.

        API: https://docs.databricks.com/api/azure/workspace/jobs/submit  
        Executes a job configuration immediately.

        Args:
            run_config (dict): Configuration for the run including tasks and cluster.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: Run metadata.
        """
        return self._post("/api/2.1/jobs/runs/submit", run_config, service_principal)

    def get_job_permissions(self, job_id, service_principal: bool = False):
        """
        Retrieves access control settings for a job.

        API: https://docs.databricks.com/api/azure/workspace/jobs/getpermissions  
        Returns permission entries and roles for the specified job.

        Args:
            job_id (str): Unique identifier of the job.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: Permission metadata.
        """
        return self._get(f"/api/2.0/permissions/jobs/{job_id}", service_principal=service_principal)

    def set_job_permissions(self, job_id, access_control_list, service_principal: bool = False):
        """
        Sets access control permissions for a job.

        API: https://docs.databricks.com/api/azure/workspace/jobs/setpermissions  
        Replaces existing permissions with the provided list.

        Args:
            job_id (str): Unique identifier of the job.
            access_control_list (list): List of permission entries.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: API response confirming permission update.
        """
        payload = {"access_control_list": access_control_list}
        return self._post(f"/api/2.0/permissions/jobs/{job_id}", payload, service_principal)

    def update_job_permissions(self, job_id, access_control_list, service_principal: bool = False):
        """
        Updates access control permissions for a job.

        API: https://docs.databricks.com/api/azure/workspace/jobs/updatepermissions  
        Modifies existing permission entries for the job.

        Args:
            job_id (str): Unique identifier of the job.
            access_control_list (list): Updated permission entries.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: API response confirming permission update.
        """
        payload = {"access_control_list": access_control_list}
        return self._patch(f"/api/2.0/permissions/jobs/{job_id}", payload, service_principal)

    def get_job_permission_levels(self, job_id, service_principal: bool = False):
        """
        Retrieves available permission levels for a job.

        API: https://docs.databricks.com/api/azure/workspace/jobs/getpermissionlevels  
        Returns a list of permission levels that can be assigned to users.

        Args:
            job_id (str): Unique identifier of the job.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: API response with permission level options.
        """
        return self._get(f"/api/2.0/permissions/jobs/{job_id}/permissionLevels", service_principal=service_principal)


class DashboardsAPI(DatabricksBaseAPI):
    
    def list_dashboards(self, service_principal: bool = False):
        return self._get("/api/2.0/preview/sql/dashboards", service_principal)
    
    def write_table(self, catalog_name: str = 'platform_admin', schema_name: str = 'metadata', table_name: str = 'dashboards', service_principal: bool = False):

        results_table = f"{catalog_name}.{schema_name}.{table_name}"

        dashboards = self.list_dashboards(service_principal=service_principal)

        schema = StructType([
            StructField("id", StringType(), True),
            StructField("slug", StringType(), True),
            StructField("name", StringType(), True),
            StructField("user_id", LongType(), True),
            StructField("dashboard_filters_enabled", BooleanType(), True),
            StructField("is_draft", BooleanType(), True),
            StructField("updated_at", StringType(), True),
            StructField("created_at", StringType(), True),
            StructField("version", LongType(), True),
            StructField("color_palette", StringType(), True),
            StructField("run_as_role", StringType(), True),
            StructField("run_as_service_principal_id", StringType(), True),
            StructField("data_source_id", StringType(), True),
            StructField("warehouse_id", StringType(), True),
            StructField("is_favorite", BooleanType(), True),
            StructField("folder_parent", StringType(), True),
            StructField("folder_node_status", StringType(), True),
            StructField("folder_node_internal_name", StringType(), True),
            StructField("user_name", StringType(), True),
            StructField("user_email", StringType(), True),
            StructField("tags", StringType(), True)
        ])

        flat_dashboards = []
        for d in dashboards["results"]:
            record = {
                "id": d.get("id"),
                "slug": d.get("slug"),
                "name": d.get("name"),
                "user_id": d.get("user_id"),
                "dashboard_filters_enabled": d.get("dashboard_filters_enabled"),
                "is_draft": d.get("is_draft"),
                "updated_at": d.get("updated_at"),
                "created_at": d.get("created_at"),
                "version": d.get("version"),
                "color_palette": d.get("color_palette"),
                "run_as_role": d.get("run_as_role"),
                "run_as_service_principal_id": d.get("run_as_service_principal_id"),
                "data_source_id": d.get("data_source_id"),
                "warehouse_id": d.get("warehouse_id"),
                "is_favorite": d.get("is_favorite"),
                # Flatten nested 'options'
                "folder_parent": d.get("options", {}).get("parent"),
                "folder_node_status": d.get("options", {}).get("folder_node_status"),
                "folder_node_internal_name": d.get("options", {}).get("folder_node_internal_name"),
                # Flatten nested 'user'
                "user_name": d.get("user", {}).get("name"),
                "user_email": d.get("user", {}).get("email"),
                # Flatten tags list into comma-separated string
                "tags": ",".join(d.get("tags", [])) if d.get("tags") else None
            }
            flat_dashboards.append(record)


        if dashboards:
            self._write_table(full_table_name=results_table, data_to_write=flat_dashboards, primary_key="id", schema=schema, service_principal=service_principal)
            print(f"Data written to table {results_table}")
        else:
            print("No data to write")      

    
    def create_dashboard(self, name, service_principal: bool = False):
        data = {"name": name}
        return self._post("/api/2.1/preview/sql/dashboards", data, service_principal)

    
    def delete_dashboard(self, dashboard_id, service_principal: bool = False):
        return self._delete(f"/api/2.1/preview/sql/dashboards/{dashboard_id}", service_principal)


class WorkspacesAPI(DatabricksBaseAPI):
    
    def list_workspace_items(self, path, service_principal: bool = False):
        return self._get(f"/api/2.0/workspace/list?path={path}", service_principal)
    
    def write_table(self, catalog_name: str = 'platform_admin', schema_name: str = 'metadata', table_name: str = 'workspace_items', service_principal: bool = False):
 
        results_table = f"{catalog_name}.{schema_name}.{table_name}"

        workspace_items = self.list_workspace_items(path='/',service_principal=service_principal)

        flat_objects = []
        for obj in workspace_items["objects"]:
            record = {
                "object_type": obj.get("object_type"),
                "path": obj.get("path"),
                "object_id": obj.get("object_id"),
                "resource_id": obj.get("resource_id"),
                # Only present for notebooks
                "language": obj.get("language"),
                "created_at": obj.get("created_at"),
                "modified_at": obj.get("modified_at")
            }
            flat_objects.append(record)            

        if workspace_items:
            self._write_table(full_table_name=results_table, data_to_write=flat_objects, primary_key="object_id", schema=None, service_principal=service_principal)
            print(f"Data written to table {results_table}")
        else:
            print("No data to write")    

    
    def create_workspace_directory(self, path, service_principal: bool = False):
        data = {"path": path, "overwrite": True}
        return self._post("/api/2.1/workspace/mkdirs", data, service_principal)

    
    def delete_workspace_item(self, path, recursive=False, service_principal: bool = False):
        return self._post("/api/2.1/workspace/delete", {"path": path, "recursive": recursive}, service_principal)


class RecipientsAPI(DatabricksBaseAPI):
    
    def list_recipients(self, service_principal: bool = False):
        return self._get("/api/2.1/unity-catalog/recipients", service_principal)

    def write_table(self, catalog_name: str = 'platform_admin', schema_name: str = 'metadata', table_name: str = 'recipients', service_principal: bool = False):

        results_table = f"{catalog_name}.{schema_name}.{table_name}"

        recipients = self.list_recipients(service_principal=service_principal)

        recipients_schema = StructType([
            StructField("id", StringType(), True),
            StructField("name", StringType(), True),
            StructField("full_name", StringType(), True),
            StructField("authentication_type", StringType(), True),
            StructField("data_recipient_global_metastore_id", StringType(), True),
            StructField("owner", StringType(), True),
            StructField("comment", StringType(), True),
            StructField("created_at", LongType(), True),
            StructField("created_by", StringType(), True),
            StructField("updated_at", LongType(), True),
            StructField("updated_by", StringType(), True),
            StructField("cloud", StringType(), True),
            StructField("region", StringType(), True),
            StructField("metastore_id", StringType(), True),
            StructField("securable_type", StringType(), True),
            StructField("securable_kind", StringType(), True),
            StructField("prop_name", StringType(), True),
            StructField("prop_account_id", StringType(), True),
            StructField("prop_metastore_id", StringType(), True)
        ])

        flat_recipients = []
        for r in recipients["recipients"]:
            props = r.get("properties_kvpairs", {}).get("properties", {})
            record = {
                "id": r.get("id"),
                "name": r.get("name"),
                "full_name": r.get("full_name"),
                "authentication_type": r.get("authentication_type"),
                "data_recipient_global_metastore_id": r.get("data_recipient_global_metastore_id"),
                "owner": r.get("owner"),
                "comment": r.get("comment"),
                "created_at": r.get("created_at"),
                "created_by": r.get("created_by"),
                "updated_at": r.get("updated_at"),
                "updated_by": r.get("updated_by"),
                "cloud": r.get("cloud"),
                "region": r.get("region"),
                "metastore_id": r.get("metastore_id"),
                "securable_type": r.get("securable_type"),
                "securable_kind": r.get("securable_kind"),
                # Flatten nested properties
                "prop_name": props.get("databricks.name"),
                "prop_account_id": props.get("databricks.accountId"),
                "prop_metastore_id": props.get("databricks.metastoreId")
            }
            flat_recipients.append(record)


        if recipients:
            self._write_table(full_table_name=results_table, data_to_write=flat_recipients, primary_key="id", schema=recipients_schema, service_principal=service_principal)
            print(f"Data written to table {results_table}")
        else:
            print("No data to write")
    
    def create_recipient(self, name, sharing_type, service_principal: bool = False):
        data = {
            "name": name,
            "sharing_type": sharing_type
        }
        return self._post("/api/2.1/unity-catalog/recipients", data, service_principal)

    
    def delete_recipient(self, recipient_name, service_principal: bool = False):
        return self._delete(f"/api/2.1/unity-catalog/recipients/{recipient_name}", service_principal)


class ObjectPermissionsAPI(DatabricksBaseAPI):
    
    def get_object_permissions(self, object_id, service_principal: bool = False):
        return self._get(f"/api/2.1/permissions/{object_id}", service_principal)

    
    def set_object_permissions(self, object_id, permissions, service_principal: bool = False):
        data = {"access_control_list": permissions}
        return self._put(f"/api/2.1/permissions/{object_id}", data, service_principal)

    
    def update_object_permissions(self, object_id, permissions, service_principal: bool = False):
        data = {"access_control_list": permissions}
        return self._patch(f"/api/2.1/permissions/{object_id}", data, service_principal)

class SecretsAPI(DatabricksBaseAPI):

    def list_scopes(self, service_principal: bool = False):
        """
        GET /api/2.0/secrets/scopes/list
        Lists all secret scopes in the workspace.
        """
        return self._get("/api/2.0/secrets/scopes/list", service_principal=service_principal)

    def create_scope(
        self,
        scope: str,
        initial_manage_principal: str = None,
        scope_backend_type: str = None,
        backend_azure_keyvault: dict = None,
        service_principal: bool = False,
    ):
        """
        POST /api/2.0/secrets/scopes/create
        Creates a new secret scope. Optionally backed by Azure Key Vault.
        """
        data = {"scope": scope}
        if initial_manage_principal:
            data["initial_manage_principal"] = initial_manage_principal
        if scope_backend_type:
            data["scope_backend_type"] = scope_backend_type
        if backend_azure_keyvault:
            data["backend_azure_keyvault"] = backend_azure_keyvault
        return self._post("/api/2.0/secrets/scopes/create", data, service_principal)

    def delete_scope(self, scope: str, service_principal: bool = False):
        """
        POST /api/2.0/secrets/scopes/delete
        Deletes a secret scope and all its secrets + ACLs.
        """
        return self._post("/api/2.0/secrets/scopes/delete", {"scope": scope}, service_principal)

    # Secret ACLs

    def list_acls(self, scope: str, service_principal: bool = False):
        """
        GET /api/2.0/secrets/acls/list?scope={scope}
        Lists ACLs for a given secret scope.
        """
        return self._get("/api/2.0/secrets/acls/list", params={"scope": scope}, service_principal=service_principal)

    def get_acl(self, scope: str, principal: str, service_principal: bool = False):
        """
        GET /api/2.0/secrets/acls/get?scope={scope}&principal={principal}
        Returns the ACL entry for a specific principal.
        """
        return self._get(
            "/api/2.0/secrets/acls/get",
            params={"scope": scope, "principal": principal},
            service_principal=service_principal,
        )

    def delete_acl(self, scope: str, principal: str, service_principal: bool = False):
        """
        POST /api/2.0/secrets/acls/delete
        Removes an ACL for a given principal.
        """
        data = {"scope": scope, "principal": principal}
        return self._post("/api/2.0/secrets/acls/delete", data, service_principal)

    def put_acl(self, scope: str, principal: str, permission: str, service_principal: bool = False):
        """
        POST /api/2.0/secrets/acls/put
        Creates or updates an ACL for the given principal.
        Permission must be one of READ|WRITE|MANAGE.
        """
        data = {"scope": scope, "principal": principal, "permission": permission}
        return self._post("/api/2.0/secrets/acls/put", data, service_principal)

    # Secrets

    def list_secrets(self, scope: str, service_principal: bool = False):
        """
        GET /api/2.0/secrets/list?scope={scope}
        Lists all secret keys (metadata only) in a scope.
        """
        return self._get("/api/2.0/secrets/list", params={"scope": scope}, service_principal=service_principal)

    def get_secret(self, scope: str, key: str, service_principal: bool = False):
        """
        GET /api/2.0/secrets/get?scope={scope}&key={key}
        Retrieves the Base64‐encoded value of a secret.
        """
        return self._get(
            "/api/2.0/secrets/get",
            params={"scope": scope, "key": key},
            service_principal=service_principal,
        )

    def delete_secret(self, scope: str, key: str, service_principal: bool = False):
        """
        POST /api/2.0/secrets/delete
        Deletes a secret from the given scope.
        """
        data = {"scope": scope, "key": key}
        return self._post("/api/2.0/secrets/delete", data, service_principal)

    def put_secret(
        self,
        scope: str,
        key: str,
        string_value: str = None,
        bytes_value: str = None,
        service_principal: bool = False,
    ):
        """
        POST /api/2.0/secrets/put
        Inserts or updates a secret. Must supply exactly one of string_value or bytes_value.
        """
        data = {"scope": scope, "key": key}
        if string_value and bytes_value:
            raise ValueError("Provide only one of string_value or bytes_value.")
        if string_value:
            data["string_value"] = string_value
        elif bytes_value:
            data["bytes_value"] = bytes_value
        else:
            raise ValueError("Must provide string_value or bytes_value.")
        return self._post("/api/2.0/secrets/put", data, service_principal)

    def write_table(self, catalog_name: str = 'platform_admin', schema_name: str = 'metadata', table_name: str = 'secrets_scopes', service_principal: bool = False):

        results_table = f"{catalog_name}.{schema_name}.{table_name}"

        scopes = self.list_scopes(service_principal=service_principal)

        flattened = []
        for scope in scopes['scopes']:
            scope_name = scope.get('name')
            backend_type = scope.get('backend_type')
            resource_id = scope.get('keyvault_metadata', {}).get('resource_id')
            dns_name = scope.get('keyvault_metadata', {}).get('dns_name')

            try:
                secrets = self.list_secrets(scope=scope_name, service_principal=service_principal)

                for secret in secrets.get('secrets', []):
                    flattened.append({
                        'scope_name': scope_name,
                        'backend_type': backend_type,
                        'resource_id': resource_id,
                        'dns_name': dns_name,
                        'secret_key': secret.get('key'),
                        'last_updated_timestamp': secret.get('last_updated_timestamp')
                    })
            except:
                print(f"ERROR: No access to scope {scope_name}")
                pass

        # Define schema for the combined data
        schema = StructType([
            StructField("scope_name", StringType(), True),
            StructField("backend_type", StringType(), True),
            StructField("resource_id", StringType(), True),
            StructField("dns_name", StringType(), True),
            StructField("secret_key", StringType(), True),
            StructField("last_updated_timestamp", LongType(), True)
        ])

        if flattened:
            self._write_table(full_table_name=results_table, data_to_write = flattened, primary_key = ["scope_name", "secret_key"], schema = schema, service_principal=service_principal, add_workspace = True)
            print(f"Data written to table {results_table}")
        else:
            print("No data to write")

    def write_acls_table(self, catalog_name: str = 'platform_admin', schema_name: str = 'metadata', table_name: str = 'secret_scopes_acls', service_principal: bool = False):

        results_table = f"{catalog_name}.{schema_name}.{table_name}"

        scopes = self.list_scopes(service_principal=service_principal)

        flattened = []
        for scope in scopes['scopes']:
            scope_name = scope.get('name')
            backend_type = scope.get('backend_type')
            resource_id = scope.get('keyvault_metadata', {}).get('resource_id')
            dns_name = scope.get('keyvault_metadata', {}).get('dns_name')

            try:
                acls = self.list_acls(scope=scope_name, service_principal=service_principal)

                for acl in acls.get('items', []):
                    flattened.append({
                        'scope_name': scope_name,
                        'backend_type': backend_type,
                        'resource_id': resource_id,
                        'dns_name': dns_name,
                        'principal': acl.get('principal'),
                        'permission': acl.get('permission')
                    })

            except Exception as e:
                print(f"ERROR: No access to ACLs for scope {scope_name} — {e}")
                pass

        # Define schema for ACL data
        schema = StructType([
            StructField("scope_name", StringType(), True),
            StructField("backend_type", StringType(), True),
            StructField("resource_id", StringType(), True),
            StructField("dns_name", StringType(), True),
            StructField("principal", StringType(), True),
            StructField("permission", StringType(), True)
        ])

        if flattened:
            self._write_table(
                full_table_name=results_table,
                data_to_write=flattened,
                primary_key=["scope_name", "principal", "permission"],
                schema=schema,
                service_principal=service_principal,
                add_workspace=True
            )
            print(f"ACL data written to table {results_table}")
        else:
            print("No ACL data to write")

    def update_repo(self, repo_id, branch=None, tag=None, service_principal: bool = False):
        data = {}
        if branch:
            data["branch"] = branch
        if tag:
            data["tag"] = tag
        return self._patch(f"/api/2.0/repos/{repo_id}", data, service_principal)        

class ReposAPI(DatabricksBaseAPI):

    def create_repo(self, url, provider, path, service_principal: bool = False):
        data = {
            "url": url,
            "provider": provider,
            "path": path
        }
        return self._post("/api/2.0/repos", data, service_principal)

    def get_repo(self, repo_id, service_principal: bool = False):
        return self._get(f"/api/2.0/repos/{repo_id}", service_principal=service_principal)

    def list_repos(self, path_prefix=None, service_principal: bool = False):
        params = {}
        if path_prefix:
            params["path_prefix"] = path_prefix
        return self._get("/api/2.0/repos", params=params, service_principal=service_principal)
    
    def write_table(self, catalog_name: str = 'platform_admin', schema_name: str = 'metadata', table_name: str = 'repos', service_principal: bool = False):

        results_table = f"{catalog_name}.{schema_name}.{table_name}"

        repos = self.list_repos(service_principal=service_principal)

        repos_schema = StructType([
            StructField("id", LongType(), True),
            StructField("path", StringType(), True),
            StructField("url", StringType(), True),
            StructField("provider", StringType(), True),
            StructField("branch", StringType(), True),
            StructField("head_commit_id", StringType(), True)
        ])

        flat_repos = []
        for repo in repos["repos"]:
            record = {
                "id": repo.get("id"),
                "path": repo.get("path"),
                "url": repo.get("url"),
                "provider": repo.get("provider"),
                "branch": repo.get("branch"),
                "head_commit_id": repo.get("head_commit_id")
            }
            flat_repos.append(record)

        if repos:
            self._write_table(full_table_name=results_table, data_to_write = flat_repos, primary_key = "id", schema = repos_schema, service_principal=service_principal)
            print(f"Data written to table {results_table}")
        else:
            print("No data to write")

    def update_repo(self, repo_id, branch=None, tag=None, service_principal: bool = False):
        data = {}
        if branch:
            data["branch"] = branch
        if tag:
            data["tag"] = tag
        return self._patch(f"/api/2.0/repos/{repo_id}", data, service_principal)

    def delete_repo(self, repo_id, service_principal: bool = False):
        return self._delete(f"/api/2.0/repos/{repo_id}", service_principal)

    # Permissions API
    def set_repo_permissions(self, repo_id, access_control_list, service_principal: bool = False):
        data = {
            "access_control_list": access_control_list
        }
        return self._post(f"/api/2.0/permissions/repos/{repo_id}", data, service_principal)

    def update_repo_permissions(self, repo_id, access_control_list, service_principal: bool = False):
        data = {
            "access_control_list": access_control_list
        }
        return self._patch(f"/api/2.0/permissions/repos/{repo_id}", data, service_principal)

    def get_repo_permissions(self, repo_id, service_principal: bool = False):
        return self._get(f"/api/2.0/permissions/repos/{repo_id}", service_principal=service_principal)

    def get_repo_permission_levels(self, repo_id, service_principal: bool = False):
        return self._get(f"/api/2.0/permissions/repos/{repo_id}/permissionLevels", service_principal=service_principal)

class ServicePrincipalsAPI(DatabricksBaseAPI):
    """
    Wrapper for the Azure Databricks Service Principals (SCIM) REST API.
    Endpoints live under /api/2.0/preview/scim/v2/ServicePrincipals
    """

    def list_service_principals(
        self,
        filter: str = None,
        start_index: int = None,
        count: int = None,
        attributes: str = None,
        excluded_attributes: str = None,
        service_principal: bool = False
    ):
        """
        GET /api/2.0/preview/scim/v2/ServicePrincipals
        Lists service principals in the workspace.

        :param filter: SCIM filter, e.g. 'displayName eq "my-app"'
        :param start_index: 1-based index of first result to return
        :param count: max number of results to return
        :param attributes: comma-separated list of attributes to include
        :param excluded_attributes: comma-separated list of attributes to exclude
        """
        params = {}
        if filter is not None:
            params["filter"] = filter
        if start_index is not None:
            params["startIndex"] = start_index
        if count is not None:
            params["count"] = count
        if attributes is not None:
            params["attributes"] = attributes
        if excluded_attributes is not None:
            params["excludedAttributes"] = excluded_attributes

        return self._get(
            "/api/2.0/preview/scim/v2/ServicePrincipals",
            params=params,
            service_principal=service_principal
        )

    def write_table(self, catalog_name: str = 'platform_admin', schema_name: str = 'metadata', table_name: str = 'service_principals', service_principal: bool = False):

        results_table = f"{catalog_name}.{schema_name}.{table_name}"

        service_principals = self.list_service_principals(service_principal=service_principal)

        resources = service_principals["Resources"]

        flat_data = []
        for principal in resources:
            flat_record = {
                "displayName": principal.get("displayName"),
                "id": principal.get("id"),
                "applicationId": principal.get("applicationId"),
                "active": principal.get("active"),
                "externalId": principal.get("externalId"),
                "entitlements": [e["value"] for e in principal.get("entitlements", [])],
                "groups": [g["display"] for g in principal.get("groups", [])]
            }
            flat_data.append(flat_record)

        if service_principals:
            self._write_table(full_table_name=results_table, data_to_write = flat_data, primary_key = "displayName", schema = None, service_principal=service_principal)
            print(f"Data written to table {results_table}")
        else:
            print("No data to write")          

    def create_service_principal(
        self,
        display_name: str,
        external_id: str = None,
        active: bool = None,
        entitlements: list = None,
        groups: list = None,
        service_principal: bool = False
    ):
        """
        POST /api/2.0/preview/scim/v2/ServicePrincipals
        Creates a new service principal.

        :param display_name: required human-readable name
        :param external_id: optional external identifier
        :param active: optional flag whether SP is active
        :param entitlements: list of dicts, e.g. [{"value": "allow-cluster-create"}]
        :param groups: list of dicts, e.g. [{"value": "group-uuid"}]
        """
        payload = {
            "schemas": ["urn:ietf:params:scim:schemas:core:2.0:ServicePrincipal"],
            "displayName": display_name
        }
        if external_id is not None:
            payload["externalId"] = external_id
        if active is not None:
            payload["active"] = active
        if entitlements is not None:
            payload["entitlements"] = entitlements
        if groups is not None:
            payload["groups"] = groups

        return self._post(
            "/api/2.0/preview/scim/v2/ServicePrincipals",
            json=payload,
            service_principal=service_principal
        )

    def get_service_principal(
        self,
        sp_id: str,
        service_principal: bool = False
    ):
        """
        GET /api/2.0/preview/scim/v2/ServicePrincipals/{sp_id}
        Retrieves a single service principal by its ID.
        """
        endpoint = f"/api/2.0/preview/scim/v2/ServicePrincipals/{sp_id}"
        return self._get(endpoint, service_principal=service_principal)

    def update_service_principal(
        self,
        sp_id: str,
        operations: list,
        service_principal: bool = False
    ):
        """
        PATCH /api/2.0/preview/scim/v2/ServicePrincipals/{sp_id}
        Performs a SCIM patch to update the service principal.

        :param operations: list of SCIM patch ops, e.g.
            [{"op": "replace", "path": "displayName", "value": "New Name"}]
        """
        endpoint = f"/api/2.0/preview/scim/v2/ServicePrincipals/{sp_id}"
        payload = {
            "schemas": ["urn:ietf:params:scim:api:messages:2.0:PatchOp"],
            "Operations": operations
        }
        return self._patch(endpoint, json=payload, service_principal=service_principal)

    def replace_service_principal(
        self,
        sp_id: str,
        display_name: str,
        external_id: str = None,
        active: bool = None,
        entitlements: list = None,
        groups: list = None,
        roles: list = None,
        service_principal: bool = False
    ):
        """
        PUT /api/2.0/preview/scim/v2/ServicePrincipals/{sp_id}
        Replaces an existing service principal. All provided attributes
        overwrite the existing resource.

        :param sp_id: the service principal ID
        :param display_name: required human-readable name
        :param external_id: optional external identifier
        :param active: optional flag whether SP is active
        :param entitlements: optional list of dicts [{"value": "..."}]
        :param groups: optional list of dicts [{"value": "group-uuid"}]
        :param roles: optional list of dicts [{"value": "role-arn"}]
        """
        endpoint = f"/api/2.0/preview/scim/v2/ServicePrincipals/{sp_id}"
        payload = {
            "schemas": ["urn:ietf:params:scim:schemas:core:2.0:ServicePrincipal"],
            "displayName": display_name
        }
        if external_id is not None:
            payload["externalId"] = external_id
        if active is not None:
            payload["active"] = active
        if entitlements is not None:
            payload["entitlements"] = entitlements
        if groups is not None:
            payload["groups"] = groups
        if roles is not None:
            payload["roles"] = roles

        return self._put(
            endpoint,
            json=payload,
            service_principal=service_principal
        )

    def delete_service_principal(
        self,
        sp_id: str,
        service_principal: bool = False
    ):
        """
        DELETE /api/2.0/preview/scim/v2/ServicePrincipals/{sp_id}
        Deletes a service principal by ID.
        """
        endpoint = f"/api/2.0/preview/scim/v2/ServicePrincipals/{sp_id}"
        return self._delete(endpoint, service_principal=service_principal)
    
    # users.py

class UsersAPI(DatabricksBaseAPI):
    """
    Wrapper for the Azure Databricks Users (SCIM) REST API.
    Endpoints live under /api/2.0/preview/scim/v2/Users
    """

    def list_users(
        self,
        filter: str = None,
        start_index: int = None,
        count: int = None,
        attributes: str = None,
        excluded_attributes: str = None,
        service_principal: bool = False
    ):
        """
        GET /api/2.0/preview/scim/v2/Users
        Lists users in the workspace.

        :param filter: SCIM filter expression, e.g. 'userName eq "alice@example.com"'
        :param start_index: 1-based index of first result to return
        :param count: max number of results to return
        :param attributes: comma-separated list of attributes to include
        :param excluded_attributes: comma-separated list of attributes to exclude
        """
        params = {}
        if filter is not None:
            params["filter"] = filter
        if start_index is not None:
            params["startIndex"] = start_index
        if count is not None:
            params["count"] = count
        if attributes is not None:
            params["attributes"] = attributes
        if excluded_attributes is not None:
            params["excludedAttributes"] = excluded_attributes

        return self._get(
            "/api/2.0/preview/scim/v2/Users",
            params=params or None,
            service_principal=service_principal
        )

    def write_table(self, catalog_name: str = 'platform_admin', schema_name: str = 'metadata', table_name: str = 'users', service_principal: bool = False):

        results_table = f"{catalog_name}.{schema_name}.{table_name}"

        users = self.list_users(service_principal=service_principal)

        users_schema = StructType([
            StructField("displayName", StringType(), True),
            StructField("id", StringType(), True),
            StructField("applicationId", StringType(), True),
            StructField("externalId", StringType(), True),
            StructField("active", BooleanType(), True),
            StructField("entitlements", ArrayType(StringType()), True),
            StructField("groups", ArrayType(StringType()), True)
        ])

        flat_users = []
        for user in users["Resources"]:
            record = {
                "displayName": user.get("displayName"),
                "id": user.get("id"),
                "applicationId": user.get("applicationId"),
                "externalId": user.get("externalId"),
                "active": user.get("active"),
                # Flatten entitlements into a list of strings
                "entitlements": [e["value"] for e in user.get("entitlements", [])],
                # Flatten groups into a list of group display names
                "groups": [g["display"] for g in user.get("groups", [])]
            }
            flat_users.append(record)

        if users:
            self._write_table(full_table_name=results_table, data_to_write = flat_users, primary_key = "id", schema = users_schema, service_principal=service_principal)
            print(f"Data written to table {results_table}")
        else:
            print("No data to write")            

    def create_user(
        self,
        user_name: str,
        display_name: str = None,
        active: bool = None,
        external_id: str = None,
        entitlements: list = None,
        roles: list = None,
        groups: list = None,
        service_principal: bool = False
    ):
        """
        POST /api/2.0/preview/scim/v2/Users
        Creates a new user.

        :param user_name: required unique user identifier (usually an email)
        :param display_name: optional human-readable full name
        :param active: optional flag whether the user is active
        :param external_id: optional external identifier
        :param entitlements: optional list of dicts, e.g. [{"value": "allow-cluster-create"}]
        :param roles: optional list of dicts, e.g. [{"value": "role-uuid"}]
        :param groups: optional list of dicts, e.g. [{"value": "group-uuid"}]
        """
        payload = {
            "schemas": ["urn:ietf:params:scim:schemas:core:2.0:User"],
            "userName": user_name
        }
        if display_name is not None:
            payload["displayName"] = display_name
        if active is not None:
            payload["active"] = active
        if external_id is not None:
            payload["externalId"] = external_id
        if entitlements:
            payload["entitlements"] = entitlements
        if roles:
            payload["roles"] = roles
        if groups:
            payload["groups"] = groups

        return self._post(
            "/api/2.0/preview/scim/v2/Users",
            json=payload,
            service_principal=service_principal
        )

    def get_user(
        self,
        user_id: str,
        service_principal: bool = False
    ):
        """
        GET /api/2.0/preview/scim/v2/Users/{user_id}
        Retrieves a user by its ID.
        """
        endpoint = f"/api/2.0/preview/scim/v2/Users/{user_id}"
        return self._get(endpoint, service_principal=service_principal)

    def update_user(
        self,
        user_id: str,
        operations: list,
        service_principal: bool = False
    ):
        """
        PATCH /api/2.0/preview/scim/v2/Users/{user_id}
        Performs a SCIM patch to update the user.

        :param operations: list of SCIM patch operations, e.g.:
                           [{"op": "replace", "path": "displayName", "value": "Alice A."}]
        """
        endpoint = f"/api/2.0/preview/scim/v2/Users/{user_id}"
        payload = {
            "schemas": ["urn:ietf:params:scim:api:messages:2.0:PatchOp"],
            "Operations": operations
        }
        return self._patch(
            endpoint,
            json=payload,
            service_principal=service_principal
        )

    def replace_user(
        self,
        user_id: str,
        user_name: str,
        display_name: str = None,
        active: bool = None,
        external_id: str = None,
        entitlements: list = None,
        roles: list = None,
        groups: list = None,
        service_principal: bool = False
    ):
        """
        PUT /api/2.0/preview/scim/v2/Users/{user_id}
        Replaces an existing user. All provided attributes overwrite the resource.

        :param user_id: the ID of the user to replace
        :param user_name: required unique userName
        :param display_name: optional full name
        :param active: optional active flag
        :param external_id: optional external ID
        :param entitlements: optional list of dicts [{"value": "..."}]
        :param roles: optional list of dicts [{"value": "..."}]
        :param groups: optional list of dicts [{"value": "..."}]
        """
        endpoint = f"/api/2.0/preview/scim/v2/Users/{user_id}"
        payload = {
            "schemas": ["urn:ietf:params:scim:schemas:core:2.0:User"],
            "userName": user_name
        }
        if display_name is not None:
            payload["displayName"] = display_name
        if active is not None:
            payload["active"] = active
        if external_id is not None:
            payload["externalId"] = external_id
        if entitlements is not None:
            payload["entitlements"] = entitlements
        if roles is not None:
            payload["roles"] = roles
        if groups is not None:
            payload["groups"] = groups

        return self._put(
            endpoint,
            json=payload,
            service_principal=service_principal
        )

    def delete_user(
        self,
        user_id: str,
        service_principal: bool = False
    ):
        """
        DELETE /api/2.0/preview/scim/v2/Users/{user_id}
        Deletes a user by ID.
        """
        endpoint = f"/api/2.0/preview/scim/v2/Users/{user_id}"
        return self._delete(endpoint, service_principal=service_principal)

# schemas_api.py


class SchemasAPI(DatabricksBaseAPI):
    """
    Wrapper for the Unity Catalog Schemas REST API.
    Endpoints are under /api/2.1/unity-catalog/schemas.
    """

    def list_schemas(
        self,
        catalog_name: str,
        schema_name: str = None,
        service_principal: bool = False
    ):
        """
        GET /api/2.1/unity-catalog/schemas
        Lists all schemas in a Unity Catalog catalog.

        :param catalog_name: name of the parent catalog (required)
        :param schema_name: optional filter by a specific schema name
        """
        params = {"catalog_name": catalog_name}
        if schema_name is not None:
            params["schema_name"] = schema_name

        return self._get(
            "/api/2.1/unity-catalog/schemas",
            params=params,
            service_principal=service_principal
        )

    def write_table(self, catalog_name: str = 'platform_admin', schema_name: str = 'metadata', table_name: str = 'schemas', service_principal: bool = False):

        results_table = f"{catalog_name}.{schema_name}.{table_name}"

        # needs to be updated to pull list of catalogs and then append schemas from loop of catalogs

        all_schemas = []

        my_catalogs = Unity_Catalog_API(self.DATABRICKS_INSTANCE,self.TOKEN)
        catalogs = my_catalogs.list_catalog(service_principal=service_principal)

        for catalog in catalogs['catalogs']:
            catalog_name = catalog['name']
            if catalog['securable_kind'] != 'CATALOG_DELTASHARING':
                print(f"Catalog name: {catalog_name}")
                schemas = self.list_schemas(catalog_name=catalog_name,service_principal=service_principal)
                all_schemas.extend(schemas['schemas'])

        if len(all_schemas) > 0:
            self._write_table(full_table_name=results_table, data_to_write = all_schemas, primary_key = "schema_id", schema = None, service_principal=service_principal)
            print(f"Data written to table {results_table}")
        else:
            print("No data to write")            

    def get_schema(
        self,
        full_name: str,
        service_principal: bool = False
    ):
        """
        GET /api/2.1/unity-catalog/schemas/{full_name}
        Retrieves metadata for one schema.

        :param full_name: fully-qualified schema name: <catalog>.<schema>
        """
        endpoint = f"/api/2.1/unity-catalog/schemas/{full_name}"
        return self._get(endpoint, service_principal=service_principal)

    def create_schema(
        self,
        catalog_name: str,
        schema_name: str,
        comment: str = None,
        properties: dict = None,
        service_principal: bool = False
    ):
        """
        POST /api/2.1/unity-catalog/schemas
        Creates a new schema in a Unity Catalog catalog.

        :param catalog_name: parent catalog name (required)
        :param schema_name: new schema name (required)
        :param comment: optional descriptive text
        :param properties: optional key/value metadata
        """
        data = {
            "catalog_name": catalog_name,
            "schema_name": schema_name
        }
        if comment is not None:
            data["comment"] = comment
        if properties is not None:
            data["properties"] = properties

        return self._post(
            "/api/2.1/unity-catalog/schemas",
            data,
            service_principal=service_principal
        )

    def update_schema(
        self,
        full_name: str,
        comment: str = None,
        owner: str = None,
        properties: dict = None,
        service_principal: bool = False
    ):
        """
        PATCH /api/2.1/unity-catalog/schemas/{full_name}
        Updates metadata on an existing schema.

        :param full_name: fully-qualified schema name: <catalog>.<schema>
        :param comment: optional new comment
        :param owner: optional new owner (principal)
        :param properties: optional dict of properties to overwrite
        """
        data = {}
        if comment is not None:
            data["comment"] = comment
        if owner is not None:
            data["owner"] = owner
        if properties is not None:
            data["properties"] = properties

        endpoint = f"/api/2.1/unity-catalog/schemas/{full_name}"
        return self._patch(
            endpoint,
            data,
            service_principal=service_principal
        )

    def delete_schema(
        self,
        full_name: str,
        force: bool = False,
        service_principal: bool = False
    ):
        """
        DELETE /api/2.1/unity-catalog/schemas/{full_name}
        Deletes a schema, optionally cascading.

        :param full_name: fully-qualified schema name: <catalog>.<schema>
        :param force: if True, cascade-drop dependent objects
        """
        endpoint = f"/api/2.1/unity-catalog/schemas/{full_name}"
        if force:
            endpoint += "?force=true"

        return self._delete(endpoint, service_principal=service_principal)

    # Permissions

    def get_permission_levels(
        self,
        service_principal: bool = False
    ):
        """
        GET /api/2.1/unity-catalog/schemas/permissionLevels
        Lists the valid permission levels for schemas.
        """
        return self._get(
            "/api/2.1/unity-catalog/schemas/permissionLevels",
            service_principal=service_principal
        )

    def get_schema_permissions(
        self,
        full_name: str,
        service_principal: bool = False
    ):
        """
        GET /api/2.1/unity-catalog/schemas/{full_name}/permissions
        Retrieves the ACL for a schema.
        """
        endpoint = f"/api/2.1/unity-catalog/schemas/{full_name}/permissions"
        return self._get(endpoint, service_principal=service_principal)

    def update_schema_permissions(
        self,
        full_name: str,
        access_control_list: list,
        service_principal: bool = False
    ):
        """
        PATCH /api/2.1/unity-catalog/schemas/{full_name}/permissions
        Merges new entries into the existing ACL for a schema.

        :param access_control_list: list of permission dicts,
          e.g. [{"principal": "user@example.com", "permission": "SELECT"}]
        """
        endpoint = f"/api/2.1/unity-catalog/schemas/{full_name}/permissions"
        data = {"access_control_list": access_control_list}
        return self._patch(endpoint, data, service_principal=service_principal)

    def set_schema_permissions(
        self,
        full_name: str,
        access_control_list: list,
        service_principal: bool = False
    ):
        """
        POST /api/2.1/unity-catalog/schemas/{full_name}/permissions
        Overwrites the ACL for a schema.

        :param access_control_list: list of permission dicts,
          e.g. [{"principal": "user@example.com", "permission": "SELECT"}]
        """
        endpoint = f"/api/2.1/unity-catalog/schemas/{full_name}/permissions"
        data = {"access_control_list": access_control_list}
        return self._post(endpoint, data, service_principal=service_principal)

class ServicePrincipalSecretsProxyAPI(DatabricksBaseAPI):
    """
    Wrapper for the Service Principal Secrets Proxy API.
    Endpoints live under /api/2.0/accounts/servicePrincipals/{service_principal_id}/credentials/secrets
    """

    def list_secrets(
        self,
        service_principal_id: str,
        page_token: str = None,
        page_size: int = None,
        service_principal: bool = False
    ) -> dict:
        """
        GET /api/2.0/accounts/servicePrincipals/{service_principal_id}/credentials/secrets
        Lists all secrets associated with the given service principal. Does not return secret values.

        :param service_principal_id: the Databricks service principal UUID
        :param page_token: opaque token from a previous response to fetch the next page
        :param page_size: max number of entries to return (default 100)
        :param service_principal: whether to use service-principal auth headers
        """
        endpoint = f"/api/2.0/accounts/servicePrincipals/{service_principal_id}/credentials/secrets"
        params = {}
        if page_token is not None:
            params["page_token"] = page_token
        if page_size is not None:
            params["page_size"] = page_size

        return self._get(endpoint, params=params or None, service_principal=service_principal)
    
    
    def principal_Oauth_token(
        self,
        account_id:str,
        service_principal: bool = False
    ) -> dict:
        # API endpoint
        """
        POST /api/2.0/accounts/{account_id}/servicePrincipals/{service_principal_id}/credentials/secrets
        :param service_principal_id: the Databricks service principal UUID this number and not ID
        :param account_id: the Databricks account ID
        """
        # JSON payload
        payload = {
                    "lifetime": "31536000s"
                }
        
        if not payload:
            raise Exception("Payload is required.")
        else:
          return  self._post(
              "/api/2.0/accounts/{account_id}/servicePrincipals/{service_principal_id}/credentials/secrets",
              data=payload,
              service_principal=service_principal)


    def write_table(self, catalog_name: str = 'platform_admin', schema_name: str = 'metadata', table_name: str = 'service_principal_secrets', service_principal: bool = False):

        results_table = f"{catalog_name}.{schema_name}.{table_name}"

        schema = StructType([
            StructField("displayName", StringType(), True),
            StructField("id", StringType(), True),
            StructField("applicationId", StringType(), True),
            StructField("active", BooleanType(), True),
            StructField("groups", ArrayType(StringType()), True),
            StructField("entitlements", ArrayType(
                StructType([
                    StructField("value", StringType(), True)
                ])
            ), True)
        ])

        my_principals = ServicePrincipalsAPI(self.DATABRICKS_INSTANCE,self.TOKEN)
        principals_list = my_principals.list_service_principals(service_principal=service_principal)

        secret_list = []

        for principal in principals_list["Resources"]:
            secrets = self.list_secrets(principal["id"])
            if secrets:
                print(secrets)
                secret_list.append(self.list_secrets(principal["id"], service_principal=service_principal))

        print('Final: ',secret_list)

        if principals_list:
            self._write_table(full_table_name=results_table, data_to_write = secret_list, primary_key = "id", schema = schema, service_principal=service_principal)
            print(f"Data written to table {results_table}")
        else:
            print("No data to write")    


    def create_secrets(
        self,
        service_principal_id: str,
        secrets: list[dict],
        service_principal: bool = False
    ) -> dict:
        """
        POST /api/2.0/accounts/servicePrincipals/{service_principal_id}/credentials/secrets
        Creates one or more new secret references for the given service principal.

        :param service_principal_id: the Databricks service principal UUID
        :param secrets: list of secret objects, e.g.
                        [{"scope": "my-scope", "key": "my-key"}, ...]
        :param service_principal: whether to use service-principal auth headers
        """
        endpoint = f"/api/2.0/accounts/servicePrincipals/{service_principal_id}/credentials/secrets"
        payload = {"secrets": secrets}
        return self._post(endpoint, payload, service_principal=service_principal)


    def delete_secret(
        self,
        service_principal_id: str,
        secret_id: str,
        service_principal: bool = False
    ) -> dict:
        """
        DELETE /api/2.0/accounts/servicePrincipals/{service_principal_id}/credentials/secrets/{secret_id}
        Deletes a secret reference for the given service principal.

        :param service_principal_id: the Databricks service principal UUID
        :param secret_id: the UUID of the secret reference to delete
        :param service_principal: whether to use service-principal auth headers
        """
        endpoint = (
            f"/api/2.0/accounts/servicePrincipals/"
            f"{service_principal_id}/credentials/secrets/{secret_id}"
        )
        return self._delete(endpoint, service_principal=service_principal)


class VolumesAPI(DatabricksBaseAPI):
    """
    Wrapper for the Azure Databricks Volumes REST API.
    Endpoints live under /api/2.1/volumes.
    """

    def list_volumes(self, catalog_name: str = None, schema_name:str = None, service_principal: bool = False) -> dict:
        """
        GET /api/2.1/volumes/list
        Lists all volumes in the workspace, optionally under a given workspace path.

        :param workspace_path: optional DBFS/Workspace path filter, e.g. "/Users/me/volumes"
        :param service_principal: whether to use SP headers
        """

        params = {}
        if catalog_name is not None:
            params["catalog_name"] = catalog_name
        if schema_name is not None:
            params["schema_name"] = schema_name

        return self._get(
            "/api/2.1/unity-catalog/volumes",
            params=params or None,
            service_principal=service_principal
        )

    def write_table(self, catalog_name: str = 'platform_admin', schema_name: str = 'metadata', table_name: str = 'volumes', service_principal: bool = False):

        results_table = f"{catalog_name}.{schema_name}.{table_name}"

        all_volumes = []

        my_catalogs = Unity_Catalog_API(self.DATABRICKS_INSTANCE,self.TOKEN)
        my_schemas = SchemasAPI(self.DATABRICKS_INSTANCE,self.TOKEN)
        catalogs = my_catalogs.list_catalog(service_principal=service_principal)

        for catalog in catalogs['catalogs']:
            catalog_name = catalog['name']
            if catalog['securable_kind'] != 'CATALOG_DELTASHARING':
                print(f"Catalog name: {catalog_name}")
                schemas = my_schemas.list_schemas(catalog_name=catalog_name,service_principal=service_principal)
                for schema in schemas['schemas']:
                    schema_name = schema['name']
                    print('Schema name: ',schema['name'])
                    volumes = self.list_volumes(catalog_name=catalog_name,schema_name=schema_name,service_principal=service_principal)
                    if 'volumes' in volumes and volumes['volumes']:                    
                        for volume in volumes['volumes']:
                            print(volume)                
                            all_volumes.append(volume)

        if len(all_volumes) > 0:
            self._write_table(full_table_name=results_table, data_to_write = all_volumes, primary_key = "volume_id", schema = None, service_principal=service_principal)

        if volumes:
            self._write_table(results_table, volumes)
            print(f"Data written to table {results_table}")
        else:
            print("No data to write")                


    def create_volume(
        self,
        name: str,
        storage_credential_name: str,
        comment: str = None,
        properties: dict = None,
        service_principal: bool = False
    ) -> dict:
        """
        POST /api/2.1/volumes/create
        Creates a new volume.

        :param name: unique name of the new volume
        :param storage_credential_name: name of an existing Unity Catalog storage credential
        :param comment: optional free-form text comment
        :param properties: optional key/value metadata for the volume
        :param service_principal: whether to use SP headers
        """
        data = {
            "name": name,
            "storage_credential_name": storage_credential_name
        }
        if comment is not None:
            data["comment"] = comment
        if properties is not None:
            data["properties"] = properties

        return self._post(
            "/api/2.1/volumes/create",
            data,
            service_principal=service_principal
        )

    def get_volume(self, volume_id: str, service_principal: bool = False) -> dict:
        """
        GET /api/2.1/volumes/get?volume_id={volume_id}
        Retrieves metadata for a single volume by its ID.

        :param volume_id: the ID of the volume to retrieve
        :param service_principal: whether to use SP headers
        """
        return self._get(
            f"/api/2.1/volumes/get?volume_id={volume_id}",
            service_principal=service_principal
        )

    def update_volume(
        self,
        volume_id: str,
        name: str = None,
        comment: str = None,
        properties: dict = None,
        service_principal: bool = False
    ) -> dict:
        """
        PATCH /api/2.1/volumes/update
        Updates an existing volume’s metadata. You must supply the volume_id
        and at least one field to update.

        :param volume_id: the ID of the volume to update
        :param name: new name for the volume (optional)
        :param comment: new comment (optional)
        :param properties: updated key/value metadata (optional)
        :param service_principal: whether to use SP headers
        """
        data = {"volume_id": volume_id}
        if name is not None:
            data["name"] = name
        if comment is not None:
            data["comment"] = comment
        if properties is not None:
            data["properties"] = properties

        return self._patch(
            "/api/2.1/volumes/update",
            data,
            service_principal=service_principal
        )

    def delete_volume(self, volume_id: str, service_principal: bool = False) -> dict:
        """
        POST /api/2.1/volumes/delete
        Deletes a volume. This permanently removes the volume and its data.

        :param volume_id: the ID of the volume to delete
        :param service_principal: whether to use SP headers
        """
        return self._post(
            "/api/2.1/volumes/delete",
            {"volume_id": volume_id},
            service_principal=service_principal
        )

class EntityTagAPI(DatabricksBaseAPI):
    """
    A client class for interacting with Databricks Unity Catalog Entity Tag Assignments API.

    This class provides methods to create, list, retrieve, update, and delete tag assignments
    for Unity Catalog entities such as catalogs, schemas, tables, views, columns, and volumes.

    API Overview: https://docs.databricks.com/api/azure/workspace/entitytagassignments
    """

    def _get_tag_url(self):
        """Returns the base endpoint URL for entity tag assignments."""
        return "/api/2.1/unity-catalog/entity-tag-assignments"

    def create_tag_assignment(self, entity_name, entity_type, tag_key, tag_value=None, service_principal=False):
        """
        Assigns a tag to a Unity Catalog entity.

        API: https://docs.databricks.com/api/azure/workspace/entitytagassignments/create  
        This endpoint allows you to attach a tag key (and optional value) to a cataloged entity.

        Args:
            entity_name (str): Full name of the entity (e.g., catalog.schema.table).
            entity_type (str): Type of the entity (e.g., TABLE, VIEW).
            tag_key (str): Key of the tag to assign.
            tag_value (str, optional): Value of the tag.

        Returns:
            dict: API response containing the created tag assignment.
        """
        payload = {
            "entity_name": entity_name,
            "entity_type": entity_type,
            "tag_key": tag_key
        }
        if tag_value:
            payload["tag_value"] = tag_value
        return self._post(self._get_tag_url(), payload, service_principal = service_principal)

    def list_tag_assignments(self, entity_name, entity_type):
        """
        Lists all tag assignments for a Unity Catalog entity.

        API: https://docs.databricks.com/api/azure/workspace/entitytagassignments/list  
        Returns all tags currently assigned to the specified entity.

        Args:
            entity_name (str): Full name of the entity.
            entity_type (str): Type of the entity.

        Returns:
            dict: API response containing a list of tag assignments.
        """
        params = {"entity_name": entity_name, "entity_type": entity_type}
        return self._get(self._get_tag_url(), params=params)

    def get_tag_assignment(self, entity_name, entity_type, tag_key):
        """
        Retrieves a specific tag assignment for a Unity Catalog entity.

        API: https://docs.databricks.com/api/azure/workspace/entitytagassignments/get  
        Returns the tag value and metadata for a given tag key on an entity.

        Args:
            entity_name (str): Full name of the entity.
            entity_type (str): Type of the entity.
            tag_key (str): Key of the tag to retrieve.

        Returns:
            dict: API response containing the tag assignment details.
        """
        params = {"entity_name": entity_name, "entity_type": entity_type, "tag_key": tag_key}
        return self._get(self._get_tag_url(), params=params)

    def update_tag_assignment(self, entity_name, entity_type, tag_key, tag_value):
        """
        Updates the value of an existing tag assignment.

        API: https://docs.databricks.com/api/azure/workspace/entitytagassignments/update  
        Modifies the value of a tag already assigned to an entity.

        Args:
            entity_name (str): Full name of the entity.
            entity_type (str): Type of the entity.
            tag_key (str): Key of the tag to update.
            tag_value (str): New value for the tag.

        Returns:
            dict: API response containing the updated tag assignment.
        """
        payload = {
            "entity_name": entity_name,
            "entity_type": entity_type,
            "tag_key": tag_key,
            "tag_value": tag_value
        }
        return self._patch(self._get_tag_url(), payload)

    def delete_tag_assignment(self, entity_name, entity_type, tag_key):
        """
        Deletes a tag assignment from a Unity Catalog entity.

        API: https://docs.databricks.com/api/azure/workspace/entitytagassignments/delete  
        Removes the specified tag key from the entity.

        Args:
            entity_name (str): Full name of the entity.
            entity_type (str): Type of the entity.
            tag_key (str): Key of the tag to delete.

        Returns:
            dict: API response confirming deletion.
        """
        params = {"entity_name": entity_name, "entity_type": entity_type, "tag_key": tag_key}
        return self._delete(self._get_tag_url(), service_principal = False)

class ABACPolicyAPI(DatabricksBaseAPI):
    """
    A client class for managing Attribute-Based Access Control (ABAC) policies in Azure Databricks.

    ABAC policies allow fine-grained access control based on data attributes such as tags and context.

    API Overview: https://docs.databricks.com/api/azure/workspace/policies
    """

    def _get_policy_url(self):
        """Returns the base endpoint URL for ABAC policy operations."""
        return "/api/2.0/policies"

    def create_policy(self, policy_name, definition, description=None):
        """
        Creates a new ABAC policy.

        API: https://docs.databricks.com/api/azure/workspace/policies/createpolicy  
        Defines a policy that applies to a securable and its descendants.

        Args:
            policy_name (str): Unique name for the policy.
            definition (str): JSON string defining the policy rules.
            description (str, optional): Optional description of the policy.

        Returns:
            dict: API response containing the created policy details.
        """
        payload = {"policy_name": policy_name, "definition": definition}
        if description:
            payload["description"] = description
        return self._post(self._get_policy_url() + "/createpolicy", payload)

    def list_policies(self):
        """
        Lists all ABAC policies in the workspace.

        API: https://docs.databricks.com/api/azure/workspace/policies/listpolicies  
        Returns metadata for all defined policies.

        Returns:
            dict: API response containing a list of policies.
        """
        return self._get(self._get_policy_url() + "/listpolicies")

    def get_policy(self, policy_id):
        """
        Retrieves details of a specific ABAC policy.

        API: https://docs.databricks.com/api/azure/workspace/policies/getpolicy  
        Returns the full definition and metadata of the policy.

        Args:
            policy_id (str): Unique identifier of the policy.

        Returns:
            dict: API response containing the policy details.
        """
        return self._get(self._get_policy_url() + "/getpolicy", {"policy_id": policy_id})

    def update_policy(self, policy_id, definition=None, description=None):
        """
        Updates an existing ABAC policy.

        API: https://docs.databricks.com/api/azure/workspace/policies/updatepolicy  
        Modifies the definition or description of a policy.

        Args:
            policy_id (str): Unique identifier of the policy.
            definition (str, optional): Updated JSON definition of the policy.
            description (str, optional): Updated description of the policy.

        Returns:
            dict: API response containing the updated policy.
        """
        payload = {"policy_id": policy_id}
        if definition:
            payload["definition"] = definition
        if description:
            payload["description"] = description
        return self._patch(self._get_policy_url() + "/updatepolicy", payload)

    def delete_policy(self, policy_id):
        """
        Deletes an ABAC policy.

        API: https://docs.databricks.com/api/azure/workspace/policies/deletepolicy  
        Removes the policy from the workspace.

        Args:
            policy_id (str): Unique identifier of the policy to delete.

        Returns:
            dict: API response confirming deletion.
        """
        return self._delete(self._get_policy_url() + "/deletepolicy", {"policy_id": policy_id})



class PipelineAPI(DatabricksBaseAPI):
    """
    A client class for managing Delta Live Tables pipelines in Azure Databricks.

    This class provides methods to create, retrieve, update, delete, and control pipelines,
    as well as manage permissions and monitor pipeline events and updates.

    API Overview: https://docs.databricks.com/api/azure/workspace/pipelines
    """

    def _get_pipeline_url(self):
        """Returns the base endpoint URL for pipeline operations."""
        return "/api/2.0/pipelines"

    def create_pipeline(self, pipeline_spec, service_principal: bool = False):
        """
        Creates a new Delta Live Tables pipeline.

        API: https://docs.databricks.com/api/azure/workspace/pipelines/create  
        This endpoint registers a new pipeline with the specified configuration.

        Args:
            pipeline_spec (dict): Dictionary containing pipeline configuration.

        Returns:
            dict: API response with pipeline creation details.
        """
        return self._post(self._get_pipeline_url() + "/create", pipeline_spec, service_principal = service_principal)

    def list_pipelines(self, service_principal: bool = False, next_page_token: str = None, filter: str = None, debug: bool = False):
        """
        Lists pipelines in the workspace, optionally using a next_page_token for pagination.

        Args:
            service_principal (bool): Whether to use service principal authentication.
            next_page_token (str, optional): Token for fetching the next page of results.

        Returns:
            dict: API response containing a list of pipelines.
        """
        
        payload = {}
        if next_page_token:           
            payload["next_page_token"] = next_page_token
        if filter:
            payload["filter"] = f"name LIKE '{filter}'"
        
        if debug:
            print('PAYLOAD: ',payload)

        return self._get(self._get_pipeline_url(), params=payload, service_principal=service_principal)
    

    def get_pipelines(self, service_principal: bool = False, filter = None) -> list:
        """
        Retrieves all piepline metadata from the workspace, handling pagination correctly.

        Returns full job definitions and configurations across all pages.

        Args:
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            list: List of pipeline metadata dictionaries.
        """

        endpoint = self._get_pipeline_url()
        all_pipelines = []
        page_token = None

        while True:
            params = {}

            if filter:
                params["filter"] = f"name LIKE '{filter}'"
            if page_token:
                params["page_token"] = page_token

            response = self._get(endpoint, service_principal=service_principal, params=params)
            pipelines = response.get("statuses", [])
            all_pipelines.extend(pipelines)       

            if response.get("next_page_token"):
                # Reuse the same page_token value for the next request
                page_token = response.get("next_page_token")
            else:
                print('ALL:',all_pipelines)
                return all_pipelines
                break

        return all_pipelines
    
    def write_table(self, catalog_name='platform_admin', schema_name='metadata', table_name='pipelines', service_principal: bool = False):
        """
        Writes job metadata to a Delta table.

        This method flattens job metadata and stores it in a structured format.

        Args:
            catalog_name (str): Catalog name.
            schema_name (str): Schema name.
            table_name (str): Table name.
            service_principal (bool): Whether to use service principal authentication.
        """
        results_table = f"{catalog_name}.{schema_name}.{table_name}"
        pipelines = self.get_pipelines(service_principal=service_principal)
        print('PIPELINES:',pipelines)
        if len(pipelines) > 0:
            self._write_table(results_table, pipelines, "pipeline_id", schema=None, service_principal=service_principal, add_workspace=True)
            print(f"Data written to table {results_table}")
        else:
            print("No data to write")    




    def get_pipeline(self, pipeline_id, service_principal:bool = False):
        """
        Retrieves details of a specific pipeline.

        API: https://docs.databricks.com/api/azure/workspace/pipelines/get  
        Returns the full configuration and status of the pipeline.

        Args:
            pipeline_id (str): Unique identifier of the pipeline.

        Returns:
            dict: API response with pipeline details.
        """
        return self._get(self._get_pipeline_url() + f"/{pipeline_id}", service_principal = service_principal)
    

    def get_pipeline_id_by_name(self, pipeline_name, service_principal: bool = False):
        """
        Retrieves details of a specific pipeline by name, paginating through results if needed.

        Args:
            pipeline_name (str): Name of the pipeline.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            str or None: Pipeline ID if found, otherwise None.
        """

        pipelines = self.list_pipelines(service_principal=service_principal, filter=pipeline_name)

        for pipeline in pipelines.get("statuses", []):
            print(pipeline.get("name"))
            if pipeline.get("name") == pipeline_name:
                return pipeline.get("pipeline_id")

        return None


    def update_pipeline(self, pipeline_id, updates, service_principal: bool = False):
        """
        Updates an existing pipeline configuration.

        API: https://docs.databricks.com/api/azure/workspace/pipelines/update  
        Modifies the pipeline definition and settings.

        Args:
            pipeline_id (str): Unique identifier of the pipeline.
            updates (dict): Dictionary of updated pipeline fields.

        Returns:
            dict: API response with updated pipeline details.
        """

        return self._put(self._get_pipeline_url() + f"/{pipeline_id}", updates, service_principal = service_principal)
    

    def update_pipeline_tags(self, tag_spec, pipeline_id = None, pipeline_name = None, service_principal: bool = False):
        """
        Updates an existing pipeline's tag configuration.

        Args:
            pipeline_id (str): Unique identifier of the pipeline.
            updates (dict): Dictionary of updated pipeline fields.

        Returns:
            dict: API response with updated pipeline details.
        """          

        if pipeline_name and not pipeline_id:
            pipeline_id = self.get_pipeline_id_by_name(pipeline_name,service_principal)
        elif not pipeline_id:
            print('pipeline_id or pipeline_name must be provided')
            return None
        
        my_pipeline = self.get_pipeline(pipeline_id, service_principal=service_principal)

        # Ensure 'spec' exists
        if "spec" not in my_pipeline:
            my_pipeline["spec"] = {}

        # Ensure 'tags' exists inside spec
        if "tags" not in my_pipeline["spec"]:
            my_pipeline["spec"]["tags"] = {}

        # Merge updates['tags'] into existing spec['tags']
        my_pipeline["spec"]["tags"].update(tag_spec["tags"])        

        # Update pipeline definition using updated definition
        self.update_pipeline(pipeline_id, my_pipeline["spec"], service_principal)

        

    def delete_pipeline(self, pipeline_id, service_principal: bool = False):
        """
        Deletes a pipeline.

        API: https://docs.databricks.com/api/azure/workspace/pipelines/delete  
        Removes the pipeline and its associated metadata.

        Args:
            pipeline_id (str): Unique identifier of the pipeline.

        Returns:
            dict: API response confirming deletion.
        """
        return self._delete(self._get_pipeline_url() + "/delete", {"pipeline_id": pipeline_id})

    def list_pipeline_events(self, pipeline_id, service_principal: bool = False):
        """
        Lists events for a specific pipeline.

        API: https://docs.databricks.com/api/azure/workspace/pipelines/listpipelineevents  
        Returns a timeline of pipeline events such as start, stop, and errors.

        Args:
            pipeline_id (str): Unique identifier of the pipeline.

        Returns:
            dict: API response containing pipeline events.
        """
        return self._get(self._get_pipeline_url() + "/listpipelineevents", {"pipeline_id": pipeline_id}, service_principal = service_principal)

    def stop_pipeline(self, pipeline_id, service_principal: bool = False):
        """
        Stops a running pipeline.

        API: https://docs.databricks.com/api/azure/workspace/pipelines/stop  
        Terminates the active pipeline run.

        Args:
            pipeline_id (str): Unique identifier of the pipeline.

        Returns:
            dict: API response confirming stop request.
        """
        return self._post(self._get_pipeline_url() + "/stop", {"pipeline_id": pipeline_id}, service_principal = service_principal)

    def list_pipeline_updates(self, pipeline_id, service_principal: bool = False):
        """
        Lists update history for a pipeline.

        API: https://docs.databricks.com/api/azure/workspace/pipelines/listupdates  
        Returns a list of past pipeline runs and their statuses.

        Args:
            pipeline_id (str): Unique identifier of the pipeline.

        Returns:
            dict: API response containing update history.
        """
        return self._get(self._get_pipeline_url() + "/listupdates", {"pipeline_id": pipeline_id}, service_principal = service_principal)

    def start_pipeline_update(self, pipeline_id, full_refresh=False, service_principal: bool = False):
        """
        Starts a new update (run) of the pipeline.

        API: https://docs.databricks.com/api/azure/workspace/pipelines/startupdate  
        Initiates a pipeline run with optional full refresh.

        Args:
            pipeline_id (str): Unique identifier of the pipeline.
            full_refresh (bool): Whether to perform a full refresh.

        Returns:
            dict: API response with update initiation details.
        """
        payload = {
            "pipeline_id": pipeline_id,
            "full_refresh": full_refresh
        }
        return self._post(self._get_pipeline_url() + "/startupdate", payload, service_principal = service_principal)

    def get_pipeline_update(self, pipeline_id, update_id, service_principal: bool = False):
        """
        Retrieves details of a specific pipeline update.

        API: https://docs.databricks.com/api/azure/workspace/pipelines/getupdate  
        Returns metadata and status of the specified update.

        Args:
            pipeline_id (str): Unique identifier of the pipeline.
            update_id (str): Unique identifier of the update.

        Returns:
            dict: API response with update details.
        """
        params = {
            "pipeline_id": pipeline_id,
            "update_id": update_id
        }
        return self._get(self._get_pipeline_url() + "/getupdate", params=params, service_principal = service_principal)

    def get_pipeline_permissions(self, pipeline_id, service_principal: bool = False):
        """
        Gets permission settings for a pipeline.

        API: https://docs.databricks.com/api/azure/workspace/pipelines/getpermissions  
        Returns access control entries for the pipeline.

        Args:
            pipeline_id (str): Unique identifier of the pipeline.

        Returns:
            dict: API response with permission details.
        """
        return self._get(f"{self._get_pipeline_url()}/{pipeline_id}/permissions")

    def set_pipeline_permissions(self, pipeline_id, access_control_list, service_principal: bool = False):
        """
        Sets permission settings for a pipeline.

        API: https://docs.databricks.com/api/azure/workspace/pipelines/setpermissions  
        Replaces existing permissions with the provided list.

        Args:
            pipeline_id (str): Unique identifier of the pipeline.
            access_control_list (list): List of permission entries.

        Returns:
            dict: API response confirming permission update.
        """
        payload = {"access_control_list": access_control_list}
        return self._post(f"{self._get_pipeline_url()}/{pipeline_id}/permissions", payload, service_principal = service_principal)

    def update_pipeline_permissions(self, pipeline_id, access_control_list, service_principal: bool = False):
        """
        Updates permission settings for a pipeline.

        API: https://docs.databricks.com/api/azure/workspace/pipelines/updatepermissions  
        Modifies existing access control entries.

        Args:
            pipeline_id (str): Unique identifier of the pipeline.
            access_control_list (list): List of updated permission entries.

        Returns:
            dict: API response confirming permission update.
        """
        payload = {"access_control_list": access_control_list}
        return self._patch(f"{self._get_pipeline_url()}/{pipeline_id}/permissions", payload, service_principal = service_principal)

    def get_pipeline_permission_levels(self, pipeline_id, service_principal: bool = False):
        """
        Retrieves available permission levels for a pipeline.

        API: https://docs.databricks.com/api/azure/workspace/pipelines/getpermissionlevels  
        Returns a list of permission levels that can be assigned.

        Args:
            pipeline_id (str): Unique identifier of the pipeline.

        Returns:
            dict: API response with permission level options.
        """
        return self._get(f"{self._get_pipeline_url()}/{pipeline_id}/permissionLevels", service_principal = service_principal)
    
class NetworkConnectivityAPI(DatabricksBaseAPI):
    """
    A client class for managing Network Connectivity Configurations (NCCs) in Azure Databricks.

    This class provides methods to list network connectivity configurations associated with a Databricks account.

    API Overview: https://docs.databricks.com/api/azure/account/networkconnectivity
    """

    def list_nccs(
        self,
        account_id: str,
        service_principal: bool = False
    ) -> dict:
        """
        Lists all network connectivity configurations (NCCs) for a given Databricks account.

        API: https://docs.databricks.com/api/azure/account/networkconnectivity#operation/get-network-connectivity-configs  
        This endpoint returns a list of NCCs, which define how workspaces connect to the cloud network.

        Args:
            account_id (str): The unique identifier of the Databricks account.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: API response containing the list of NCCs and their configuration details.
        """
        endpoint = f"/api/2.0/accounts/{account_id}/network-connectivity-configs"        
        params = None

        if service_principal and self.SP_HEADERS is not None:
            api_header = self.SP_HEADERS
        else:
            api_header = self.HEADERS

        accounts_url = f"https://accounts.azuredatabricks.net{endpoint}"

        response = requests.get(accounts_url, headers=api_header, params = params)
        response.raise_for_status()

        if isinstance(type(response), dict):
            return response
        else:
            return response.json()
        
    def write_table(self, catalog_name: str = 'platform_admin', schema_name: str = 'metadata', table_name: str = 'nccs', service_principal: bool = False, account_id: str = None):

            results_table = f"{catalog_name}.{schema_name}.{table_name}"

            if account_id:
                use_account_id = account_id
            else:
                use_account_id = self.ACCOUNT_ID

            my_nccs = self.list_nccs(account_id=use_account_id,service_principal=service_principal)

            ncc_schema = StructType([
                StructField("network_connectivity_config_id", StringType(), True),
                StructField("account_id", StringType(), True),
                StructField("name", StringType(), True),
                StructField("region", StringType(), True),
                StructField("creation_time", LongType(), True),
                StructField("updated_time", LongType(), True),
                StructField("egress_config", StructType([
                    StructField("default_rules", StructType([
                        StructField("azure_service_endpoint_rule", StructType([
                            StructField("target_region", StringType(), True),
                            StructField("target_services", ArrayType(StringType()), True),
                            StructField("subnets", ArrayType(StringType()), True)
                        ]))
                    ])),
                    StructField("target_rules", StructType([
                        StructField("azure_private_endpoint_rules", ArrayType(StructType([
                            StructField("rule_id", StringType(), True),
                            StructField("network_connectivity_config_id", StringType(), True),
                            StructField("resource_id", StringType(), True),
                            StructField("group_id", StringType(), True),
                            StructField("endpoint_name", StringType(), True),
                            StructField("connection_state", StringType(), True),
                            StructField("creation_time", LongType(), True),
                            StructField("updated_time", LongType(), True)
                        ])))
                    ]))
                ]))
            ])


            items = my_nccs.get("items", [])

            if len(items) > 0:
                self._write_table(full_table_name=results_table, data_to_write = items, primary_key = "network_connectivity_config_id", schema = ncc_schema, service_principal=service_principal)
            else:
                print("No data to write") 
                

    def list_private_endpoint_rules(
        self,
        account_id: str,
        network_connectivity_config_id: str,
        service_principal: bool = False
    ) -> list:
        """
        Lists all private endpoint rules for a specific network connectivity configuration.

        API: https://docs.databricks.com/api/azure/account/networkconnectivity/listprivateendpointrules  
        This endpoint returns a paginated list of private endpoint rules associated with the specified NCC.

        This method automatically handles pagination and returns a flat list of rules.

        Args:
            account_id (str): The unique identifier of the Databricks account.
            network_connectivity_config_id (str): The ID of the network connectivity configuration.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            list: A list of private endpoint rule dictionaries.
        """
        base_endpoint = f"/api/2.0/accounts/{account_id}/network-connectivity-configs/{network_connectivity_config_id}/private-endpoint-rules"
        accounts_url = f"https://accounts.azuredatabricks.net{base_endpoint}"

        if service_principal and self.SP_HEADERS is not None:
            api_header = self.SP_HEADERS
        else:
            api_header = self.HEADERS

        all_items = []
        next_page_token = None

        while True:
            params = {}
            if next_page_token:
                params["page_token"] = next_page_token

            response = requests.get(accounts_url, headers=api_header, params=params)
            response.raise_for_status()
            result = response.json()

            items = result.get("items", [])
            all_items.extend(items)

            next_page_token = result.get("next_page_token")
            if not next_page_token:
                break

        return all_items



        
    def write_table_endpoint_rules(self, catalog_name: str = 'platform_admin', schema_name: str = 'metadata', table_name: str = 'ncc_rules', service_principal: bool = False, account_id: str = None):

            results_table = f"{catalog_name}.{schema_name}.{table_name}"

            if account_id:
                use_account_id = account_id
            else:
                use_account_id = self.ACCOUNT_ID

            my_nccs = self.list_nccs(account_id=use_account_id,service_principal=service_principal)

            items = my_nccs.get("items", [])

            rules = []

            for item in items:
                new_rules = self.list_private_endpoint_rules(account_id=use_account_id,network_connectivity_config_id=item['network_connectivity_config_id'],service_principal=service_principal)
                rules.extend(new_rules)

            private_endpoint_rule_schema = StructType([
                StructField("rule_id", StringType(), True),
                StructField("network_connectivity_config_id", StringType(), True),
                StructField("connection_state", StringType(), True),
                StructField("creation_time", LongType(), True),
                StructField("updated_time", LongType(), True),
                StructField("resource_id", StringType(), True),
                StructField("group_id", StringType(), True),
                StructField("endpoint_name", StringType(), True)
            ])

            display(rules)

            if len(rules) > 0:
                self._write_table(full_table_name=results_table, data_to_write = rules, primary_key = "rule_id", schema = private_endpoint_rule_schema, service_principal=service_principal)
            else:
                print("No data to write")         


    def create_ncc(
        self,
        account_id: str,
        payload: dict,
        service_principal: bool = False
    ) -> dict:
        """
        Creates a new network connectivity configuration (NCC).

        API: https://docs.databricks.com/api/azure/account/networkconnectivity/createnetworkconnectivityconfiguration

        Args:
            account_id (str): The Databricks account ID.
            payload (dict): The configuration payload as defined by the API spec.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: API response containing the created NCC details.
        """
        endpoint = f"/api/2.0/accounts/{account_id}/network-connectivity-configs"
        url = f"https://accounts.azuredatabricks.net{endpoint}"
        headers = self.SP_HEADERS if service_principal and self.SP_HEADERS else self.HEADERS

        response = requests.post(url, headers=headers, json=payload)
        response.raise_for_status()
        return response.json()


    def get_ncc(
        self,
        account_id: str,
        network_connectivity_config_id: str,
        service_principal: bool = False
    ) -> dict:
        """
        Retrieves a specific network connectivity configuration.

        API: https://docs.databricks.com/api/azure/account/networkconnectivity/getnetworkconnectivityconfiguration

        Args:
            account_id (str): The Databricks account ID.
            network_connectivity_config_id (str): The NCC ID.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: API response containing the NCC details.
        """
        endpoint = f"/api/2.0/accounts/{account_id}/network-connectivity-configs/{network_connectivity_config_id}"
        url = f"https://accounts.azuredatabricks.net{endpoint}"
        headers = self.SP_HEADERS if service_principal and self.SP_HEADERS else self.HEADERS

        response = requests.get(url, headers=headers)
        response.raise_for_status()
        return response.json()


    def delete_ncc(
        self,
        account_id: str,
        network_connectivity_config_id: str,
        service_principal: bool = False
    ) -> dict:
        """
        Deletes a specific network connectivity configuration.

        API: https://docs.databricks.com/api/azure/account/networkconnectivity/deletenetworkconnectivityconfiguration

        Args:
            account_id (str): The Databricks account ID.
            network_connectivity_config_id (str): The NCC ID.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: API response confirming deletion.
        """
        endpoint = f"/api/2.0/accounts/{account_id}/network-connectivity-configs/{network_connectivity_config_id}"
        url = f"https://accounts.azuredatabricks.net{endpoint}"
        headers = self.SP_HEADERS if service_principal and self.SP_HEADERS else self.HEADERS

        response = requests.delete(url, headers=headers)
        response.raise_for_status()
        try:
            return response.json()
        except ValueError:
            return {"status": "deleted"}


    def create_private_endpoint_rule(
        self,
        account_id: str,
        network_connectivity_config_id: str,
        payload: dict,
        service_principal: bool = False
    ) -> dict:
        """
        Creates a private endpoint rule for a given NCC.

        API: https://docs.databricks.com/api/azure/account/networkconnectivity/createprivateendpointrule

        Args:
            account_id (str): The Databricks account ID.
            network_connectivity_config_id (str): The NCC ID.
            payload (dict): The rule definition.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: API response containing the created rule.
        """
        endpoint = f"/api/2.0/accounts/{account_id}/network-connectivity-configs/{network_connectivity_config_id}/private-endpoint-rules"
        url = f"https://accounts.azuredatabricks.net{endpoint}"
        headers = self.SP_HEADERS if service_principal and self.SP_HEADERS else self.HEADERS

        response = requests.post(url, headers=headers, json=payload)
        response.raise_for_status()
        return response.json()


    def get_private_endpoint_rule(
        self,
        account_id: str,
        network_connectivity_config_id: str,
        rule_id: str,
        service_principal: bool = False
    ) -> dict:
        """
        Retrieves a specific private endpoint rule.

        API: https://docs.databricks.com/api/azure/account/networkconnectivity/getprivateendpointrule

        Args:
            account_id (str): The Databricks account ID.
            network_connectivity_config_id (str): The NCC ID.
            rule_id (str): The rule ID.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: API response containing the rule details.
        """
        endpoint = f"/api/2.0/accounts/{account_id}/network-connectivity-configs/{network_connectivity_config_id}/private-endpoint-rules/{rule_id}"
        url = f"https://accounts.azuredatabricks.net{endpoint}"
        headers = self.SP_HEADERS if service_principal and self.SP_HEADERS else self.HEADERS

        response = requests.get(url, headers=headers)
        response.raise_for_status()
        return response.json()


    def update_private_endpoint_rule(
        self,
        account_id: str,
        network_connectivity_config_id: str,
        rule_id: str,
        payload: dict,
        service_principal: bool = False
    ) -> dict:
        """
        Updates a private endpoint rule.

        API: https://docs.databricks.com/api/azure/account/networkconnectivity/updateprivateendpointrule

        Args:
            account_id (str): The Databricks account ID.
            network_connectivity_config_id (str): The NCC ID.
            rule_id (str): The rule ID.
            payload (dict): The updated rule definition.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: API response containing the updated rule.
        """
        endpoint = f"/api/2.0/accounts/{account_id}/network-connectivity-configs/{network_connectivity_config_id}/private-endpoint-rules/{rule_id}"
        url = f"https://accounts.azuredatabricks.net{endpoint}"
        headers = self.SP_HEADERS if service_principal and self.SP_HEADERS else self.HEADERS

        response = requests.patch(url, headers=headers, json=payload)
        response.raise_for_status()
        return response.json()


    def delete_private_endpoint_rule(
        self,
        account_id: str,
        network_connectivity_config_id: str,
        rule_id: str,
        service_principal: bool = False
    ) -> dict:
        """
        Deletes a private endpoint rule.

        API: https://docs.databricks.com/api/azure/account/networkconnectivity/deleteprivateendpointrule

        Args:
            account_id (str): The Databricks account ID.
            network_connectivity_config_id (str): The NCC ID.
            rule_id (str): The rule ID.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: API response confirming deletion.
        """
        endpoint = f"/api/2.0/accounts/{account_id}/network-connectivity-configs/{network_connectivity_config_id}/private-endpoint-rules/{rule_id}"
        url = f"https://accounts.azuredatabricks.net{endpoint}"
        headers = self.SP_HEADERS if service_principal and self.SP_HEADERS else self.HEADERS

        response = requests.delete(url, headers=headers)
        response.raise_for_status()
        try:
            return response.json()
        except ValueError:
            return {"status": "deleted"}


class QueryHistoryAPI(DatabricksBaseAPI):
    """
    A client class for accessing SQL query history in Azure Databricks workspaces.

    This class provides methods to list historical SQL queries executed via SQL warehouses or serverless compute.

    API Overview: https://docs.databricks.com/api/azure/workspace/queryhistory/list
    """

    def list_queries(
        self,
        start_time_ms: int = None,
        end_time_ms: int = None,
        user_id: str = None,
        warehouse_id: str = None,
        status: str = None,
        max_results: int = 100,
        service_principal: bool = False
    ) -> list:
        """
        Lists historical SQL queries executed in the workspace.

        API: https://docs.databricks.com/api/azure/workspace/queryhistory/list  
        This endpoint returns a paginated list of query executions, filtered by time, user, warehouse, and status.

        Args:
            start_time_ms (int): Optional. Filter queries started after this timestamp (in milliseconds).
            end_time_ms (int): Optional. Filter queries started before this timestamp (in milliseconds).
            user_id (str): Optional. Filter by user ID.
            warehouse_id (str): Optional. Filter by SQL warehouse ID.
            status (str): Optional. Filter by query status (e.g., "FINISHED", "FAILED").
            max_results (int): Maximum number of results to return per page (default: 100).
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            list: A list of query history records.
        """
        endpoint = "/api/2.0/sql/history/queries"
        url = f"{self.DATABRICKS_INSTANCE}{endpoint}"
        headers = self.SP_HEADERS if service_principal and self.SP_HEADERS else self.HEADERS

        all_items = []
        next_page_token = None

        while True:
            payload = {
                "max_results": max_results
            }
            if start_time_ms:
                payload["filter_by_start_time_ms"] = start_time_ms
            if end_time_ms:
                payload["filter_by_end_time_ms"] = end_time_ms
            if user_id:
                payload["filter_by_user_id"] = user_id
            if warehouse_id:
                payload["filter_by_warehouse_id"] = warehouse_id
            if status:
                payload["filter_by_status"] = status
            if next_page_token:
                payload["page_token"] = next_page_token

            response = requests.post(url, headers=headers, json=payload)
            response.raise_for_status()
            result = response.json()

            items = result.get("res", [])
            all_items.extend(items)

            next_page_token = result.get("next_page_token")
            if not next_page_token:
                break

        return all_items




class PolicyComplianceAPI(DatabricksBaseAPI):
    """
    A client class for managing policy compliance for clusters and jobs in Azure Databricks.

    This class provides methods to enforce, retrieve, and list compliance status for both clusters and jobs
    based on workspace policies.

    Cluster Compliance API Overview: https://docs.databricks.com/api/azure/workspace/policycomplianceforclusters  
    Job Compliance API Overview: https://docs.databricks.com/api/azure/workspace/policycomplianceforjobs
    """

    # -------------------------------
    # Cluster Policy Compliance APIs
    # -------------------------------

    def enforce_cluster_compliance(self, cluster_id: str, service_principal: bool = False):
        """
        Enforces policy compliance on a specified cluster.

        API: https://docs.databricks.com/api/azure/workspace/policycomplianceforclusters/enforcecompliance  
        This endpoint applies workspace policies to the given cluster.

        Args:
            cluster_id (str): Unique identifier of the cluster.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: API response indicating enforcement status.
        """
        data = {"cluster_id": cluster_id}
        return self._post("/api/2.0/policy-compliance/clusters/enforce-compliance", data, service_principal)

    def get_cluster_compliance(self, cluster_id: str, service_principal: bool = False):
        """
        Retrieves the compliance status of a specified cluster.

        API: https://docs.databricks.com/api/azure/workspace/policycomplianceforclusters/getcompliance  
        This endpoint returns the current compliance status for the cluster.

        Args:
            cluster_id (str): Unique identifier of the cluster.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: API response with compliance details.
        """
        params = {"cluster_id": cluster_id}
        return self._get("/api/2.0/policy-compliance/clusters/get-compliance", params=params, service_principal=service_principal)

    def list_cluster_compliance(self, service_principal: bool = False):
        """
        Lists compliance status for all clusters in the workspace.

        API: https://docs.databricks.com/api/azure/workspace/policycomplianceforclusters/listcompliance  
        This endpoint returns a list of clusters and their compliance states.

        Args:
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: API response with a list of cluster compliance records.
        """
        return self._get("/api/2.0/policy-compliance/clusters/list-compliance", service_principal=service_principal)

    # ---------------------------
    # Job Policy Compliance APIs
    # ---------------------------

    def enforce_job_compliance(self, job_id: int, service_principal: bool = False):
        """
        Enforces policy compliance on a specified job.

        API: https://docs.databricks.com/api/azure/workspace/policycomplianceforjobs/enforcecompliance  
        This endpoint applies workspace policies to the given job.

        Args:
            job_id (int): Unique identifier of the job.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: API response indicating enforcement status.
        """
        data = {"job_id": job_id}
        return self._post("/api/2.0/policy-compliance/jobs/enforce-compliance", data, service_principal)

    def get_job_compliance(self, job_id: int, service_principal: bool = False):
        """
        Retrieves the compliance status of a specified job.

        API: https://docs.databricks.com/api/azure/workspace/policycomplianceforjobs/getcompliance  
        This endpoint returns the current compliance status for the job.

        Args:
            job_id (int): Unique identifier of the job.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: API response with compliance details.
        """
        params = {"job_id": job_id}
        return self._get("/api/2.0/policy-compliance/jobs/get-compliance", params=params, service_principal=service_principal)

    def list_job_compliance(self, service_principal: bool = False):
        """
        Lists compliance status for all jobs in the workspace.

        API: https://docs.databricks.com/api/azure/workspace/policycomplianceforjobs/listcompliance  
        This endpoint returns a list of jobs and their compliance states.

        Args:
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: API response with a list of job compliance records.
        """
        return self._get("/api/2.0/policy-compliance/jobs/list-compliance", service_principal=service_principal)

class PolicyFamiliesAPI(DatabricksBaseAPI):
    """
    A client class for managing policy families in Azure Databricks.

    This class provides methods to list available policy families and retrieve details about a specific policy family.
    Policy families define reusable configurations for cluster policies across the workspace.

    API Overview: https://docs.databricks.com/api/azure/workspace/policyfamilies
    """

    def list_policy_families(self, service_principal: bool = False):
        """
        Lists all available policy families in the workspace.

        API: https://docs.databricks.com/api/azure/workspace/policyfamilies/list  
        This endpoint returns metadata about policy families that can be used to create cluster policies.

        Args:
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: API response containing a list of policy families.
        """
        return self._get("/api/2.0/policy-families/list", service_principal=service_principal)

    def get_policy_family(self, policy_family_id: str, service_principal: bool = False):
        """
        Retrieves details for a specific policy family.

        API: https://docs.databricks.com/api/azure/workspace/policyfamilies/get  
        This endpoint returns configuration and metadata for the specified policy family.

        Args:
            policy_family_id (str): Unique identifier of the policy family.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: API response with policy family details.
        """
        return self._get(f"/api/2.0/policy-families/get?policy_family_id={policy_family_id}", service_principal=service_principal)

class CurrentUserAPI(DatabricksBaseAPI):
    """
    A client class for retrieving information about the current authenticated user in Azure Databricks.

    This class provides a method to fetch identity details of the caller, including user ID, username, and account info.

    API Overview: https://docs.databricks.com/api/azure/workspace/currentuser
    """

    def get_current_user(self, service_principal: bool = False):
        """
        Retrieves information about the current authenticated user.

        API: https://docs.databricks.com/api/azure/workspace/currentuser/me  
        This endpoint returns identity details of the caller, such as user ID, username, and account context.

        Args:
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: API response containing user identity information.
        """
        return self._get("/api/2.0/current-user/me", service_principal=service_principal)


class GroupsAPI(DatabricksBaseAPI):
    """
    A client class for managing identity groups in Azure Databricks using the Groups V2 API.

    This class provides methods to list, create, retrieve, update, patch, and delete identity groups
    within a Databricks workspace. Groups are used to manage access control and organize users.

    API Overview: https://docs.databricks.com/api/azure/workspace/groupsv2
    """

    def list_groups(self, service_principal: bool = False):
        """
        Lists all identity groups in the workspace.

        API: https://docs.databricks.com/api/azure/workspace/groupsv2/list  
        This endpoint returns metadata for all groups, including names, IDs, and entitlements.

        Args:
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: API response containing a list of groups.
        """
        return self._get("/api/2.0/groups/list", service_principal=service_principal)

    def create_group(self, group_spec: dict, service_principal: bool = False):
        """
        Creates a new identity group in the workspace.

        API: https://docs.databricks.com/api/azure/workspace/groupsv2/create  
        This endpoint registers a new group with the specified configuration.

        Args:
            group_spec (dict): Dictionary containing group configuration (e.g., display name, entitlements).
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: API response with group creation details.
        """
        return self._post("/api/2.0/groups/create", group_spec, service_principal)

    def get_group(self, group_id: str, service_principal: bool = False):
        """
        Retrieves details for a specific identity group.

        API: https://docs.databricks.com/api/azure/workspace/groupsv2/get  
        This endpoint returns metadata and configuration for the specified group.

        Args:
            group_id (str): Unique identifier of the group.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: API response with group details.
        """
        return self._get(f"/api/2.0/groups/get?group_id={group_id}", service_principal=service_principal)

    def update_group(self, group_id: str, update_spec: dict, service_principal: bool = False):
        """
        Updates an identity group by replacing its configuration.

        API: https://docs.databricks.com/api/azure/workspace/groupsv2/update  
        This endpoint performs a full update of the group’s metadata and entitlements.

        Args:
            group_id (str): Unique identifier of the group.
            update_spec (dict): Dictionary containing updated group configuration.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: API response with updated group details.
        """
        return self._put(f"/api/2.0/groups/update?group_id={group_id}", update_spec, service_principal)

    def patch_group(self, group_id: str, patch_spec: dict, service_principal: bool = False):
        """
        Applies partial updates to an identity group.

        API: https://docs.databricks.com/api/azure/workspace/groupsv2/patch  
        This endpoint modifies specific fields of the group without replacing the entire configuration.

        Args:
            group_id (str): Unique identifier of the group.
            patch_spec (dict): Dictionary containing fields to update.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: API response with patched group details.
        """
        return self._patch(f"/api/2.0/groups/patch?group_id={group_id}", patch_spec, service_principal)

    def delete_group(self, group_id: str, service_principal: bool = False):
        """
        Deletes an identity group from the workspace.

        API: https://docs.databricks.com/api/azure/workspace/groupsv2/delete  
        This endpoint removes the specified group and its associated metadata.

        Args:
            group_id (str): Unique identifier of the group.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: API response confirming deletion.
        """
        return self._delete(f"/api/2.0/groups/delete?group_id={group_id}", service_principal=service_principal)


class GroupsAPI(DatabricksBaseAPI):
    """
    A client class for managing identity groups in Azure Databricks using the Groups V2 API.

    This class provides methods to list, create, retrieve, update, patch, and delete identity groups
    within a Databricks workspace. Groups are used to manage access control and organize users.

    API Overview: https://docs.databricks.com/api/azure/workspace/groupsv2
    """

    def list_groups(self, service_principal: bool = False):
        """
        Lists all identity groups in the workspace.

        API: https://docs.databricks.com/api/azure/workspace/groupsv2/list  
        This endpoint returns metadata for all groups, including names, IDs, and entitlements.

        Args:
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: API response containing a list of groups.
        """
        return self._get("/api/2.0/groups/list", service_principal=service_principal)

    def create_group(self, group_spec: dict, service_principal: bool = False):
        """
        Creates a new identity group in the workspace.

        API: https://docs.databricks.com/api/azure/workspace/groupsv2/create  
        This endpoint registers a new group with the specified configuration.

        Args:
            group_spec (dict): Dictionary containing group configuration (e.g., display name, entitlements).
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: API response with group creation details.
        """
        return self._post("/api/2.0/groups/create", group_spec, service_principal)

    def get_group(self, group_id: str, service_principal: bool = False):
        """
        Retrieves details for a specific identity group.

        API: https://docs.databricks.com/api/azure/workspace/groupsv2/get  
        This endpoint returns metadata and configuration for the specified group.

        Args:
            group_id (str): Unique identifier of the group.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: API response with group details.
        """
        return self._get(f"/api/2.0/groups/get?group_id={group_id}", service_principal=service_principal)

    def update_group(self, group_id: str, update_spec: dict, service_principal: bool = False):
        """
        Updates an identity group by replacing its configuration.

        API: https://docs.databricks.com/api/azure/workspace/groupsv2/update  
        This endpoint performs a full update of the group’s metadata and entitlements.

        Args:
            group_id (str): Unique identifier of the group.
            update_spec (dict): Dictionary containing updated group configuration.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: API response with updated group details.
        """
        data = {"group_id": group_id, **update_spec}
        return self._post("/api/2.0/groups/update", data, service_principal)

    def patch_group(self, group_id: str, patch_spec: dict, service_principal: bool = False):
        """
        Applies partial updates to an identity group.

        API: https://docs.databricks.com/api/azure/workspace/groupsv2/patch  
        This endpoint modifies specific fields of the group without replacing the entire configuration.

        Args:
            group_id (str): Unique identifier of the group.
            patch_spec (dict): Dictionary containing fields to update.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: API response with patched group details.
        """
        data = {"group_id": group_id, **patch_spec}
        return self._post("/api/2.0/groups/patch", data, service_principal)

    def delete_group(self, group_id: str, service_principal: bool = False):
        """
        Deletes an identity group from the workspace.

        API: https://docs.databricks.com/api/azure/workspace/groupsv2/delete  
        This endpoint removes the specified group and its associated metadata.

        Args:
            group_id (str): Unique identifier of the group.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: API response confirming deletion.
        """
        data = {"group_id": group_id}
        return self._post("/api/2.0/groups/delete", data, service_principal)
    

class PrincipalFederationPoliciesAPI(DatabricksBaseAPI):
    """
    A client class for managing service principal federation policies in Azure Databricks.

    These APIs allow account administrators to configure workload identity federation, enabling secure access
    to Databricks APIs using tokens from external identity providers (IdPs) without storing secrets.

    API Overview: https://docs.databricks.com/api/azure/account/serviceprincipalfederationpolicy
    """

    def create_policy(self, account_id, service_principal_id, project, repo, environment = None, override_payload = None):

        endpoint = f"/api/2.0/accounts/{account_id}/servicePrincipals/{service_principal_id}/federationPolicies"

        if self.SP_TOKEN is None:
            raise Exception("Service principal client token is not set.")

        # Headers
        headers = {
            "Authorization": f"Bearer {self.SP_TOKEN}",
            "Content-Type": "application/json"
            }

        # JSON payload

        if environment is None:
            env_str = ''
        else:
            env_str = f':environment:{environment}'

        if override_payload:
            payload = override_payload
        else:
            payload = {
                "oidc_policy": {
                    "issuer": "https://token.actions.githubusercontent.com",
                    "audiences": [
                        f"https://github.com/{project}"   # CLA GitHub Org repo
                    ],
                    "subject": f"repo:{project}/{repo}{env_str}"       
                }  
            }

        response = requests.post(endpoint, headers=headers, data=json.dumps(payload))

        # Output response
        print("Status Code:", response.status_code)
        print(response.text)        


    def list_policies(self, account_id: str, service_principal_id: str, service_principal: bool = False):
        """
        Lists federation policies for a specific service principal.

        API: https://docs.databricks.com/api/azure/account/serviceprincipalfederationpolicy/list  
        This endpoint returns all federation policies associated with the given service principal.

        Args:
            account_id (str): The Databricks account ID.
            service_principal_id (str): The service principal ID.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: API response containing a list of federation policies.
        """
        endpoint = f"/api/2.0/accounts/{account_id}/servicePrincipals/{service_principal_id}/federationPolicies"
        return self._get(endpoint, service_principal=service_principal)

    # def create_policy(self, account_id: str, policy_spec: dict, service_principal: bool = False):
    #     """
    #     Creates a new service principal federation policy.

    #     API: https://docs.databricks.com/api/azure/account/serviceprincipalfederationpolicy/create  
    #     This endpoint registers a new federation policy for a service principal.

    #     Args:
    #         account_id (str): The Databricks account ID.
    #         policy_spec (dict): Dictionary containing policy configuration.
    #         service_principal (bool): Whether to use service principal authentication.

    #     Returns:
    #         dict: API response with policy creation details.
    #     """
    #     endpoint = f"/api/2.0/accounts/{account_id}/service-principal-federation-policies"
    #     return self._post(endpoint, policy_spec, service_principal)

    def get_policy(self, account_id: str, policy_id: str, service_principal: bool = False):
        """
        Retrieves details of a specific federation policy.

        API: https://docs.databricks.com/api/azure/account/serviceprincipalfederationpolicy/get  
        This endpoint returns metadata and configuration for the specified policy.

        Args:
            account_id (str): The Databricks account ID.
            policy_id (str): Unique identifier of the federation policy.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: API response with policy details.
        """
        endpoint = f"/api/2.0/accounts/{account_id}/service-principal-federation-policies/{policy_id}"
        return self._get(endpoint, service_principal=service_principal)

    def update_policy(self, account_id: str, policy_id: str, update_spec: dict, service_principal: bool = False):
        """
        Updates an existing federation policy.

        API: https://docs.databricks.com/api/azure/account/serviceprincipalfederationpolicy/update  
        This endpoint replaces the configuration of the specified policy.

        Args:
            account_id (str): The Databricks account ID.
            policy_id (str): Unique identifier of the federation policy.
            update_spec (dict): Dictionary containing updated policy configuration.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: API response with updated policy details.
        """
        endpoint = f"/api/2.0/accounts/{account_id}/service-principal-federation-policies/{policy_id}"
        return self._patch(endpoint, update_spec, service_principal)

    def delete_policy(self, account_id: str, policy_id: str,service_principal_id:str, service_principal: bool = False):
        """
        Deletes a federation policy from the account.

        API: https://docs.databricks.com/api/azure/account/serviceprincipalfederationpolicy/delete  
        This endpoint removes the specified federation policy.

        Args:
            account_id (str): The Databricks account ID.
            policy_id (str): Unique identifier of the federation policy.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: API response confirming deletion.
        """
        endpoint = f"/api/2.0/accounts/{account_id}/servicePrincipals/{service_principal_id}/federationPolicies/{policy_id}"
        return self._delete(endpoint, service_principal=service_principal)


class TokenManagementAPI(BaseAPI):
    """
    Azure Databricks Token Management API.

    Provides methods to manage workspace tokens and their permissions.
    Relies on BaseAPI for HTTP helpers (_get, _put, _patch, _delete)
    and authentication routing via the `service_principal` flag.
    """

    def get_permissions(self, service_principal: bool = False) -> dict:
        """
        Get token-management permissions (ACL) at the workspace level.

        Endpoint:
            GET /api/2.0/permissions/token-management

        Documentation:
            https://docs.databricks.com/api/azure/workspace/tokenmanagement/getpermissions

        Args:
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: Permissions response including principal entries and their permission assignments.
        """
        endpoint = "/api/2.0/permissions/token-management"
        return self._get(endpoint, service_principal=service_principal)

    def set_permissions(self, payload: dict, service_principal: bool = False) -> dict:
        """
        Set (replace) token-management permissions.

        Endpoint:
            PUT /api/2.0/permissions/token-management

        Documentation:
            https://docs.databricks.com/api/azure/workspace/tokenmanagement/setpermissions

        Args:
            payload (dict): JSON body defining the new ACL (e.g., {"access_control_list": [...] }).
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: The updated permissions response.
        """
        endpoint = "/api/2.0/permissions/token-management"
        return self._put(endpoint, data=payload, service_principal=service_principal)

    def update_permissions(self, payload: dict, service_principal: bool = False) -> dict:
        """
        Update (patch) token-management permissions.

        Endpoint:
            PATCH /api/2.0/permissions/token-management

        Documentation:
            https://docs.databricks.com/api/azure/workspace/tokenmanagement/updatepermissions

        Args:
            payload (dict): JSON body with partial changes to the ACL.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: The updated permissions response.
        """
        endpoint = "/api/2.0/permissions/token-management"
        return self._patch(endpoint, data=payload, service_principal=service_principal)

    def get_permission_levels(self, service_principal: bool = False) -> dict:
        """
        Get the supported permission levels for token-management.

        Endpoint:
            GET /api/2.0/permissions/token-management/permissionLevels

        Documentation:
            https://docs.databricks.com/api/azure/workspace/tokenmanagement/getpermissionlevels

        Args:
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: Supported permission levels for token-management.
        """
        endpoint = "/api/2.0/permissions/token-management/permissionLevels"
        return self._get(endpoint, service_principal=service_principal)

    def list(self, user_id: str | None = None, service_principal: bool = False) -> dict:
        """
        List tokens (admin-only) with optional filtering by user.

        Endpoint:
            GET /api/2.0/token-management/tokens

        Documentation:
            https://docs.databricks.com/api/azure/workspace/tokenmanagement/list

        Args:
            user_id (str, optional): Subject ID to filter tokens (e.g., a user or service principal ID).
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: Response containing tokens (e.g., {"token_infos": [...] }).
        """
        endpoint = "/api/2.0/token-management/tokens"
        params = {"user_id": user_id} if user_id else None
        return self._get(endpoint, service_principal=service_principal, params=params)

    def get(self, token_id: str, service_principal: bool = False) -> dict:
        """
        Get token info by ID (admin-only).

        Endpoint:
            GET /api/2.0/token-management/tokens/{token_id}

        Documentation:
            https://docs.databricks.com/api/azure/workspace/tokenmanagement/get

        Args:
            token_id (str): The ID of the token to retrieve.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: Token info record.
        """
        endpoint = f"/api/2.0/token-management/tokens/{token_id}"
        return self._get(endpoint, service_principal=service_principal)

    def delete(self, token_id: str, service_principal: bool = False) -> dict:
        """
        Delete (revoke) a token by ID (admin-only).

        Endpoint:
            DELETE /api/2.0/token-management/tokens/{token_id}

        Documentation:
            https://docs.databricks.com/api/azure/workspace/tokenmanagement/delete

        Args:
            token_id (str): The ID of the token to delete.
            service_principal (bool): Whether to use service principal authentication.

        Returns:
            dict: Deletion response (typically empty dict on success).
        """
        endpoint = f"/api/2.0/token-management/tokens/{token_id}"
        return self._delete(endpoint, service_principal=service_principal)


class SettingsAPI(DatabricksBaseAPI):
    """
    Azure Databricks Settings v2 API.

    This class exposes workspace-level Settings v2 endpoints and relies on BaseAPI
    for HTTP helpers (_get, _patch) and authentication routing.
    """

    def list_workspace_settings_metadata(
        self,
        service_principal: bool = False,
        page_size: int = 1000,
        max_pages: int = 1000,  # safety guard
    ) -> list[dict]:
        """
        GET /api/2.1/settings-metadata
        Returns: {"settings_metadata": [...], "next_page_token": "..."} (if more pages)
        """

        endpoint = "/api/2.1/settings-metadata"

        # Databricks caps/coerces at 1000
        page_size = min(int(page_size), 1000)

        results: list[dict] = []
        page_token: str | None = None

        for _ in range(max_pages):
            params = {"page_size": page_size}
            if page_token:
                # IMPORTANT: request param is page_token
                params["page_token"] = page_token

            payload = self._get(endpoint, service_principal=service_principal, params=params) or {}

            # IMPORTANT: response key is settings_metadata
            items = payload.get("settings_metadata") or []
            if not isinstance(items, list):
                raise TypeError(f"Unexpected settings_metadata type: {type(items)}; payload={payload}")

            results.extend(items)

            page_token = payload.get("next_page_token")
            if not page_token:
                break

        return results

    def get_public_workspace_setting(self, setting_name: str, service_principal: bool = False) -> dict:
        """
        Get the current value of a public workspace setting.

        Endpoint:
            GET /api/2.1/settings/{name}

        Behavior:
            - Retrieves the workspace-level value for the specified setting.
            - The response shape depends on the setting; typically includes "value" and may include "effective_value" and "etag".

        Args:
            setting_name: The canonical name of the setting (e.g., "audit_logs", "aibi_dashboard_embedding_access_policy").
            service_principal: Whether to use service principal auth for the request.

        Returns:
            dict: The setting record, including the current value and metadata.

        Example:
            setting = settings_api.get_public_workspace_setting("audit_logs")
        """
        endpoint = f"/api/2.1/settings/{setting_name}"
        return self._get(endpoint, service_principal=service_principal)

    def patch_public_workspace_setting(self, setting_name: str, payload: dict, service_principal: bool = False) -> dict:
        """
        Update a public workspace setting.

        Endpoint:
            PATCH /api/2.1/settings/{name}

        Behavior:
            - Applies an update to the specified workspace setting.
            - Payload typically includes "value" and may include "etag" for optimistic concurrency.
            - Response returns the updated setting record.

        Args:
            setting_name: The canonical name of the setting to update.
            payload: The JSON body for the setting update. Common patterns:
                     {"value": {...}} or {"value": {...}, "etag": "..."} depending on the setting.
            service_principal: Whether to use service principal auth for the request.

        Returns:
            dict: The updated setting record, including the applied value and metadata.

        Example:
            settings_api.patch_public_workspace_setting(
                "audit_logs",
                {"value": {"enabled": True}}
            )
        """
        endpoint = f"/api/2.1/settings/{setting_name}"
        return self._patch(endpoint, data=payload, service_principal=service_principal)

  
