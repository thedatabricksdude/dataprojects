# Databricks notebook source
def dbk_get_token(client_id,client_secret,tenant_id,scope):
    """
    client_id: The client ID for the Azure AD application.
    client_secret: The client secret for the Azure AD application.
    tenant_id: The tenant ID for the Azure AD. 
    """
    import requests

    tenant_id = tenant_id
    client_id = client_id
    client_secret = client_secret
    if not tenant_id and not client_id and not client_secret:
        raise Exception("Please provide the client_id, client_secret and tenant_id")
    resource = dbutils.secrets.get(
        scope=str(scope), key="dbk-resource-id"
    )

    url = f"https://login.microsoftonline.com/{tenant_id}/oauth2/token"
    payload = {
        'grant_type': 'client_credentials',
        'client_id': client_id,
        'client_secret': client_secret,
        'resource': resource
    }

    response = requests.post(url, data=payload)
    token = response.json().get('access_token')
    if not token:
        raise Exception("Unable to get token")

    return token
