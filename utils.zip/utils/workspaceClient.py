# Databricks notebook source
from databricks.sdk import WorkspaceClient

def get_workspace_client(url, token):
  w = WorkspaceClient(
      host=url,
      token=token)
  return w
