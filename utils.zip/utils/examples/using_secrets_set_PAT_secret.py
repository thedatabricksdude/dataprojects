# Databricks notebook source
# DBTITLE 1,Module declarations
import sys
sys.path.append("/Workspace/deployments/etl-databricks-platform-support/files/utils") 

import workspace_api_utils

# COMMAND ----------

# DBTITLE 1,Variable declarations
# Get default workspace URL from Spark config
spark_ws_url = spark.conf.get("spark.databricks.workspaceUrl")
default_workspace_url = f"https://{spark_ws_url}"
print("Default Workspace URL:", default_workspace_url)

# Create widgets with default values
dbutils.widgets.text("widget_workspace_url", spark_ws_url, "Workspace URL Override")
dbutils.widgets.text("widget_token", "", "Token Override")

# Read widget values
widget_workspace_url = dbutils.widgets.get("widget_workspace_url")
widget_token = dbutils.widgets.get("widget_token")

# Final workspace URL
workspace_url = f"https://{widget_workspace_url}" if widget_workspace_url else default_workspace_url
print("Workspace URL:", workspace_url)

current_user = spark.sql("SELECT current_user()").collect()[0][0]
print("Current user:", current_user)

# Retrieve token from secret scope api tokens using dbx id as the key
# Need to create api_tokens scope and key is the dbx id/email with the value set to the user's token and only they and SPNs granted read access on the secret
# Create script to allow users to simply add token to api_tokens scope using widgets
try:
    my_token = dbutils.secrets.get(scope=f"{current_user}", key="api_token")
except Exception as e:
    print("Could not retrieve token from secrets:", e)
    my_token = ""

# Override with widget token if provided
if widget_token:
    my_token = widget_token

print("Token is set:", "*" * len(my_token))  # Obscure output for security


# COMMAND ----------

import os
os.environ["WORKSPACE"] = 'adb-1881585681447865.5'

# COMMAND ----------

# DBTITLE 1,Job API class instantiation / authentication
#initialize a variable named my_secrets with the SecretsAPI class in workspace_api_utils
#requires workspace_url and matching token in my_token to authenticate to the API
my_secrets = workspace_api_utils.SecretsAPI(workspace_url,my_token)

# COMMAND ----------

scope_list = my_secrets.list_scopes()

display(scope_list)

# COMMAND ----------

no_access = []
for scope in scope_list['scopes']:
  print('SCOPE: ',scope['name'])
  try:
    secrets_list = my_secrets.list_secrets(scope['name'],service_principal=True)
    display(secrets_list)      
  except:
    no_access.append(scope['name'])
print(no_access)



# COMMAND ----------

# DBTITLE 1,Create scope
scope_list = my_secrets.create_scope(current_user)

display(scope_list)

# COMMAND ----------

# DBTITLE 1,List ACLs for scope
acl_list = my_secrets.list_acls(current_user)

display(acl_list)

# COMMAND ----------

# DBTITLE 1,Set PAT secret
my_secrets.put_secret(current_user,'api_token',my_token)

# COMMAND ----------

secrets_list = my_secrets.list_secrets(current_user)

display(secrets_list)

# COMMAND ----------

token = my_secrets.get_client_token(scope='ops-support-key-vault-secret-dev', client_id_secret='AppReg-da-dev-dc01-analytics-fw-bk-dbk-admin-jobs-worker-ClientID', client_secret_secret='AppReg-da-dev-dc01-analytics-fw-bk-dbk-admin-jobs-worker-ClientSecret')

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE platform_admin.metadata.secrets_scopes

# COMMAND ----------

my_secrets.write_table(service_principal=False)
#my_secrets.list_secrets(scope='key-vault-secret', service_principal=True)

# COMMAND ----------

my_secrets.write_acls_table(service_principal=False)
=======

my_secrets.write_table(service_principal=False)
#my_secrets.list_secrets(scope='key-vault-secret', service_principal=True)
