# Databricks notebook source
# DBTITLE 1,Module declarations
import sys
sys.path.append("/Workspace/deployments/etl-databricks-platform-support/files/utils") 

import workspace_api_utils
import os, re

# COMMAND ----------

# DBTITLE 1,Variable declarations
workspace_url = "https://adb-1881585681447865.5.azuredatabricks.net"
workspace_name = "da-dev-dc01-analytics-fw-bk"
principal = "da-dev-dc01-analytics-fw-bk-dbk-admin-jobs-worker"
principal_id = "fe90eb19-69b5-4440-8330-ece7512ec02b"
scope = "ops-support-key-vault-secret-dev"

client_id_secret = f"AppReg-{principal}-ClientID"
client_secret_secret = f"AppReg-{principal}-ClientSecret"

workspace = re.sub(r"^https://", "", workspace_url)
workspace = re.sub(r"\.\d+\.azuredatabricks\.net.*$", "", workspace)

os.environ["WORKSPACE"] = workspace

# Extract the workspace ID between 'adb-' and the first dot before '.azuredatabricks.net'
match = re.search(r"adb-(\d+)", workspace_url)
workspace_id = match.group(1) if match else None

scope2 = "key-vault-secrets"
account_id = '6a3b960d-4be7-4eea-a98a-93dc0193e2c5'

print('workspace url', workspace_url)
print('workspace name:', workspace_name)
print("workspace:", workspace)
print("workspace_id:", workspace_id)

# COMMAND ----------

# DBTITLE 1,Job API class instantiation / authentication
#initialize a variable named my_jobs with the JobsAPI class in workspace_api_utils
#requires workspace_url and matching token in my_token to authenticate to the API

my_jobs = workspace_api_utils.JobsAPI(databricks_instance = workspace_url, client_id_secret_key = client_id_secret, client_secret_secret_key = client_secret_secret, scope = scope, scope2 = scope2)
my_pipelines = workspace_api_utils.PipelineAPI(databricks_instance = workspace_url, client_id_secret_key = client_id_secret, client_secret_secret_key = client_secret_secret, scope = scope, scope2 = scope2)


# COMMAND ----------

# DBTITLE 1,Update a pipeline tag
pipeline_id = my_pipelines.get_pipeline_id_by_name('test',True)

my_pipeline = my_pipelines.get_pipeline(pipeline_id, service_principal=True)

print(my_pipeline)

updates = {
    "tags": {
        "Project": "N/A"
    }
}

my_pipelines.update_pipeline_tags(updates,pipeline_id,service_principal=True)


# COMMAND ----------

# DBTITLE 1,Update a job tag
job_id = 841283847603142

updates = {
    "tags": {
        "Project": "N/A"
    }
}

my_jobs.update_job_tags(updates,job_id,service_principal=True)
