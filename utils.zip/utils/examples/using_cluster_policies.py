# Databricks notebook source
# DBTITLE 1,Module declarations
import sys
sys.path.append("/Workspace/deployments/etl-databricks-platform-support/files/utils") 

import workspace_api_utils

# COMMAND ----------

# DBTITLE 1,Variable declarations
# Get default workspace URL from Spark config
spark_ws_url = spark.conf.get("spark.databricks.workspaceUrl")
default_workspace_url = f"https://{spark_ws_url}"
print("Default Workspace URL:", default_workspace_url)

# Create widgets with default values
dbutils.widgets.text("widget_workspace_url", spark_ws_url, "Workspace URL Override")
dbutils.widgets.text("widget_token", "", "Token Override")

# Read widget values
widget_workspace_url = dbutils.widgets.get("widget_workspace_url")
widget_token = dbutils.widgets.get("widget_token")

# Final workspace URL
workspace_url = f"https://{widget_workspace_url}" if widget_workspace_url else default_workspace_url
print("Workspace URL:", workspace_url)

current_user = spark.sql("SELECT current_user()").collect()[0][0]
print("Current user:", current_user)

# Retrieve token from secret scope api tokens using dbx id as the key
# Need to create scope is the dbx id/email with the key api_token and value set to the user's token and only they and SPNs granted read access on the scope
# Create script to allow users to simply add token to api_tokens scope using widgets
try:
    my_token = dbutils.secrets.get(scope=f"{current_user}", key="api_token")
except Exception as e:
    print("Could not retrieve token from secrets:", e)
    my_token = ""

# Override with widget token if provided
if widget_token:
    my_token = widget_token

print("Token is set:", "*" * len(my_token))  # Obscure output for security


# COMMAND ----------

# DBTITLE 1,Instantiate ClustersAPI class as my_cluster and authenticate
my_cluster = workspace_api_utils.ClustersAPI(workspace_url,my_token)

# COMMAND ----------

# DBTITLE 1,List cluster policies
cluster_policies = my_cluster.list_policies()
display(cluster_policies)

# COMMAND ----------

# policy id below changes in each environment and can be found in the list of policies in the previous cell
this_policy = my_cluster.get_policy('D96308F1BF000A4B')
display(this_policy)

# COMMAND ----------

import os

os.environ["WORKSPACE_NAME"] = 'da-dev-dc01-analytics-fw-bk'
os.environ["WORKSPACE_ID"] = 'adb-1881585681447865.5'

# COMMAND ----------

# DBTITLE 0,w
my_cluster.write_table_policies()
