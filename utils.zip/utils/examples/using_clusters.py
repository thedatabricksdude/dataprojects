# Databricks notebook source
# DBTITLE 1,Module declarations
import sys
sys.path.append("/Workspace/deployments/etl-databricks-platform-support/files/utils") 

import workspace_api_utils

# COMMAND ----------

# DBTITLE 1,Variable declarations
# Get default workspace URL from Spark config
spark_ws_url = spark.conf.get("spark.databricks.workspaceUrl")
default_workspace_url = f"https://{spark_ws_url}"
print("Default Workspace URL:", default_workspace_url)

# Create widgets with default values
dbutils.widgets.text("widget_workspace_url", spark_ws_url, "Workspace URL Override")
dbutils.widgets.text("widget_token", "", "Token Override")
dbutils.widgets.text("env", "", "Environment (dev/tst/prd)")

# Read widget values
widget_workspace_url = dbutils.widgets.get("widget_workspace_url")
widget_token = dbutils.widgets.get("widget_token")
env = dbutils.widgets.get("env")

# Final workspace URL
workspace_url = f"https://{widget_workspace_url}" if widget_workspace_url else default_workspace_url
print("Workspace URL:", workspace_url)

current_user = spark.sql("SELECT current_user()").collect()[0][0]
print("Current user:", current_user)

# Retrieve token from secret scope api tokens using dbx id as the key
# Need to create api_tokens scope and key is the dbx id/email with the value set to the user's token and only they and SPNs granted read access on the secret
# Create script to allow users to simply add token to api_tokens scope using widgets
try:
    my_token = dbutils.secrets.get(scope=F"{current_user}", key="api_token")
except Exception as e:
    print("Could not retrieve token from secrets:", e)
    my_token = ""

# Override with widget token if provided
if widget_token:
    my_token = widget_token

print("Token is set:", "*" * len(my_token))  # Obscure output for security


# COMMAND ----------

# DBTITLE 1,Sample cluster payload
#example cluster payload - can be saved from UI to base the cluster off of another cluster
# future class addition - ClustersAPI.CloneCluster(cluster_id, **kwargs for properties to update) - clone a cluster without providing payload

cluster_payload = {
    "cluster_name": "FrameworkCluster Testing",
    "spark_version": "13.3.x-scala2.12",
    "spark_conf": {
        "spark.databricks.delta.preview.enabled": "true",
        "spark.hadoop.datanucleus.connectionPoolingType": "hikari",
    },
    "azure_attributes": {
        "first_on_demand": 1,
        "availability": "ON_DEMAND_AZURE",
        "spot_bid_max_price": -1,
    },
    "node_type_id": "Standard_D64s_v3",
    "driver_node_type_id": "Standard_D32s_v3",
    "cluster_log_conf": {
        "dbfs": {
            "destination": "dbfs:/cluster-logs"
        }
    },
    "spark_env_vars": {
        "DISABLE_WEB_TERMINAL": "true"
    },
    "autotermination_minutes": 20,
    "enable_elastic_disk": True,
    "init_scripts": [
        {
            "volumes": {
                "destination": "/Volumes/de_prd/volume/init_script/pyodbc-install.sh"
            }
        }
    ],
    "enable_local_disk_encryption": False,
    "data_security_mode": "USER_ISOLATION",
    "runtime_engine": "PHOTON",
    "autoscale": {
        "min_workers": 2,
        "max_workers": 10
    },
    "apply_policy_default_values": False
}

# COMMAND ----------

# DBTITLE 1,Instantiate ClustersAPI class/authentication
my_cluster = workspace_api_utils.ClustersAPI(workspace_url,my_token)


# COMMAND ----------

# DBTITLE 1,List clusters
cluster_list = my_cluster.list_clusters(service_principal='true')

display(cluster_list)

# COMMAND ----------

my_cluster.write_table_clusters()

# COMMAND ----------

# DBTITLE 1,Assign SPN token
# need to verify these secrets only difference is prd/tst/dev, etc
# need an environment variable with proper scope for environment
scope = f"ops-support-key-vault-secret-{env}"
tenant_id =  dbutils.secrets.get(scope = f'{scope}' , key ="tenant-id")
client_id = dbutils.secrets.get(scope =f'{scope}' , key =f"AppReg-da-{env}-dc01-analytics-fw-bk-dbk-admin-jobs-worker-ClientID")
client_secret = dbutils.secrets.get(scope =f'{scope}', key =f"AppReg-da-{env}-dc01-analytics-fw-bk-dbk-admin-jobs-worker-ClientSecret")
resource = dbutils.secrets.get(scope =f'{scope}' , key ="dbk-resource-id")
my_cluster.get_client_token(client_id,client_secret,tenant_id,resource)

# COMMAND ----------

# DBTITLE 1,Create new cluster from json payload and created by SPN
my_cluster.create_cluster(json_data=cluster_payload, service_principal=True)
