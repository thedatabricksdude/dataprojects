# Databricks notebook source
# DBTITLE 1,Module declarations
import sys
sys.path.append("/Workspace/deployments/etl-databricks-platform-support/files/utils") 

import workspace_api_utils

# COMMAND ----------

# DBTITLE 1,Variable declarations
# Get default workspace URL from Spark config
spark_ws_url = spark.conf.get("spark.databricks.workspaceUrl")
default_workspace_url = f"https://{spark_ws_url}"
print("Default Workspace URL:", default_workspace_url)

# Create widgets with default values
dbutils.widgets.text("widget_workspace_url", spark_ws_url, "Workspace URL Override")
dbutils.widgets.text("widget_token", "", "Token Override")

# Read widget values
widget_workspace_url = dbutils.widgets.get("widget_workspace_url")
widget_token = dbutils.widgets.get("widget_token")

# Final workspace URL
workspace_url = f"https://{widget_workspace_url}" if widget_workspace_url else default_workspace_url
print("Workspace URL:", workspace_url)

current_user = spark.sql("SELECT current_user()").collect()[0][0]
print("Current user:", current_user)

# Retrieve token from secret scope api tokens using dbx id as the key
# Need to create api_tokens scope and key is the dbx id/email with the value set to the user's token and only they and SPNs granted read access on the secret
# Create script to allow users to simply add token to api_tokens scope using widgets
try:
    my_token = dbutils.secrets.get(scope=f"{current_user}", key="api_token")
except Exception as e:
    print("Could not retrieve token from secrets:", e)
    my_token = ""

# Override with widget token if provided
if widget_token:
    my_token = widget_token

print("Token is set:", "*" * len(my_token))  # Obscure output for security


# COMMAND ----------

# DBTITLE 1,Job API class instantiation / authentication
#initialize a variable named my_jobs with the JobsAPI class in workspace_api_utils
#requires workspace_url and matching token in my_token to authenticate to the API
my_principals = workspace_api_utils.ServicePrincipalsAPI(workspace_url,my_token)

# COMMAND ----------

principals_list = my_principals.list_service_principals()

display(principals_list)

# COMMAND ----------

display(my_principals.get_service_principal(470645144310150))

# COMMAND ----------

my_principals.write_table()

# COMMAND ----------

my_secrets = workspace_api_utils.ServicePrincipalSecretsProxyAPI(workspace_url,my_token) 

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, BooleanType, ArrayType

df_principals = None


schema = StructType([
    StructField("displayName", StringType(), True),
    StructField("id", StringType(), True),
    StructField("applicationId", StringType(), True),
    StructField("active", BooleanType(), True),
    StructField("groups", ArrayType(StringType()), True),
    StructField("entitlements", ArrayType(
        StructType([
            StructField("value", StringType(), True)
        ])
    ), True)
])

for principal in principals_list['Resources']:
  print([principal])
  secret_list = my_secrets.list_secrets(principal['id'])
  if df_principals is None:
    df_principals = spark.createDataFrame([principal], schema)
  else:
    df_principals = df_principals.union(spark.createDataFrame([principal], schema))
                                        
df_principals.display()

# COMMAND ----------

secret_list = [{"test":"test_value"}]

my_secrets.create_secrets(7841501468404104,secret_list)
my_secrets.create_secrets(1653499494251601,secret_list)


# COMMAND ----------

my_secrets.list_secrets(7841501468404104)
