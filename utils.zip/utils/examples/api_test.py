from workspace_api_utils import ClustersAPI


clusterx = ClustersAPI(
  databricks_instance='',
  scope = "",
  client_id_secret_key ="",
  client_secret_secret_key =""
)

print(clusterx.__getattribute__)