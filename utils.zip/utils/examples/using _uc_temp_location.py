# Databricks notebook source
# MAGIC %run ../uc_temp_location

# COMMAND ----------

import pandas as pd
# Create a sample DataFrame
data = {'Name': ['Alice', 'Bob', 'Charlie'], 'Age': [25, 30, 35]}
df = pd.DataFrame(data)
print(df.head(5))

# Usage example
with UcTempVolume('de_dev','myvolume') as volume:
    #volume.write_file('myfile4', '.csv', b'Hello World!')
    temp_csv_path = os.path.join(volume.tmp_path, 'myfile7.csv')
    print(f"Writing DataFrame to {temp_csv_path}")
    
    df.to_csv(temp_csv_path, index=False)
    print(f"DataFrame written to {temp_csv_path}")

# COMMAND ----------

