# Databricks notebook source
# DBTITLE 1,sys
import sys
sys.path.append("/Workspace/deployments/etl-databricks-platform-support/files/utils") 

import workspace_api_utils
