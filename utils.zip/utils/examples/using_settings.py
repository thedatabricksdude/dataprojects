# Databricks notebook source
# DBTITLE 1,Module declarations
import sys, re, os
sys.path.append("/Workspace/Users/john.ertel@cliftonlarsonallen.onmicrosoft.com/etl-databricks-platform-support-2/utils") 

import workspace_api_utils

# COMMAND ----------

# DBTITLE 1,Variable declarations
workspace_url = "https://adb-1881585681447865.5.azuredatabricks.net"
workspace_name = "da-dev-dc01-analytics-fw-bk"
principal = "da-dev-dc01-analytics-fw-bk-dbk-admin-jobs-worker"
principal_id = "fe90eb19-69b5-4440-8330-ece7512ec02b"
scope = "ops-support-key-vault-secret-dev"

client_id_secret = f"AppReg-{principal}-ClientID"
client_secret_secret = f"AppReg-{principal}-ClientSecret"

workspace = re.sub(r"^https://", "", workspace_url)
workspace = re.sub(r"\.\d+\.azuredatabricks\.net.*$", "", workspace)

os.environ["WORKSPACE"] = workspace

# Extract the workspace ID between 'adb-' and the first dot before '.azuredatabricks.net'
match = re.search(r"adb-(\d+)", workspace_url)
workspace_id = match.group(1) if match else None

scope2 = "key-vault-secrets"
account_id = '6a3b960d-4be7-4eea-a98a-93dc0193e2c5'

print('workspace url', workspace_url)
print('workspace name:', workspace_name)
print("workspace:", workspace)
print("workspace_id:", workspace_id)

#initialize a variable named my_jobs with the JobsAPI class in workspace_api_utils
#requires workspace_url and matching token in my_token to authenticate to the API

my_settings = workspace_api_utils.SettingsAPI(databricks_instance = workspace_url, client_id_secret_key = client_id_secret, client_secret_secret_key = client_secret_secret, scope = scope, scope2 = scope2)



# COMMAND ----------

settings = my_settings.list_workspace_settings_metadata(service_principal=True)
display(settings)

setting1 = my_settings.get_public_workspace_setting(setting_name='abac_rls_cm',service_principal=True)
print(setting1)


