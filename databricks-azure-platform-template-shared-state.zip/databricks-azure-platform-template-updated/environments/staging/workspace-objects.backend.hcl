resource_group_name  = "rg-tdp-shared-tfstate"
storage_account_name = "sttdpterraformstate"
container_name       = "tfstate-qa"
key                  = "workspace-objects/staging.tfstate"
use_azuread_auth     = true
