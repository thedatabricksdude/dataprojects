databricks_account_id = "00000000-0000-0000-0000-000000000000"
region_code           = "wus2"

foundation_state = {
  resource_group_name  = "rg-tdp-shared-tfstate"
  storage_account_name = "sttdpterraformstate"
  container_name       = "tfstate-qa"
  key                  = "foundation/qa.tfstate"
  use_azuread_auth     = true
}

unity_catalog = {
  enabled                         = true
  metastore_name                  = "uc-qa-wus2"
  owner                           = "dbx-wus2-platform-metastore-admin"
  admin_workspace_key             = "enterpriseapps-dev"
  metastore_storage_workspace_key = "enterpriseapps-dev"
  metastore_storage_container     = "gold"
  metastore_storage_subpath       = "unity-catalog/metastore"
}

catalogs = {
  telcor = {
    comment               = "Example managed catalog"
    owner                 = "dbx-wus2-platform-metastore-admin"
    storage_workspace_key = "enterpriseapps-dev"
    storage_container     = "gold"
    storage_subpath       = "catalogs/telcor"
    schemas = {
      claims = {
        comment = "Claims domain"
      }
      finance = {
        comment = "Finance domain"
      }
    }
  }
}

cluster_policy_templates = {
  personal-dev = {
    workspace_key = "enterpriseapps-dev"
    name          = "Personal Compute"
    template      = "personal-compute"
    max_dbu       = 10
    permissions = {
      "dbx-wus2-enterpriseapps-dev-workspace-admin" = "CAN_MANAGE"
      "dbx-wus2-enterpriseapps-dev-data-engineer"   = "CAN_USE"
      "dbx-wus2-enterpriseapps-dev-data-scientist"  = "CAN_USE"
    }
  }

  jobs-prod = {
    workspace_key = "enterpriseapps-prod"
    name          = "Job Compute"
    template      = "job-compute"
    max_dbu       = 20
    permissions = {
      "dbx-wus2-enterpriseapps-audit-prod-workspace-admin" = "CAN_MANAGE"
      "dbx-wus2-enterpriseapps-audit-prod-data-engineer"   = "CAN_USE"
    }
  }
}

sql_warehouses = {
  analyst-dev = {
    workspace_key    = "enterpriseapps-dev"
    name             = "Analyst SQL"
    cluster_size     = "Small"
    min_num_clusters = 1
    max_num_clusters = 1
    auto_stop_mins   = 30
    permissions = {
      "dbx-wus2-enterpriseapps-dev-workspace-admin"            = "CAN_MANAGE"
      "dbx-wus2-enterpriseapps-dev-data-analyst"               = "CAN_USE"
      "dbx-wus2-enterpriseapps-dev-business-consumer-readonly" = "CAN_USE"
    }
  }
}
