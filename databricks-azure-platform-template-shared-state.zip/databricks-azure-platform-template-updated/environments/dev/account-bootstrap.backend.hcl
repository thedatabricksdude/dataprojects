resource_group_name  = "rg-tdp-shared-tfstate"
storage_account_name = "sttdpterraformstate"
container_name       = "tfstate-dev"
key                  = "account-bootstrap/dev.tfstate"
use_azuread_auth     = true
