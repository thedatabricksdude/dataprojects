# Azure Databricks private-link platform template

This repository is the **Databricks-side project** in a two-repository operating model:

- the companion **Azure platform bootstrap repository** creates shared Azure prerequisites such as state, Microsoft Entra identity, Key Vault, and the self-hosted Azure DevOps agent VNet/VM
- this repository creates the **Databricks foundation** and then the **Databricks account/workspace objects**

The core pattern you wanted remains true:

1. **Azure networking, storage, access connectors, private endpoints, DNS, and workspaces** are managed in one Terraform root: `roots/foundation`
2. **Unity Catalog objects, grants, cluster policies, SQL warehouses, group assignments, and entitlements** are managed in another Terraform root: `roots/workspace_objects`
3. Shared identifiers cross the boundary through **remote state outputs**, not by collapsing everything into one state file
4. Environments map to **different backend configs / state locations**, not only different var files

A small extra helper root is included:

- `roots/account_bootstrap`: a one-time local bootstrap that registers the Azure deployment service principal inside the Databricks account and can grant it the `account_admin` role. This is needed before unattended workspace-object pipelines can run with a Microsoft Entra service principal.

## Repository layout

```text
.
├── bootstrap/
│   └── state_backend/
├── docs/
├── environments/
│   ├── dev/
│   ├── qa/
│   └── prod/
├── modules/
│   ├── azure/
│   │   ├── landing_zone/
│   │   ├── private_endpoint/
│   │   └── web_auth_host/
│   └── databricks/
│       ├── catalog_bundle/
│       ├── cluster_policy_template/
│       └── sql_warehouse/
├── pipelines/
│   ├── templates/
│   └── vars/
├── reference/
├── roots/
│   ├── account_bootstrap/
│   ├── foundation/
│   └── workspace_objects/
├── scripts/
└── sql/
```

## Where this repo fits in the real bootstrap order

The first private-link deployment is staged across both repositories:

1. Azure bootstrap repo: create state backend
2. Azure bootstrap repo: create resource groups, Key Vault, Microsoft Entra deployment identity, **and the IT-managed self-hosted agent VM**
3. This repo: run `roots/foundation` from the self-hosted agent pipeline
4. Azure bootstrap repo: run `roots/agent_runtime` to peer the self-hosted agent VNet to the Databricks VNets and link private DNS
5. This repo: run `roots/account_bootstrap` once from a local/admin context
6. This repo: use the Azure DevOps pipeline on the self-hosted agent for normal `workspace_objects` plan/apply jobs

## Why the first foundation apply no longer needs to be local

The IT-managed self-hosted agent VM is now created **before** the Databricks foundation. It can be registered into Azure DevOps without already being peered to the Databricks VNets.

That breaks the bootstrap deadlock:
- the self-hosted agent exists early
- `foundation` can run on that agent
- peerings and DNS links can be added afterward in `agent_runtime`

## Typical commands

### 1) One-time Databricks account bootstrap

```bash
cd roots/account_bootstrap
terraform init -backend-config=../../environments/dev/account-bootstrap.backend.hcl
terraform plan -var-file=../../environments/dev/account-bootstrap.auto.tfvars
terraform apply -var-file=../../environments/dev/account-bootstrap.auto.tfvars
```

### 2) Workspace objects

```bash
cd roots/workspace_objects
terraform init -backend-config=../../environments/dev/workspace-objects.backend.hcl
terraform plan -var-file=../../environments/dev/workspace-objects.auto.tfvars
terraform apply -var-file=../../environments/dev/workspace-objects.auto.tfvars
```

## Pipeline model

The included Azure DevOps pipeline assumes:
- jobs run on a **self-hosted agent** in Azure
- the self-hosted VM uses its **managed identity** to read the deployment service principal secrets from Key Vault at runtime
- Terraform then authenticates to Azure and Azure Databricks by exporting those secrets as environment variables

That avoids storing Azure client secrets directly in Azure DevOps.

## Start with the docs

Read these in order:

0. `docs/Databricks_Azure_Platform_Guide.docx`
1. `docs/00-architecture-overview.md`
2. `docs/01-file-by-file-walkthrough.md`
3. `docs/02-deployment-runbook.md`
4. `docs/03-design-defense-notes.md`
5. `docs/04-gotchas.md`
6. `docs/05-naming-and-rbac-model.md`
7. `docs/07-self-hosted-agent-and-pipeline.md`
8. `docs/08-account-bootstrap.md`


## Existing Terraform state storage

This template assumes the Terraform state storage account already exists and is not owned by this Terraform package:

- Resource group: `rg-tdp-shared-tfstate`
- Storage account: `sttdpterraformstate`
- Containers: `tfstate-dev`, `tfstate-qa`, `tfstate-prod`

Terraform backend `key` values are unique blob paths inside those containers, for example `foundation/dev.tfstate` or `workspace-objects/staging.tfstate`. Staging intentionally uses the `tfstate-qa` container with staging-specific keys. No additional state containers are required unless you want stricter operational separation later.

Do not import the shared storage account into these roots unless you intend this package to manage it. The current configuration treats it as pre-existing infrastructure and uses it only as the backend target.
