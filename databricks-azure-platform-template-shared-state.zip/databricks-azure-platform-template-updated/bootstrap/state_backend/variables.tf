variable "subscription_id" {
  description = "Optional Azure subscription ID. If null, Azure CLI / managed identity context is used."
  type        = string
  default     = null
}

variable "resource_group_name" {
  description = "Existing resource group containing the shared Terraform backend storage account."
  type        = string
}

variable "location" {
  description = "Azure region for the backend storage account."
  type        = string
}

variable "storage_account_name" {
  description = "Existing shared Terraform state storage account name."
  type        = string
}

variable "container_names" {
  description = "Existing blob containers used for Terraform state. They are validated/returned, not created."
  type        = set(string)
  default     = ["tfstate-dev", "tfstate-qa", "tfstate-prod"]
}

variable "tags" {
  description = "Tags for the backend storage account."
  type        = map(string)
  default     = {}
}
