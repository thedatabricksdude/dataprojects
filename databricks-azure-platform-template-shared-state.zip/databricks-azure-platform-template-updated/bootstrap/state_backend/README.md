# State backend bootstrap helper

Use this helper only if the remote-state storage account and container do not already exist.

This root intentionally uses normal local Terraform behavior. After it verifies the existing backend storage account settings, the two main roots can use the AzureRM backend.
