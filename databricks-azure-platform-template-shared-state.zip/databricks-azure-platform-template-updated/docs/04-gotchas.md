# Gotchas

## 1. Backend bootstrap is a chicken-and-egg problem

A remote backend must generally exist before `terraform init` can use it.

That is why this repository treats backend creation as a separate concern.

## 2. The compliance profile is not something to flip lightly

If you enable the compliance security profile or remove standards later, the workspace may require replacement. Treat those settings as near-permanent design choices.

## 3. Storage account names must be globally unique

Terraform cannot solve global namespace collisions by itself unless you let it randomize names. In this template you provide explicit names so you can defend and standardize them, but that means uniqueness is your responsibility.

## 4. Private DNS is where many deployments fail

If DNS forwarding, existing zone IDs, or VNet links are wrong, the private endpoints may exist but the workspace still feels “broken.”

Symptoms often look like:

- web sign-in loops
- timeouts opening the workspace UI
- clusters failing to reach control plane services
- private storage endpoints resolving inconsistently

## 5. Browser auth is a shared dependency

In a region where multiple workspaces share the same private DNS design, deleting the host for the `browser_authentication` endpoint can break browser SSO across those workspaces.

## 6. `databricks_grants` is authoritative

If someone manually adds privileges in the UI and Terraform manages that same securable with `databricks_grants`, the next apply will reconcile back to the Terraform definition.

That is a feature, not a bug, but teams need to know it.

## 7. Role assignments can be eventually consistent

Azure RBAC assignments for the access connector can take time to propagate. If Unity Catalog creation is attempted immediately after the first foundation deployment, you may need a short pause or a second apply in the workspace-objects root.

## 8. One metastore per region is the normal pattern

Do not casually create multiple metastores in one region unless you truly understand why you need them. The common enterprise pattern is one metastore per region / environment boundary.

## 9. Workspace keys are part of the contract

The `landing_zones` map key is used in remote state and in the second root. Renaming keys later is possible, but it is a structural change, not a cosmetic one.

## 10. Do not hand-edit state to “fix” normal drift

Import, moved blocks, and planned refactoring are safer than manual state surgery.

## 11. The bootstrap deadlock is solved by using the IT-managed agent VM

In this updated pattern, the companion Azure bootstrap repository creates the IT-managed self-hosted Azure DevOps VM before the Databricks foundation exists. That lets the first `foundation` pipeline run from the self-hosted agent, and then the follow-up agent-runtime root adds VNet peerings and private DNS links after the Databricks VNets exist.

## 12. Azure service principals and Databricks service principals are not the same thing

Creating the deployment service principal in Microsoft Entra does not automatically make it a Databricks account principal. The one-time `roots/account_bootstrap` helper closes that gap.
