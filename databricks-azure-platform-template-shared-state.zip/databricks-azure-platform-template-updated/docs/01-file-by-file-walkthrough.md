# File-by-file walkthrough

This guide is meant to help you explain the code to someone else, not just run it.

## Root: `bootstrap/state_backend`

This is a one-time helper root.

- `versions.tf`: Terraform and provider version constraints.
- `providers.tf`: AzureRM provider configuration.
- `variables.tf`: Inputs for the pre-existing resource group, shared backend storage account, and container names.
- `main.tf`: Creates the storage account and blob container used by the remote state backends.
- `outputs.tf`: Prints the exact backend values you can copy into the environment backend files.

Why it exists:
A remote backend usually must already exist before `terraform init` on the main roots can succeed.

## Root: `roots/foundation`

This is the Azure landing-zone root.

- `backend.tf`: Empty AzureRM backend declaration. Backend values come from `-backend-config` files per environment.
- `versions.tf`: Terraform and provider constraints.
- `providers.tf`: AzureRM and Random providers.
- `variables.tf`: Main input contract for the hub, shared services, and workload landing zones.
- `data.tf`: Looks up the pre-created resource groups and the current tenant context.
- `locals.tf`: Central naming and tagging helpers.
- `main.tf`: Creates the shared hub resources, DNS zones, optional web-auth workspace, and calls the landing-zone module for each workspace.
- `outputs.tf`: Exports the remote-state contract consumed by the Databricks objects root.

### Foundation modules

#### `modules/azure/private_endpoint`
A small reusable wrapper that standardizes Azure private endpoint creation.

#### `modules/azure/web_auth_host`
Creates the dedicated web-auth host workspace and the `browser_authentication` private endpoint.

#### `modules/azure/landing_zone`
Creates one spoke landing zone:
- VNet and subnets
- optional route table
- NSG and subnet associations
- VNet peerings
- ADLS Gen2
- Key Vault
- Databricks access connector
- Databricks workspace
- private endpoints
- DNS links
- optional diagnostics

## Root: `roots/account_bootstrap`

This is a one-time Databricks account bootstrap helper.

- `backend.tf`: AzureRM backend declaration for the helper state.
- `versions.tf`: Databricks provider version constraint.
- `providers.tf`: Account-level Databricks provider configured for `azure-cli` auth.
- `variables.tf`: Inputs for Databricks account ID and the Azure deployment service principal identifiers.
- `main.tf`: Registers the Azure deployment service principal inside the Databricks account and optionally grants `account_admin`.
- `outputs.tf`: Emits the Databricks service principal ID.

Why it exists:
The Azure deployment service principal must also exist as a Databricks account principal before unattended workspace-object Terraform can run with service-principal auth.

## Root: `roots/workspace_objects`

This is the Databricks objects root.

- `backend.tf`: Empty AzureRM backend declaration.
- `versions.tf`: Terraform and Databricks provider constraints.
- `providers.tf`: Databricks account-level provider.
- `variables.tf`: Inputs for remote state lookup, naming, Unity Catalog, cluster policies, and SQL warehouses.
- `remote_state.tf`: Reads outputs from the `foundation` root.
- `locals.tf`: Builds group names, persona maps, and reusable derived structures.
- `groups.tf`: Creates account groups, assigns them to workspaces, and grants workspace entitlements.
- `unity_catalog.tf`: Creates the metastore, assignments, storage credentials, and catalog modules.
- `cluster_policies.tf`: Instantiates reusable cluster policy templates per workspace.
- `sql_warehouses.tf`: Instantiates SQL warehouses per workspace.
- `outputs.tf`: Emits useful IDs and names for inspection.

### Databricks modules

#### `modules/databricks/catalog_bundle`
Creates a catalog bundle:
- optional external location
- catalog
- schemas
- authoritative grants for catalog and schemas

#### `modules/databricks/cluster_policy_template`
Renders and creates a policy from a named template like `personal-compute`, `shared-autoscaling`, or `job-compute`.

#### `modules/databricks/sql_warehouse`
Creates one SQL warehouse and applies access controls.

## Pipelines and scripts

### `azure-pipelines.yml`
Defines the Azure DevOps pipeline that plans and applies `foundation` and `workspace_objects` on a self-hosted agent.

### `pipelines/vars/*.yml`
Environment-specific non-secret pipeline settings such as agent pool name, Key Vault name, and file paths.

### `scripts/fetch_kv_env.sh`
Logs into Azure using the self-hosted VM's managed identity, reads the deployment secrets from Key Vault, and exports the environment variables Terraform expects.

### `scripts/terraform_root_plan.sh` and `scripts/terraform_root_apply.sh`
Reusable shell wrappers that standardize init / validate / plan / apply across roots.
