# Local edits made for shared Terraform state

## State backend

- The backend storage account is now treated as pre-existing infrastructure.
- Shared state storage account:
  - Resource group: `rg-tdp-shared-tfstate`
  - Storage account: `sttdpterraformstate`
- Existing containers used:
  - `tfstate-dev`
  - `tfstate-qa`
  - `tfstate-prod`
- Backend keys are unique blob paths such as `foundation/dev.tfstate` and `workspace-objects/prod.tfstate`.

## Staging

- Added `environments/staging` as a starter environment copied from QA.
- Staging uses the existing `tfstate-qa` container.
- Staging uses unique keys such as `foundation/staging.tfstate`, so it does not overwrite QA state.
- Review the staging workspace names, resource group names, Key Vault names, and workspace-object references before applying. They are starter values, not magic, because apparently Terraform still refuses to read minds.
