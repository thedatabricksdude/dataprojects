#!/usr/bin/env bash
set -euo pipefail

KEY_VAULT_NAME="$1"
ARM_CLIENT_ID_SECRET_NAME="$2"
ARM_CLIENT_SECRET_SECRET_NAME="$3"
ARM_TENANT_ID_SECRET_NAME="$4"
ARM_SUBSCRIPTION_ID_SECRET_NAME="$5"
DATABRICKS_ACCOUNT_ID_SECRET_NAME="${6:-}"

az login --identity --allow-no-subscriptions >/dev/null

export ARM_CLIENT_ID
ARM_CLIENT_ID=$(az keyvault secret show --vault-name "$KEY_VAULT_NAME" --name "$ARM_CLIENT_ID_SECRET_NAME" --query value -o tsv)

export ARM_CLIENT_SECRET
ARM_CLIENT_SECRET=$(az keyvault secret show --vault-name "$KEY_VAULT_NAME" --name "$ARM_CLIENT_SECRET_SECRET_NAME" --query value -o tsv)

export ARM_TENANT_ID
ARM_TENANT_ID=$(az keyvault secret show --vault-name "$KEY_VAULT_NAME" --name "$ARM_TENANT_ID_SECRET_NAME" --query value -o tsv)

export ARM_SUBSCRIPTION_ID
ARM_SUBSCRIPTION_ID=$(az keyvault secret show --vault-name "$KEY_VAULT_NAME" --name "$ARM_SUBSCRIPTION_ID_SECRET_NAME" --query value -o tsv)

export ARM_USE_AZUREAD=true
export TF_IN_AUTOMATION=1

if [[ -n "$DATABRICKS_ACCOUNT_ID_SECRET_NAME" ]]; then
  export DATABRICKS_ACCOUNT_ID
  DATABRICKS_ACCOUNT_ID=$(az keyvault secret show --vault-name "$KEY_VAULT_NAME" --name "$DATABRICKS_ACCOUNT_ID_SECRET_NAME" --query value -o tsv)
fi
