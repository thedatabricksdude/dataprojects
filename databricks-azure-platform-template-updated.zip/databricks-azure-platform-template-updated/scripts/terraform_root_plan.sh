#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$1"
BACKEND_FILE="$2"
TFVARS_FILE="$3"
PLAN_FILE="$4"

pushd "$ROOT_DIR" >/dev/null
terraform init -backend-config="$BACKEND_FILE"
terraform fmt -check
terraform validate
terraform plan -var-file="$TFVARS_FILE" -out="$PLAN_FILE"
terraform show -no-color "$PLAN_FILE" > "$PLAN_FILE.txt"
popd >/dev/null
