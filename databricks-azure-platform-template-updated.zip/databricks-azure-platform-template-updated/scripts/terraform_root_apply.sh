#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$1"
BACKEND_FILE="$2"
TFVARS_FILE="$3"
PLAN_FILE="$4"

pushd "$ROOT_DIR" >/dev/null
terraform init -backend-config="$BACKEND_FILE"
terraform apply -input=false "$PLAN_FILE"
popd >/dev/null
