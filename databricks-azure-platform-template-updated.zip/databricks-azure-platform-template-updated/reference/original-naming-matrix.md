# Naming matrix

## 1) Workspace persona groups

Pattern:

`<asset>-<region>-<application>[-audit]-<stage>-<role>`

Where:
- `asset` = `dbx`
- `region` = `wus2`
- `application` = one of the application families (`enterpriseapps`, `clinicaldatamanagement`, `dataengineering`, `datascience`, `marketing`)
- `audit` = included only for the audit/compliant workspace variant
- `stage` = `dev`, `qa`, `prod`
- `role` = one of the persona roles below

Persona roles:
- `workspace-admin`
- `data-steward`
- `data-engineer`
- `analytics-engineer`
- `data-scientist`
- `ml-engineer`
- `bi-developer`
- `data-analyst`
- `business-consumer-readonly`
- `audit-reviewer`

Examples:
- `dbx-wus2-enterpriseapps-prod-data-engineer`
- `dbx-wus2-enterpriseapps-audit-prod-audit-reviewer`
- `dbx-wus2-clinicaldatamanagement-dev-data-analyst`
- `dbx-wus2-datascience-audit-qa-data-scientist`

## 2) Platform groups

Platform groups are account-scoped and not tied to one workspace.

Pattern:
`dbx-wus2-platform-<role>`

Recommended platform groups:
- `dbx-wus2-platform-account-admin`
- `dbx-wus2-platform-metastore-admin`
- `dbx-wus2-platform-security-admin`
- `dbx-wus2-platform-audit-reviewer`

## 3) Unity Catalog data grant groups

These groups control baseline Unity Catalog privileges and are separate from workspace persona groups.

### Catalog-scoped groups
Pattern:
`uc-<catalog>-<role>`

Roles:
- `reader`
- `writer`
- `manager`

Examples:
- `uc-telcor-reader`
- `uc-telcor-writer`
- `uc-telcor-manager`

### Schema-scoped groups
Pattern:
`uc-<catalog>-<schema>-<role>`

Roles:
- `reader`
- `writer`
- `manager`

Examples:
- `uc-telcor-claims-reader`
- `uc-telcor-claims-writer`
- `uc-telcor-claims-manager`

## 4) PHI unmasking entitlement groups

These groups are used **only** by masking logic.

Pattern:
- `phi-reader-all`
- `phi-reader-<catalog>`
- `phi-reader-<catalog>-<schema>`

Examples:
- `phi-reader-all`
- `phi-reader-telcor`
- `phi-reader-telcor-claims`

### Important rule
Do **not** nest PHI authorizer groups inside each other.

Bad:
- `phi-reader-telcor-claims` is a member of `phi-reader-telcor`
- `phi-reader-telcor` is a member of `phi-reader-all`

Why this is bad:
- `is_account_group_member()` evaluates **direct and indirect** membership.
- Nesting would cause a schema-scoped user to evaluate as catalog-scoped or global.

## 5) Access model summary

A user's effective access is the combination of three layers:

1. Workspace access via workspace persona group.
2. Data access via `uc-*` group grants.
3. PHI unmasking via `phi-reader-*` groups.

Example:
- `dbx-wus2-dataengineering-prod-data-engineer`
- `uc-telcor-reader`
- `uc-telcor-claims-writer`
- `uc-telcor-claims-manager`
- `phi-reader-telcor-claims`

Result:
- Workspace access to the dataengineering prod workspace.
- Catalog-level read access in `telcor`.
- Schema-level write/manage access in `telcor.claims`.
- Unmasked PHI only in `telcor.claims`.
- PHI remains masked elsewhere.
