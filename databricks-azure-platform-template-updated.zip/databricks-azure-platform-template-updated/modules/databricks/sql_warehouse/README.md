# sql_warehouse module

Creates a Databricks SQL warehouse and applies ACLs.
