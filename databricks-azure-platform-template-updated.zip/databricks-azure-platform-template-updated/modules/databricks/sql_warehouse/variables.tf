variable "workspace_id" {
  type = string
}

variable "name" {
  type = string
}

variable "cluster_size" {
  type = string
}

variable "min_num_clusters" {
  type    = number
  default = 1
}

variable "max_num_clusters" {
  type    = number
  default = 1
}

variable "auto_stop_mins" {
  type    = number
  default = 30
}

variable "enable_photon" {
  type    = bool
  default = true
}

variable "enable_serverless_compute" {
  type    = bool
  default = false
}

variable "permissions" {
  description = "Map of principal display name to permission level."
  type        = map(string)
  default     = {}
}
