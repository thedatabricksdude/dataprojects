resource "databricks_sql_endpoint" "this" {
  provider                  = databricks
  name                      = var.name
  cluster_size              = var.cluster_size
  min_num_clusters          = var.min_num_clusters
  max_num_clusters          = var.max_num_clusters
  auto_stop_mins            = var.auto_stop_mins
  enable_photon             = var.enable_photon
  enable_serverless_compute = var.enable_serverless_compute

  provider_config {
    workspace_id = var.workspace_id
  }
}

resource "databricks_permissions" "this" {
  provider        = databricks
  sql_endpoint_id = databricks_sql_endpoint.this.id

  dynamic "access_control" {
    for_each = var.permissions
    content {
      group_name       = access_control.key
      permission_level = access_control.value
    }
  }

  provider_config {
    workspace_id = var.workspace_id
  }
}
