output "id" {
  value = databricks_sql_endpoint.this.id
}

output "name" {
  value = databricks_sql_endpoint.this.name
}
