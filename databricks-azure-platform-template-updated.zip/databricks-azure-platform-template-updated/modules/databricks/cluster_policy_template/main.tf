locals {
  base_definitions = {
    personal-compute = {
      cluster_type = {
        type   = "fixed"
        value  = "all-purpose"
        hidden = true
      }
      autotermination_minutes = {
        type   = "fixed"
        value  = var.autotermination_minutes
        hidden = true
      }
      dbus_per_hour = {
        type      = "range"
        maxValue  = var.max_dbu
        defaultValue = min(var.max_dbu, 5)
      }
      num_workers = {
        type      = "range"
        maxValue  = 2
        defaultValue = 1
      }
      spark_version = {
        type         = "allowlist"
        values       = ["auto:latest-lts", "auto:prev-lts"]
        defaultValue = "auto:latest-lts"
      }
      data_security_mode = {
        type         = "fixed"
        value        = "USER_ISOLATION"
        hidden       = true
      }
    }

    shared-autoscaling = {
      cluster_type = {
        type   = "fixed"
        value  = "all-purpose"
        hidden = true
      }
      autotermination_minutes = {
        type   = "fixed"
        value  = var.autotermination_minutes
        hidden = true
      }
      dbus_per_hour = {
        type      = "range"
        maxValue  = var.max_dbu
        defaultValue = min(var.max_dbu, 10)
      }
      autoscale.min_workers = {
        type         = "fixed"
        value        = 1
        hidden       = true
      }
      autoscale.max_workers = {
        type         = "range"
        maxValue     = 8
        defaultValue = 4
      }
      spark_version = {
        type         = "allowlist"
        values       = ["auto:latest-lts", "auto:prev-lts"]
        defaultValue = "auto:latest-lts"
      }
      data_security_mode = {
        type         = "fixed"
        value        = "USER_ISOLATION"
        hidden       = true
      }
    }

    job-compute = {
      cluster_type = {
        type   = "fixed"
        value  = "job"
        hidden = true
      }
      dbus_per_hour = {
        type      = "range"
        maxValue  = var.max_dbu
        defaultValue = min(var.max_dbu, 10)
      }
      spark_version = {
        type         = "allowlist"
        values       = ["auto:latest-lts", "auto:prev-lts"]
        defaultValue = "auto:latest-lts"
      }
      data_security_mode = {
        type         = "fixed"
        value        = "USER_ISOLATION"
        hidden       = true
      }
    }
  }

  definition = jsonencode(merge(
    lookup(local.base_definitions, var.template, local.base_definitions["shared-autoscaling"]),
    jsondecode(var.policy_overrides_json),
  ))
}

resource "databricks_cluster_policy" "this" {
  provider              = databricks
  name                  = var.name
  definition            = local.definition
  max_clusters_per_user = var.max_clusters_per_user

  provider_config {
    workspace_id = var.workspace_id
  }
}

resource "databricks_permissions" "this" {
  provider          = databricks
  cluster_policy_id = databricks_cluster_policy.this.id

  dynamic "access_control" {
    for_each = var.permissions
    content {
      group_name       = access_control.key
      permission_level = access_control.value
    }
  }

  provider_config {
    workspace_id = var.workspace_id
  }
}
