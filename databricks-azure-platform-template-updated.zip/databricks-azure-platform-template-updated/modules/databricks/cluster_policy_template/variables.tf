variable "workspace_id" {
  type = string
}

variable "name" {
  type = string
}

variable "template" {
  type = string
}

variable "max_dbu" {
  type    = number
  default = 10
}

variable "max_clusters_per_user" {
  type    = number
  default = 3
}

variable "autotermination_minutes" {
  type    = number
  default = 30
}

variable "policy_overrides_json" {
  type    = string
  default = "{}"
}

variable "permissions" {
  description = "Map of principal display name to permission level. Example: { 'dbx-wus2-platform-security-admin' = 'CAN_MANAGE' }"
  type        = map(string)
  default     = {}
}
