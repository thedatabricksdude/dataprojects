output "id" {
  value = databricks_cluster_policy.this.id
}

output "name" {
  value = databricks_cluster_policy.this.name
}
