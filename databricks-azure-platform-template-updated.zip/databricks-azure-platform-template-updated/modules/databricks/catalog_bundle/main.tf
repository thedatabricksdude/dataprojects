locals {
  catalog_reader_group  = format("uc-%s-reader", lower(var.catalog_name))
  catalog_writer_group  = format("uc-%s-writer", lower(var.catalog_name))
  catalog_manager_group = format("uc-%s-manager", lower(var.catalog_name))
}

resource "databricks_external_location" "this" {
  provider        = databricks
  name            = replace(lower(var.catalog_name), "_", "-")
  url             = var.storage_root_url
  credential_name = var.storage_credential_name
  comment         = "Managed by Terraform for catalog ${var.catalog_name}."

  provider_config {
    workspace_id = var.workspace_context_id
  }
}

resource "databricks_catalog" "this" {
  provider    = databricks
  name        = var.catalog_name
  comment     = var.catalog_comment
  owner       = var.catalog_owner
  metastore_id = var.metastore_id
  storage_root = var.storage_root_url

  provider_config {
    workspace_id = var.workspace_context_id
  }
}

resource "databricks_grants" "catalog" {
  provider = databricks
  catalog  = databricks_catalog.this.name

  grant {
    principal  = local.catalog_reader_group
    privileges = var.catalog_reader_privileges
  }

  grant {
    principal  = local.catalog_writer_group
    privileges = var.catalog_writer_privileges
  }

  grant {
    principal  = local.catalog_manager_group
    privileges = var.catalog_manager_privileges
  }

  dynamic "grant" {
    for_each = var.schemas
    content {
      principal  = format("uc-%s-%s-reader", lower(var.catalog_name), lower(grant.key))
      privileges = ["USE_CATALOG"]
    }
  }

  dynamic "grant" {
    for_each = var.schemas
    content {
      principal  = format("uc-%s-%s-writer", lower(var.catalog_name), lower(grant.key))
      privileges = ["USE_CATALOG"]
    }
  }

  dynamic "grant" {
    for_each = var.schemas
    content {
      principal  = format("uc-%s-%s-manager", lower(var.catalog_name), lower(grant.key))
      privileges = ["USE_CATALOG"]
    }
  }

  provider_config {
    workspace_id = var.workspace_context_id
  }
}

resource "databricks_schema" "this" {
  provider     = databricks
  for_each     = var.schemas
  catalog_name = databricks_catalog.this.name
  name         = each.key
  comment      = try(each.value.comment, null)
  owner        = try(each.value.owner, var.catalog_owner)

  provider_config {
    workspace_id = var.workspace_context_id
  }
}

resource "databricks_grants" "schema" {
  provider = databricks
  for_each = databricks_schema.this
  schema   = each.value.id

  grant {
    principal  = format("uc-%s-%s-reader", lower(var.catalog_name), lower(each.key))
    privileges = var.schema_reader_privileges
  }

  grant {
    principal  = format("uc-%s-%s-writer", lower(var.catalog_name), lower(each.key))
    privileges = var.schema_writer_privileges
  }

  grant {
    principal  = format("uc-%s-%s-manager", lower(var.catalog_name), lower(each.key))
    privileges = var.schema_manager_privileges
  }

  provider_config {
    workspace_id = var.workspace_context_id
  }
}
