# catalog_bundle module

Creates a repeatable Unity Catalog pattern for one catalog:

- external location
- catalog
- schemas
- authoritative grants
