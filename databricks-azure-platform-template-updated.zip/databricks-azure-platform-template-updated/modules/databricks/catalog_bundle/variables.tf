variable "catalog_name" {
  type = string
}

variable "catalog_comment" {
  type    = string
  default = null
}

variable "catalog_owner" {
  type    = string
  default = null
}

variable "metastore_id" {
  type = string
}

variable "workspace_context_id" {
  type = string
}

variable "storage_credential_name" {
  type = string
}

variable "storage_root_url" {
  type = string
}

variable "schemas" {
  type = map(object({
    comment = optional(string, null)
    owner   = optional(string, null)
  }))
  default = {}
}

variable "catalog_reader_privileges" {
  type    = list(string)
  default = ["USE_CATALOG"]
}

variable "catalog_writer_privileges" {
  type    = list(string)
  default = ["USE_CATALOG", "CREATE_SCHEMA"]
}

variable "catalog_manager_privileges" {
  type    = list(string)
  default = ["USE_CATALOG", "CREATE_SCHEMA", "MANAGE", "APPLY_TAG"]
}

variable "schema_reader_privileges" {
  type    = list(string)
  default = ["USE_SCHEMA", "SELECT", "READ_VOLUME"]
}

variable "schema_writer_privileges" {
  type    = list(string)
  default = ["USE_SCHEMA", "SELECT", "MODIFY", "CREATE_TABLE", "CREATE_FUNCTION", "CREATE_VOLUME", "READ_VOLUME", "WRITE_VOLUME"]
}

variable "schema_manager_privileges" {
  type    = list(string)
  default = ["USE_SCHEMA", "SELECT", "MODIFY", "CREATE_TABLE", "CREATE_FUNCTION", "CREATE_VOLUME", "READ_VOLUME", "WRITE_VOLUME", "APPLY_TAG", "MANAGE"]
}
