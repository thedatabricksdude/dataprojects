output "catalog_name" {
  value = databricks_catalog.this.name
}

output "external_location_name" {
  value = databricks_external_location.this.name
}

output "schema_names" {
  value = keys(databricks_schema.this)
}
