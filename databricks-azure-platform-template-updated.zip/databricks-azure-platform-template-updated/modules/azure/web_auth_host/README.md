# web_auth_host module

Creates a dedicated Databricks workspace whose only special job is to host the `browser_authentication` private endpoint used for browser-based SSO over Private Link.
