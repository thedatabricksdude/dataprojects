module "browser_auth_private_endpoint" {
  source = "../private_endpoint"

  name                           = "pe-${var.workspace_name}-browser-auth"
  resource_group_name            = var.resource_group_name
  location                       = var.location
  subnet_id                      = var.private_endpoint_subnet_id
  private_connection_resource_id = azurerm_databricks_workspace.this.id
  subresource_names              = ["browser_authentication"]
  private_dns_zone_ids           = [var.databricks_private_dns_zone_id]
  tags                           = var.tags
}

resource "azurerm_databricks_workspace" "this" {
  name                                 = var.workspace_name
  resource_group_name                  = var.resource_group_name
  location                             = var.location
  sku                                  = var.workspace_sku
  managed_resource_group_name          = var.managed_resource_group_name
  public_network_access_enabled        = var.public_network_access_enabled
  network_security_group_rules_required = var.network_security_group_rules_required
  infrastructure_encryption_enabled    = true
  tags                                 = var.tags

  custom_parameters {
    no_public_ip                                         = true
    public_subnet_name                                   = var.public_subnet_name
    public_subnet_network_security_group_association_id  = var.public_subnet_nsg_association_id
    private_subnet_name                                  = var.private_subnet_name
    private_subnet_network_security_group_association_id = var.private_subnet_nsg_association_id
    virtual_network_id                                   = var.virtual_network_id
  }

  dynamic "enhanced_security_compliance" {
    for_each = var.compliance == null ? [] : [var.compliance]
    content {
      automatic_cluster_update_enabled      = enhanced_security_compliance.value.automatic_cluster_update_enabled
      compliance_security_profile_enabled   = enhanced_security_compliance.value.compliance_security_profile_enabled
      compliance_security_profile_standards = enhanced_security_compliance.value.compliance_security_profile_standards
      enhanced_security_monitoring_enabled  = enhanced_security_compliance.value.enhanced_security_monitoring_enabled
    }
  }
}

resource "azurerm_management_lock" "this" {
  count      = var.enable_delete_lock ? 1 : 0
  name       = "lock-${var.workspace_name}"
  scope      = azurerm_databricks_workspace.this.id
  lock_level = "CanNotDelete"
  notes      = "Protect the private web auth host workspace from accidental deletion."
}

data "azurerm_monitor_diagnostic_categories" "workspace" {
  count       = var.log_analytics_workspace_id == null ? 0 : 1
  resource_id = azurerm_databricks_workspace.this.id
}

resource "azurerm_monitor_diagnostic_setting" "workspace" {
  count                      = var.log_analytics_workspace_id == null ? 0 : 1
  name                       = "diag-${var.workspace_name}"
  target_resource_id         = azurerm_databricks_workspace.this.id
  log_analytics_workspace_id = var.log_analytics_workspace_id

  dynamic "enabled_log" {
    for_each = toset(data.azurerm_monitor_diagnostic_categories.workspace[0].log_category_types)
    content {
      category = enabled_log.value
    }
  }

  dynamic "enabled_metric" {
    for_each = toset(data.azurerm_monitor_diagnostic_categories.workspace[0].metrics)
    content {
      category = enabled_metric.value
    }
  }
}
