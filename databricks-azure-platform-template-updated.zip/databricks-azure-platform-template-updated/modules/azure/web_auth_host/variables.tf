variable "workspace_name" {
  type = string
}

variable "managed_resource_group_name" {
  type = string
}

variable "workspace_sku" {
  type    = string
  default = "premium"
}

variable "resource_group_name" {
  type = string
}

variable "location" {
  type = string
}

variable "virtual_network_id" {
  type = string
}

variable "public_subnet_name" {
  type = string
}

variable "public_subnet_nsg_association_id" {
  type = string
}

variable "private_subnet_name" {
  type = string
}

variable "private_subnet_nsg_association_id" {
  type = string
}

variable "private_endpoint_subnet_id" {
  type = string
}

variable "databricks_private_dns_zone_id" {
  type = string
}

variable "public_network_access_enabled" {
  type    = bool
  default = false
}

variable "network_security_group_rules_required" {
  type    = string
  default = "NoAzureDatabricksRules"
}

variable "compliance" {
  description = "Optional enhanced security and compliance settings."
  type = object({
    automatic_cluster_update_enabled      = bool
    compliance_security_profile_enabled   = bool
    compliance_security_profile_standards = list(string)
    enhanced_security_monitoring_enabled  = bool
  })
  default = null
}

variable "enable_delete_lock" {
  type    = bool
  default = true
}

variable "log_analytics_workspace_id" {
  type    = string
  default = null
}

variable "tags" {
  type    = map(string)
  default = {}
}
