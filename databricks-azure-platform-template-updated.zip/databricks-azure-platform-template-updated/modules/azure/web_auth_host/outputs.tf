output "workspace_id" {
  value = azurerm_databricks_workspace.this.workspace_id
}

output "workspace_name" {
  value = azurerm_databricks_workspace.this.name
}

output "workspace_url" {
  value = azurerm_databricks_workspace.this.workspace_url
}

output "workspace_resource_id" {
  value = azurerm_databricks_workspace.this.id
}

output "browser_auth_private_endpoint_id" {
  value = module.browser_auth_private_endpoint.id
}
