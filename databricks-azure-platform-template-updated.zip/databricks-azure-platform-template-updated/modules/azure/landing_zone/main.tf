data "azurerm_client_config" "current" {}

resource "azurerm_network_security_group" "this" {
  name                = "nsg-${var.vnet_name}"
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags
}

resource "azurerm_virtual_network" "this" {
  name                = var.vnet_name
  address_space       = var.vnet_address_space
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags
}

resource "azurerm_subnet" "public" {
  name                 = var.public_subnet_name
  resource_group_name  = var.resource_group_name
  virtual_network_name = azurerm_virtual_network.this.name
  address_prefixes     = var.public_subnet_prefixes

  delegation {
    name = "databricks-public"
    service_delegation {
      name = "Microsoft.Databricks/workspaces"
      actions = [
        "Microsoft.Network/virtualNetworks/subnets/join/action",
        "Microsoft.Network/virtualNetworks/subnets/prepareNetworkPolicies/action",
        "Microsoft.Network/virtualNetworks/subnets/unprepareNetworkPolicies/action",
      ]
    }
  }
}

resource "azurerm_subnet" "private" {
  name                 = var.private_subnet_name
  resource_group_name  = var.resource_group_name
  virtual_network_name = azurerm_virtual_network.this.name
  address_prefixes     = var.private_subnet_prefixes

  delegation {
    name = "databricks-private"
    service_delegation {
      name = "Microsoft.Databricks/workspaces"
      actions = [
        "Microsoft.Network/virtualNetworks/subnets/join/action",
        "Microsoft.Network/virtualNetworks/subnets/prepareNetworkPolicies/action",
        "Microsoft.Network/virtualNetworks/subnets/unprepareNetworkPolicies/action",
      ]
    }
  }
}

resource "azurerm_subnet" "private_endpoints" {
  name                            = var.private_endpoint_subnet_name
  resource_group_name             = var.resource_group_name
  virtual_network_name            = azurerm_virtual_network.this.name
  address_prefixes                = var.private_endpoint_subnet_prefixes
  private_endpoint_network_policies = "Disabled"
}

resource "azurerm_subnet_network_security_group_association" "public" {
  subnet_id                 = azurerm_subnet.public.id
  network_security_group_id = azurerm_network_security_group.this.id
}

resource "azurerm_subnet_network_security_group_association" "private" {
  subnet_id                 = azurerm_subnet.private.id
  network_security_group_id = azurerm_network_security_group.this.id
}

resource "azurerm_route_table" "this" {
  count               = var.create_route_table ? 1 : 0
  name                = coalesce(var.route_table_name, "rt-${var.vnet_name}")
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags
}

resource "azurerm_route" "default" {
  count                  = var.create_route_table && var.default_route_next_hop_type != null ? 1 : 0
  name                   = "default-egress"
  resource_group_name    = var.resource_group_name
  route_table_name       = azurerm_route_table.this[0].name
  address_prefix         = "0.0.0.0/0"
  next_hop_type          = var.default_route_next_hop_type
  next_hop_in_ip_address = var.default_route_next_hop_ip_address
}

resource "azurerm_subnet_route_table_association" "public" {
  count          = var.create_route_table ? 1 : 0
  subnet_id      = azurerm_subnet.public.id
  route_table_id = azurerm_route_table.this[0].id
}

resource "azurerm_subnet_route_table_association" "private" {
  count          = var.create_route_table ? 1 : 0
  subnet_id      = azurerm_subnet.private.id
  route_table_id = azurerm_route_table.this[0].id
}

resource "azurerm_private_dns_zone_virtual_network_link" "databricks" {
  name                  = "link-${var.vnet_name}-adb"
  resource_group_name   = split("/", var.databricks_private_dns_zone_id)[4]
  private_dns_zone_name = split("/", var.databricks_private_dns_zone_id)[8]
  virtual_network_id    = azurerm_virtual_network.this.id
}

resource "azurerm_private_dns_zone_virtual_network_link" "blob" {
  name                  = "link-${var.vnet_name}-blob"
  resource_group_name   = split("/", var.blob_private_dns_zone_id)[4]
  private_dns_zone_name = split("/", var.blob_private_dns_zone_id)[8]
  virtual_network_id    = azurerm_virtual_network.this.id
}

resource "azurerm_private_dns_zone_virtual_network_link" "dfs" {
  name                  = "link-${var.vnet_name}-dfs"
  resource_group_name   = split("/", var.dfs_private_dns_zone_id)[4]
  private_dns_zone_name = split("/", var.dfs_private_dns_zone_id)[8]
  virtual_network_id    = azurerm_virtual_network.this.id
}

resource "azurerm_private_dns_zone_virtual_network_link" "keyvault" {
  name                  = "link-${var.vnet_name}-kv"
  resource_group_name   = split("/", var.key_vault_private_dns_zone_id)[4]
  private_dns_zone_name = split("/", var.key_vault_private_dns_zone_id)[8]
  virtual_network_id    = azurerm_virtual_network.this.id
}

resource "azurerm_virtual_network_peering" "spoke_to_hub" {
  count                        = var.enable_vnet_peering ? 1 : 0
  name                         = "peer-${var.vnet_name}-to-${var.hub_vnet_name}"
  resource_group_name          = var.resource_group_name
  virtual_network_name         = azurerm_virtual_network.this.name
  remote_virtual_network_id    = var.hub_vnet_id
  allow_virtual_network_access = true
  allow_forwarded_traffic      = true
}

resource "azurerm_virtual_network_peering" "hub_to_spoke" {
  count                        = var.enable_vnet_peering ? 1 : 0
  name                         = "peer-${var.hub_vnet_name}-to-${var.vnet_name}"
  resource_group_name          = var.hub_vnet_resource_group_name
  virtual_network_name         = var.hub_vnet_name
  remote_virtual_network_id    = azurerm_virtual_network.this.id
  allow_virtual_network_access = true
  allow_forwarded_traffic      = true
}

resource "azurerm_storage_account" "this" {
  name                            = var.adls_account_name
  resource_group_name             = var.resource_group_name
  location                        = var.location
  account_tier                    = "Standard"
  account_replication_type        = var.adls_replication_type
  account_kind                    = "StorageV2"
  is_hns_enabled                  = true
  min_tls_version                 = "TLS1_2"
  public_network_access_enabled   = false
  allow_nested_items_to_be_public = false
  infrastructure_encryption_enabled = true
  tags                            = var.tags

  network_rules {
    default_action = "Deny"
    bypass         = ["AzureServices"]
  }

  blob_properties {
    versioning_enabled = true

    delete_retention_policy {
      days = 7
    }

    container_delete_retention_policy {
      days = 7
    }
  }
}

resource "azurerm_storage_data_lake_gen2_filesystem" "this" {
  for_each           = var.storage_containers
  name               = each.value
  storage_account_id = azurerm_storage_account.this.id
}

resource "azurerm_key_vault" "this" {
  name                       = var.key_vault_name
  location                   = var.location
  resource_group_name        = var.resource_group_name
  tenant_id                  = data.azurerm_client_config.current.tenant_id
  sku_name                   = var.key_vault_sku_name
  purge_protection_enabled   = true
  soft_delete_retention_days = 90
  public_network_access_enabled = false
  enable_rbac_authorization  = true
  tags                       = var.tags

  network_acls {
    default_action = "Deny"
    bypass         = "None"
  }
}

resource "azurerm_databricks_access_connector" "this" {
  name                = var.access_connector_name
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags

  identity {
    type = "SystemAssigned"
  }
}

resource "azurerm_role_assignment" "access_connector_blob_data_contributor" {
  scope                = azurerm_storage_account.this.id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = azurerm_databricks_access_connector.this.identity[0].principal_id
}

resource "azurerm_databricks_workspace" "this" {
  name                                  = var.workspace_name
  resource_group_name                   = var.resource_group_name
  location                              = var.location
  sku                                   = var.workspace_sku
  managed_resource_group_name           = var.managed_resource_group_name
  public_network_access_enabled         = var.workspace_public_network_access_enabled
  network_security_group_rules_required = var.network_security_group_rules_required
  access_connector_id                   = azurerm_databricks_access_connector.this.id
  infrastructure_encryption_enabled     = true
  tags                                  = var.tags

  custom_parameters {
    no_public_ip                                         = true
    public_subnet_name                                   = azurerm_subnet.public.name
    public_subnet_network_security_group_association_id  = azurerm_subnet_network_security_group_association.public.id
    private_subnet_name                                  = azurerm_subnet.private.name
    private_subnet_network_security_group_association_id = azurerm_subnet_network_security_group_association.private.id
    virtual_network_id                                   = azurerm_virtual_network.this.id
  }

  dynamic "enhanced_security_compliance" {
    for_each = var.compliance == null ? [] : [var.compliance]
    content {
      automatic_cluster_update_enabled      = enhanced_security_compliance.value.automatic_cluster_update_enabled
      compliance_security_profile_enabled   = enhanced_security_compliance.value.compliance_security_profile_enabled
      compliance_security_profile_standards = enhanced_security_compliance.value.compliance_security_profile_standards
      enhanced_security_monitoring_enabled  = enhanced_security_compliance.value.enhanced_security_monitoring_enabled
    }
  }
}

module "storage_blob_private_endpoint" {
  source = "../private_endpoint"

  name                           = "pe-${var.workspace_name}-blob"
  resource_group_name            = var.resource_group_name
  location                       = var.location
  subnet_id                      = azurerm_subnet.private_endpoints.id
  private_connection_resource_id = azurerm_storage_account.this.id
  subresource_names              = ["blob"]
  private_dns_zone_ids           = [var.blob_private_dns_zone_id]
  tags                           = var.tags
}

module "storage_dfs_private_endpoint" {
  source = "../private_endpoint"

  name                           = "pe-${var.workspace_name}-dfs"
  resource_group_name            = var.resource_group_name
  location                       = var.location
  subnet_id                      = azurerm_subnet.private_endpoints.id
  private_connection_resource_id = azurerm_storage_account.this.id
  subresource_names              = ["dfs"]
  private_dns_zone_ids           = [var.dfs_private_dns_zone_id]
  tags                           = var.tags
}

module "key_vault_private_endpoint" {
  source = "../private_endpoint"

  name                           = "pe-${var.workspace_name}-kv"
  resource_group_name            = var.resource_group_name
  location                       = var.location
  subnet_id                      = azurerm_subnet.private_endpoints.id
  private_connection_resource_id = azurerm_key_vault.this.id
  subresource_names              = ["vault"]
  private_dns_zone_ids           = [var.key_vault_private_dns_zone_id]
  tags                           = var.tags
}

module "databricks_frontend_private_endpoint" {
  source = "../private_endpoint"

  name                           = "pe-${var.workspace_name}-frontend"
  resource_group_name            = var.resource_group_name
  location                       = var.location
  subnet_id                      = var.hub_private_endpoint_subnet_id
  private_connection_resource_id = azurerm_databricks_workspace.this.id
  subresource_names              = ["databricks_ui_api"]
  private_dns_zone_ids           = [var.databricks_private_dns_zone_id]
  tags                           = var.tags
}

module "databricks_backend_private_endpoint" {
  source = "../private_endpoint"

  name                           = "pe-${var.workspace_name}-backend"
  resource_group_name            = var.resource_group_name
  location                       = var.location
  subnet_id                      = azurerm_subnet.private_endpoints.id
  private_connection_resource_id = azurerm_databricks_workspace.this.id
  subresource_names              = ["databricks_ui_api"]
  private_dns_zone_ids           = [var.databricks_private_dns_zone_id]
  tags                           = var.tags
}

resource "azurerm_management_lock" "this" {
  count      = var.enable_delete_lock ? 1 : 0
  name       = "lock-${var.workspace_name}"
  scope      = azurerm_databricks_workspace.this.id
  lock_level = "CanNotDelete"
  notes      = "Protect this Databricks workspace from accidental deletion."
}

data "azurerm_monitor_diagnostic_categories" "workspace" {
  count       = var.log_analytics_workspace_id == null ? 0 : 1
  resource_id = azurerm_databricks_workspace.this.id
}

resource "azurerm_monitor_diagnostic_setting" "workspace" {
  count                      = var.log_analytics_workspace_id == null ? 0 : 1
  name                       = "diag-${var.workspace_name}"
  target_resource_id         = azurerm_databricks_workspace.this.id
  log_analytics_workspace_id = var.log_analytics_workspace_id

  dynamic "enabled_log" {
    for_each = toset(data.azurerm_monitor_diagnostic_categories.workspace[0].log_category_types)
    content {
      category = enabled_log.value
    }
  }

  dynamic "enabled_metric" {
    for_each = toset(data.azurerm_monitor_diagnostic_categories.workspace[0].metrics)
    content {
      category = enabled_metric.value
    }
  }
}
