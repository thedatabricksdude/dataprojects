variable "landing_zone_key" {
  type = string
}

variable "resource_group_name" {
  type = string
}

variable "location" {
  type = string
}

variable "workspace_name" {
  type = string
}

variable "managed_resource_group_name" {
  type = string
}

variable "workspace_sku" {
  type    = string
  default = "premium"
}

variable "application" {
  type = string
}

variable "stage" {
  type = string
}

variable "audit_variant" {
  type    = bool
  default = false
}

variable "vnet_name" {
  type = string
}

variable "vnet_address_space" {
  type = list(string)
}

variable "public_subnet_name" {
  type    = string
  default = "snet-dbx-public"
}

variable "public_subnet_prefixes" {
  type = list(string)
}

variable "private_subnet_name" {
  type    = string
  default = "snet-dbx-private"
}

variable "private_subnet_prefixes" {
  type = list(string)
}

variable "private_endpoint_subnet_name" {
  type    = string
  default = "snet-private-endpoints"
}

variable "private_endpoint_subnet_prefixes" {
  type = list(string)
}

variable "adls_account_name" {
  type = string
}

variable "adls_replication_type" {
  type    = string
  default = "ZRS"
}

variable "storage_containers" {
  type    = set(string)
  default = ["landing", "bronze", "silver", "gold", "checkpoints"]
}

variable "key_vault_name" {
  type = string
}

variable "key_vault_sku_name" {
  type    = string
  default = "premium"
}

variable "access_connector_name" {
  type = string
}

variable "workspace_public_network_access_enabled" {
  type    = bool
  default = false
}

variable "network_security_group_rules_required" {
  type    = string
  default = "NoAzureDatabricksRules"
}

variable "compliance" {
  description = "Optional enhanced security and compliance settings."
  type = object({
    automatic_cluster_update_enabled      = bool
    compliance_security_profile_enabled   = bool
    compliance_security_profile_standards = list(string)
    enhanced_security_monitoring_enabled  = bool
  })
  default = null
}

variable "create_route_table" {
  type    = bool
  default = false
}

variable "route_table_name" {
  type    = string
  default = null
}

variable "default_route_next_hop_type" {
  type    = string
  default = null
}

variable "default_route_next_hop_ip_address" {
  type    = string
  default = null
}

variable "hub_vnet_id" {
  type = string
}

variable "hub_vnet_name" {
  type = string
}

variable "hub_vnet_resource_group_name" {
  type = string
}

variable "hub_private_endpoint_subnet_id" {
  type = string
}

variable "enable_vnet_peering" {
  type    = bool
  default = true
}

variable "databricks_private_dns_zone_id" {
  type = string
}

variable "blob_private_dns_zone_id" {
  type = string
}

variable "dfs_private_dns_zone_id" {
  type = string
}

variable "key_vault_private_dns_zone_id" {
  type = string
}

variable "log_analytics_workspace_id" {
  type    = string
  default = null
}

variable "enable_delete_lock" {
  type    = bool
  default = false
}

variable "tags" {
  type    = map(string)
  default = {}
}
