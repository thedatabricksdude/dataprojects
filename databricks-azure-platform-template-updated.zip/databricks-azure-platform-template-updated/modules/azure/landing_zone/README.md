# landing_zone module

Creates one complete Azure Databricks spoke landing zone with private connectivity, storage, Key Vault, access connector, and workspace.
