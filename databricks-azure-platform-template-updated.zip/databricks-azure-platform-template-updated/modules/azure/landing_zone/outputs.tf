output "workspace_id" {
  value = azurerm_databricks_workspace.this.workspace_id
}

output "workspace_name" {
  value = azurerm_databricks_workspace.this.name
}

output "workspace_url" {
  value = azurerm_databricks_workspace.this.workspace_url
}

output "workspace_resource_id" {
  value = azurerm_databricks_workspace.this.id
}

output "application" {
  value = var.application
}

output "stage" {
  value = var.stage
}

output "audit_variant" {
  value = var.audit_variant
}

output "resource_group_name" {
  value = var.resource_group_name
}

output "access_connector_id" {
  value = azurerm_databricks_access_connector.this.id
}

output "storage_account_id" {
  value = azurerm_storage_account.this.id
}

output "storage_account_name" {
  value = azurerm_storage_account.this.name
}

output "storage_filesystems" {
  value = {
    for k, v in azurerm_storage_data_lake_gen2_filesystem.this :
    k => {
      name      = v.name
      abfss_uri = "abfss://${v.name}@${azurerm_storage_account.this.name}.dfs.core.windows.net/"
    }
  }
}

output "key_vault_id" {
  value = azurerm_key_vault.this.id
}

output "key_vault_name" {
  value = azurerm_key_vault.this.name
}

output "vnet_id" {
  value = azurerm_virtual_network.this.id
}

output "subnet_ids" {
  value = {
    public            = azurerm_subnet.public.id
    private           = azurerm_subnet.private.id
    private_endpoints = azurerm_subnet.private_endpoints.id
  }
}

output "private_endpoint_ids" {
  value = {
    storage_blob        = module.storage_blob_private_endpoint.id
    storage_dfs         = module.storage_dfs_private_endpoint.id
    key_vault           = module.key_vault_private_endpoint.id
    databricks_frontend = module.databricks_frontend_private_endpoint.id
    databricks_backend  = module.databricks_backend_private_endpoint.id
  }
}
