variable "name" {
  type        = string
  description = "Private endpoint name."
}

variable "resource_group_name" {
  type        = string
  description = "Resource group for the private endpoint."
}

variable "location" {
  type        = string
  description = "Azure region."
}

variable "subnet_id" {
  type        = string
  description = "Subnet where the private endpoint NIC should be created."
}

variable "private_connection_resource_id" {
  type        = string
  description = "Target resource ID."
}

variable "subresource_names" {
  type        = list(string)
  description = "Target subresource names, such as blob, dfs, vault, databricks_ui_api, or browser_authentication."
}

variable "private_service_connection_name" {
  type        = string
  description = "Name for the private service connection."
  default     = null
}

variable "private_dns_zone_group_name" {
  type        = string
  default     = "default"
}

variable "private_dns_zone_ids" {
  type        = list(string)
  default     = []
}

variable "tags" {
  type    = map(string)
  default = {}
}
