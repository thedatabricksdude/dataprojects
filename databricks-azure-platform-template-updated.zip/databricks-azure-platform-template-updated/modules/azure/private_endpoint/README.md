# private_endpoint module

Small wrapper to standardize Azure private endpoint creation and keep repeated HCL out of the main landing-zone modules.
