locals {
  common_tags = merge(
    {
      environment  = var.environment
      platform     = var.platform_name
      region       = var.location
      region_code  = var.region_code
      managed_by   = "terraform"
      terraform_root = "foundation"
    },
    var.tags,
  )

  private_dns_zone_ids = var.create_private_dns_zones ? {
    databricks = azurerm_private_dns_zone.databricks[0].id
    blob       = azurerm_private_dns_zone.blob[0].id
    dfs        = azurerm_private_dns_zone.dfs[0].id
    key_vault  = azurerm_private_dns_zone.key_vault[0].id
  } : var.existing_private_dns_zone_ids
}
