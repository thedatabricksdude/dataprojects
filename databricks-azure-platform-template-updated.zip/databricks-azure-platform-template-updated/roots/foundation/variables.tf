variable "subscription_id" {
  description = "Optional Azure subscription ID. If null, Azure CLI / managed identity context is used."
  type        = string
  default     = null
}

variable "platform_name" {
  description = "Human-readable platform name used in tags and docs."
  type        = string
}

variable "environment" {
  description = "Environment name such as dev, qa, or prod."
  type        = string
}

variable "location" {
  description = "Azure region for this deployment."
  type        = string
}

variable "region_code" {
  description = "Short region code such as wus2."
  type        = string
}

variable "resource_groups" {
  description = "Pre-created resource groups provided by IT."
  type = object({
    hub_network     = string
    shared_services = string
    web_auth        = string
    workspaces      = map(string)
  })
}

variable "hub_network" {
  description = "Transit / hub VNet settings."
  type = object({
    vnet_name                         = string
    address_space                     = list(string)
    private_endpoint_subnet_name      = optional(string, "snet-dbx-private-endpoints")
    private_endpoint_subnet_prefixes  = list(string)
    web_auth_public_subnet_name       = optional(string, "snet-dbx-webauth-public")
    web_auth_public_subnet_prefixes   = list(string)
    web_auth_private_subnet_name      = optional(string, "snet-dbx-webauth-private")
    web_auth_private_subnet_prefixes  = list(string)
    create_route_table                = optional(bool, false)
    route_table_name                  = optional(string, null)
    default_route_next_hop_type       = optional(string, null)
    default_route_next_hop_ip_address = optional(string, null)
  })
}

variable "web_auth_workspace" {
  description = "Dedicated private web-auth host workspace."
  type = object({
    create                            = optional(bool, true)
    workspace_name                    = string
    managed_resource_group_name       = string
    workspace_sku                     = optional(string, "premium")
    public_network_access_enabled     = optional(bool, false)
    network_security_group_rules_required = optional(string, "NoAzureDatabricksRules")
    enable_delete_lock                = optional(bool, true)
    compliance = optional(object({
      automatic_cluster_update_enabled      = bool
      compliance_security_profile_enabled   = bool
      compliance_security_profile_standards = list(string)
      enhanced_security_monitoring_enabled  = bool
    }), null)
  })
}

variable "landing_zones" {
  description = "Map of workload landing zones / Databricks workspaces. Each key becomes part of the remote-state contract."
  type = map(object({
    workspace_name                        = string
    managed_resource_group_name           = string
    workspace_sku                         = optional(string, "premium")
    application                           = string
    stage                                 = string
    audit_variant                         = optional(bool, false)
    vnet_name                             = string
    vnet_address_space                    = list(string)
    public_subnet_name                    = optional(string, "snet-dbx-public")
    public_subnet_prefixes                = list(string)
    private_subnet_name                   = optional(string, "snet-dbx-private")
    private_subnet_prefixes               = list(string)
    private_endpoint_subnet_name          = optional(string, "snet-private-endpoints")
    private_endpoint_subnet_prefixes      = list(string)
    adls_account_name                     = string
    adls_replication_type                 = optional(string, "ZRS")
    storage_containers                    = optional(set(string), ["landing", "bronze", "silver", "gold", "checkpoints"])
    key_vault_name                        = string
    key_vault_sku_name                    = optional(string, "premium")
    access_connector_name                 = string
    workspace_public_network_access_enabled = optional(bool, false)
    network_security_group_rules_required = optional(string, "NoAzureDatabricksRules")
    create_route_table                    = optional(bool, false)
    route_table_name                      = optional(string, null)
    default_route_next_hop_type           = optional(string, null)
    default_route_next_hop_ip_address     = optional(string, null)
    enable_vnet_peering                   = optional(bool, true)
    enable_delete_lock                    = optional(bool, false)
    compliance = optional(object({
      automatic_cluster_update_enabled      = bool
      compliance_security_profile_enabled   = bool
      compliance_security_profile_standards = list(string)
      enhanced_security_monitoring_enabled  = bool
    }), null)
  }))
}

variable "create_private_dns_zones" {
  description = "Whether the foundation root should create the required private DNS zones."
  type        = bool
  default     = true
}

variable "private_dns_zone_names" {
  description = "Names of shared private DNS zones."
  type = object({
    databricks = string
    blob       = string
    dfs        = string
    key_vault  = string
  })
  default = {
    databricks = "privatelink.azuredatabricks.net"
    blob       = "privatelink.blob.core.windows.net"
    dfs        = "privatelink.dfs.core.windows.net"
    key_vault  = "privatelink.vaultcore.azure.net"
  }
}



variable "existing_private_dns_zone_ids" {
  description = "Optional existing private DNS zone IDs to use when create_private_dns_zones is false. Leave null to have this root create them."
  type = object({
    databricks = string
    blob       = string
    dfs        = string
    key_vault  = string
  })
  default = null
}

variable "log_analytics_workspace_id" {
  description = "Optional Log Analytics workspace for resource diagnostics."
  type        = string
  default     = null
}

variable "tags" {
  description = "Common tags."
  type        = map(string)
  default     = {}
}
