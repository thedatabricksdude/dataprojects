resource "azurerm_network_security_group" "hub" {
  name                = "nsg-${var.hub_network.vnet_name}"
  location            = var.location
  resource_group_name = data.azurerm_resource_group.hub_network.name
  tags                = local.common_tags
}

resource "azurerm_virtual_network" "hub" {
  name                = var.hub_network.vnet_name
  address_space       = var.hub_network.address_space
  location            = var.location
  resource_group_name = data.azurerm_resource_group.hub_network.name
  tags                = local.common_tags
}

resource "azurerm_subnet" "hub_private_endpoints" {
  name                              = var.hub_network.private_endpoint_subnet_name
  resource_group_name               = data.azurerm_resource_group.hub_network.name
  virtual_network_name              = azurerm_virtual_network.hub.name
  address_prefixes                  = var.hub_network.private_endpoint_subnet_prefixes
  private_endpoint_network_policies = "Disabled"
}

resource "azurerm_subnet" "web_auth_public" {
  name                 = var.hub_network.web_auth_public_subnet_name
  resource_group_name  = data.azurerm_resource_group.hub_network.name
  virtual_network_name = azurerm_virtual_network.hub.name
  address_prefixes     = var.hub_network.web_auth_public_subnet_prefixes

  delegation {
    name = "databricks-public"
    service_delegation {
      name = "Microsoft.Databricks/workspaces"
      actions = [
        "Microsoft.Network/virtualNetworks/subnets/join/action",
        "Microsoft.Network/virtualNetworks/subnets/prepareNetworkPolicies/action",
        "Microsoft.Network/virtualNetworks/subnets/unprepareNetworkPolicies/action",
      ]
    }
  }
}

resource "azurerm_subnet" "web_auth_private" {
  name                 = var.hub_network.web_auth_private_subnet_name
  resource_group_name  = data.azurerm_resource_group.hub_network.name
  virtual_network_name = azurerm_virtual_network.hub.name
  address_prefixes     = var.hub_network.web_auth_private_subnet_prefixes

  delegation {
    name = "databricks-private"
    service_delegation {
      name = "Microsoft.Databricks/workspaces"
      actions = [
        "Microsoft.Network/virtualNetworks/subnets/join/action",
        "Microsoft.Network/virtualNetworks/subnets/prepareNetworkPolicies/action",
        "Microsoft.Network/virtualNetworks/subnets/unprepareNetworkPolicies/action",
      ]
    }
  }
}

resource "azurerm_subnet_network_security_group_association" "web_auth_public" {
  subnet_id                 = azurerm_subnet.web_auth_public.id
  network_security_group_id = azurerm_network_security_group.hub.id
}

resource "azurerm_subnet_network_security_group_association" "web_auth_private" {
  subnet_id                 = azurerm_subnet.web_auth_private.id
  network_security_group_id = azurerm_network_security_group.hub.id
}

resource "azurerm_route_table" "hub" {
  count               = var.hub_network.create_route_table ? 1 : 0
  name                = coalesce(var.hub_network.route_table_name, "rt-${var.hub_network.vnet_name}")
  location            = var.location
  resource_group_name = data.azurerm_resource_group.hub_network.name
  tags                = local.common_tags
}

resource "azurerm_route" "hub_default" {
  count                  = var.hub_network.create_route_table && var.hub_network.default_route_next_hop_type != null ? 1 : 0
  name                   = "default-egress"
  resource_group_name    = data.azurerm_resource_group.hub_network.name
  route_table_name       = azurerm_route_table.hub[0].name
  address_prefix         = "0.0.0.0/0"
  next_hop_type          = var.hub_network.default_route_next_hop_type
  next_hop_in_ip_address = var.hub_network.default_route_next_hop_ip_address
}

resource "azurerm_subnet_route_table_association" "web_auth_public" {
  count          = var.hub_network.create_route_table ? 1 : 0
  subnet_id      = azurerm_subnet.web_auth_public.id
  route_table_id = azurerm_route_table.hub[0].id
}

resource "azurerm_subnet_route_table_association" "web_auth_private" {
  count          = var.hub_network.create_route_table ? 1 : 0
  subnet_id      = azurerm_subnet.web_auth_private.id
  route_table_id = azurerm_route_table.hub[0].id
}

resource "azurerm_private_dns_zone" "databricks" {
  count               = var.create_private_dns_zones ? 1 : 0
  name                = var.private_dns_zone_names.databricks
  resource_group_name = data.azurerm_resource_group.shared_services.name
  tags                = local.common_tags
}

resource "azurerm_private_dns_zone" "blob" {
  count               = var.create_private_dns_zones ? 1 : 0
  name                = var.private_dns_zone_names.blob
  resource_group_name = data.azurerm_resource_group.shared_services.name
  tags                = local.common_tags
}

resource "azurerm_private_dns_zone" "dfs" {
  count               = var.create_private_dns_zones ? 1 : 0
  name                = var.private_dns_zone_names.dfs
  resource_group_name = data.azurerm_resource_group.shared_services.name
  tags                = local.common_tags
}

resource "azurerm_private_dns_zone" "key_vault" {
  count               = var.create_private_dns_zones ? 1 : 0
  name                = var.private_dns_zone_names.key_vault
  resource_group_name = data.azurerm_resource_group.shared_services.name
  tags                = local.common_tags
}

resource "azurerm_private_dns_zone_virtual_network_link" "hub_databricks" {
  count                 = var.create_private_dns_zones || var.existing_private_dns_zone_ids != null ? 1 : 0
  name                  = "link-${var.hub_network.vnet_name}-adb"
  resource_group_name   = split("/", local.private_dns_zone_ids.databricks)[4]
  private_dns_zone_name = split("/", local.private_dns_zone_ids.databricks)[8]
  virtual_network_id    = azurerm_virtual_network.hub.id
}

resource "azurerm_private_dns_zone_virtual_network_link" "hub_blob" {
  count                 = var.create_private_dns_zones || var.existing_private_dns_zone_ids != null ? 1 : 0
  name                  = "link-${var.hub_network.vnet_name}-blob"
  resource_group_name   = split("/", local.private_dns_zone_ids.blob)[4]
  private_dns_zone_name = split("/", local.private_dns_zone_ids.blob)[8]
  virtual_network_id    = azurerm_virtual_network.hub.id
}

resource "azurerm_private_dns_zone_virtual_network_link" "hub_dfs" {
  count                 = var.create_private_dns_zones || var.existing_private_dns_zone_ids != null ? 1 : 0
  name                  = "link-${var.hub_network.vnet_name}-dfs"
  resource_group_name   = split("/", local.private_dns_zone_ids.dfs)[4]
  private_dns_zone_name = split("/", local.private_dns_zone_ids.dfs)[8]
  virtual_network_id    = azurerm_virtual_network.hub.id
}

resource "azurerm_private_dns_zone_virtual_network_link" "hub_key_vault" {
  count                 = var.create_private_dns_zones || var.existing_private_dns_zone_ids != null ? 1 : 0
  name                  = "link-${var.hub_network.vnet_name}-kv"
  resource_group_name   = split("/", local.private_dns_zone_ids.key_vault)[4]
  private_dns_zone_name = split("/", local.private_dns_zone_ids.key_vault)[8]
  virtual_network_id    = azurerm_virtual_network.hub.id
}

module "web_auth_host" {
  count = try(var.web_auth_workspace.create, true) ? 1 : 0

  source = "../../modules/azure/web_auth_host"

  workspace_name                        = var.web_auth_workspace.workspace_name
  managed_resource_group_name           = var.web_auth_workspace.managed_resource_group_name
  workspace_sku                         = try(var.web_auth_workspace.workspace_sku, "premium")
  resource_group_name                   = data.azurerm_resource_group.web_auth.name
  location                              = var.location
  virtual_network_id                    = azurerm_virtual_network.hub.id
  public_subnet_name                    = azurerm_subnet.web_auth_public.name
  public_subnet_nsg_association_id      = azurerm_subnet_network_security_group_association.web_auth_public.id
  private_subnet_name                   = azurerm_subnet.web_auth_private.name
  private_subnet_nsg_association_id     = azurerm_subnet_network_security_group_association.web_auth_private.id
  private_endpoint_subnet_id            = azurerm_subnet.hub_private_endpoints.id
  databricks_private_dns_zone_id        = local.private_dns_zone_ids.databricks
  public_network_access_enabled         = try(var.web_auth_workspace.public_network_access_enabled, false)
  network_security_group_rules_required = try(var.web_auth_workspace.network_security_group_rules_required, "NoAzureDatabricksRules")
  compliance                            = try(var.web_auth_workspace.compliance, null)
  enable_delete_lock                    = try(var.web_auth_workspace.enable_delete_lock, true)
  log_analytics_workspace_id            = var.log_analytics_workspace_id
  tags                                  = merge(local.common_tags, { workload = "web-auth-host" })
}

module "landing_zones" {
  for_each = var.landing_zones

  source = "../../modules/azure/landing_zone"

  landing_zone_key                      = each.key
  resource_group_name                   = data.azurerm_resource_group.workspaces[each.key].name
  location                              = var.location
  workspace_name                        = each.value.workspace_name
  managed_resource_group_name           = each.value.managed_resource_group_name
  workspace_sku                         = try(each.value.workspace_sku, "premium")
  application                           = each.value.application
  stage                                 = each.value.stage
  audit_variant                         = try(each.value.audit_variant, false)
  vnet_name                             = each.value.vnet_name
  vnet_address_space                    = each.value.vnet_address_space
  public_subnet_name                    = try(each.value.public_subnet_name, "snet-dbx-public")
  public_subnet_prefixes                = each.value.public_subnet_prefixes
  private_subnet_name                   = try(each.value.private_subnet_name, "snet-dbx-private")
  private_subnet_prefixes               = each.value.private_subnet_prefixes
  private_endpoint_subnet_name          = try(each.value.private_endpoint_subnet_name, "snet-private-endpoints")
  private_endpoint_subnet_prefixes      = each.value.private_endpoint_subnet_prefixes
  adls_account_name                     = each.value.adls_account_name
  adls_replication_type                 = try(each.value.adls_replication_type, "ZRS")
  storage_containers                    = try(each.value.storage_containers, ["landing", "bronze", "silver", "gold", "checkpoints"])
  key_vault_name                        = each.value.key_vault_name
  key_vault_sku_name                    = try(each.value.key_vault_sku_name, "premium")
  access_connector_name                 = each.value.access_connector_name
  workspace_public_network_access_enabled = try(each.value.workspace_public_network_access_enabled, false)
  network_security_group_rules_required = try(each.value.network_security_group_rules_required, "NoAzureDatabricksRules")
  compliance                            = try(each.value.compliance, null)
  create_route_table                    = try(each.value.create_route_table, false)
  route_table_name                      = try(each.value.route_table_name, null)
  default_route_next_hop_type           = try(each.value.default_route_next_hop_type, null)
  default_route_next_hop_ip_address     = try(each.value.default_route_next_hop_ip_address, null)
  hub_vnet_id                           = azurerm_virtual_network.hub.id
  hub_vnet_name                         = azurerm_virtual_network.hub.name
  hub_vnet_resource_group_name          = data.azurerm_resource_group.hub_network.name
  hub_private_endpoint_subnet_id        = azurerm_subnet.hub_private_endpoints.id
  enable_vnet_peering                   = try(each.value.enable_vnet_peering, true)
  databricks_private_dns_zone_id        = local.private_dns_zone_ids.databricks
  blob_private_dns_zone_id              = azurerm_private_dns_zone.blob[0].id
  dfs_private_dns_zone_id               = azurerm_private_dns_zone.dfs[0].id
  key_vault_private_dns_zone_id         = azurerm_private_dns_zone.key_vault[0].id
  log_analytics_workspace_id            = var.log_analytics_workspace_id
  enable_delete_lock                    = try(each.value.enable_delete_lock, false)
  tags                                  = merge(local.common_tags, {
    application   = each.value.application
    stage         = each.value.stage
    audit_variant = tostring(try(each.value.audit_variant, false))
    landing_zone  = each.key
  })
}
