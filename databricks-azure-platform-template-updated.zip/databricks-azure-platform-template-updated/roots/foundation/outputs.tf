output "platform" {
  value = {
    platform_name = var.platform_name
    environment   = var.environment
    location      = var.location
    region_code   = var.region_code
  }
}

output "hub_network" {
  value = {
    vnet_id                    = azurerm_virtual_network.hub.id
    vnet_name                  = azurerm_virtual_network.hub.name
    private_endpoint_subnet_id = azurerm_subnet.hub_private_endpoints.id
  }
}

output "private_dns_zone_ids" {
  value = local.private_dns_zone_ids
}

output "web_auth_workspace" {
  value = try({
    workspace_name               = module.web_auth_host[0].workspace_name
    workspace_id                 = module.web_auth_host[0].workspace_id
    workspace_url                = module.web_auth_host[0].workspace_url
    workspace_resource_id        = module.web_auth_host[0].workspace_resource_id
    browser_auth_private_endpoint_id = module.web_auth_host[0].browser_auth_private_endpoint_id
  }, null)
}

output "landing_zones" {
  value = {
    for k, v in module.landing_zones :
    k => {
      workspace_id         = v.workspace_id
      workspace_name       = v.workspace_name
      workspace_url        = v.workspace_url
      workspace_resource_id = v.workspace_resource_id
      application          = v.application
      stage                = v.stage
      audit_variant        = v.audit_variant
      resource_group_name  = v.resource_group_name
      access_connector_id  = v.access_connector_id
      storage_account_id   = v.storage_account_id
      storage_account_name = v.storage_account_name
      storage_filesystems  = v.storage_filesystems
      key_vault_id         = v.key_vault_id
      key_vault_name       = v.key_vault_name
      vnet_id              = v.vnet_id
      subnet_ids           = v.subnet_ids
      private_endpoint_ids = v.private_endpoint_ids
    }
  }
}
