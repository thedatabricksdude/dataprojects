data "azurerm_client_config" "current" {}

data "azurerm_resource_group" "hub_network" {
  name = var.resource_groups.hub_network
}

data "azurerm_resource_group" "shared_services" {
  name = var.resource_groups.shared_services
}

data "azurerm_resource_group" "web_auth" {
  name = var.resource_groups.web_auth
}

data "azurerm_resource_group" "workspaces" {
  for_each = var.resource_groups.workspaces
  name     = each.value
}
