module "cluster_policies" {
  for_each = var.cluster_policy_templates
  source   = "../../modules/databricks/cluster_policy_template"

  providers = {
    databricks = databricks.account
  }

  workspace_id            = local.landing_zones[each.value.workspace_key].workspace_id
  name                    = each.value.name
  template                = each.value.template
  max_dbu                 = try(each.value.max_dbu, 10)
  max_clusters_per_user   = try(each.value.max_clusters_per_user, 3)
  autotermination_minutes = try(each.value.autotermination_minutes, 30)
  policy_overrides_json   = try(each.value.policy_overrides_json, "{}")
  permissions             = try(each.value.permissions, {})

  depends_on = [
    databricks_mws_permission_assignment.workspace_groups,
    databricks_entitlements.workspace_groups,
  ]
}
