resource "databricks_metastore" "this" {
  provider      = databricks.account
  count         = var.unity_catalog.enabled ? 1 : 0
  name          = var.unity_catalog.metastore_name
  region        = coalesce(try(var.unity_catalog.region, null), local.platform.location)
  owner         = var.unity_catalog.owner
  storage_root  = local.metastore_storage_root
  force_destroy = try(var.unity_catalog.force_destroy, false)
}

resource "databricks_metastore_data_access" "default" {
  provider     = databricks.account
  count        = var.unity_catalog.enabled ? 1 : 0
  metastore_id = databricks_metastore.this[0].id
  name         = "default-${var.unity_catalog.metastore_storage_workspace_key}"
  is_default   = true

  azure_managed_identity {
    access_connector_id = local.landing_zones[var.unity_catalog.metastore_storage_workspace_key].access_connector_id
  }

  provider_config {
    workspace_id = local.admin_workspace_id
  }
}

resource "databricks_metastore_assignment" "workspaces" {
  provider     = databricks.account
  for_each     = var.unity_catalog.enabled ? local.landing_zones : {}
  workspace_id = each.value.workspace_id
  metastore_id = databricks_metastore.this[0].id
}

resource "databricks_storage_credential" "landing_zone" {
  provider = databricks.account
  for_each = var.unity_catalog.enabled ? local.landing_zones : {}

  name    = "${each.key}-mi"
  comment = "Storage credential backed by Databricks access connector for ${each.key}."

  azure_managed_identity {
    access_connector_id = each.value.access_connector_id
  }

  provider_config {
    workspace_id = local.admin_workspace_id
  }
}

module "catalogs" {
  for_each = var.unity_catalog.enabled ? var.catalogs : {}
  source   = "../../modules/databricks/catalog_bundle"

  providers = {
    databricks = databricks.account
  }

  catalog_name            = each.key
  catalog_comment         = try(each.value.comment, null)
  catalog_owner           = try(each.value.owner, var.unity_catalog.owner)
  metastore_id            = databricks_metastore.this[0].id
  workspace_context_id    = local.admin_workspace_id
  storage_credential_name = databricks_storage_credential.landing_zone[each.value.storage_workspace_key].name
  storage_root_url        = format(
    "abfss://%s@%s.dfs.core.windows.net/%s",
    each.value.storage_container,
    local.landing_zones[each.value.storage_workspace_key].storage_account_name,
    trim(coalesce(try(each.value.storage_subpath, null), lower(each.key)), "/"),
  )
  schemas = try(each.value.schemas, {})

  depends_on = [
    databricks_metastore_assignment.workspaces,
    databricks_storage_credential.landing_zone,
    databricks_group.account_groups,
  ]
}
