output "workspace_ids" {
  value = { for k, v in local.landing_zones : k => v.workspace_id }
}

output "account_group_names" {
  value = sort(keys(databricks_group.account_groups))
}

output "metastore_id" {
  value = try(databricks_metastore.this[0].id, null)
}

output "catalog_names" {
  value = keys(module.catalogs)
}

output "cluster_policy_ids" {
  value = { for k, v in module.cluster_policies : k => v.id }
}

output "sql_warehouse_ids" {
  value = { for k, v in module.sql_warehouses : k => v.id }
}
