data "terraform_remote_state" "foundation" {
  backend = "azurerm"

  config = {
    resource_group_name  = var.foundation_state.resource_group_name
    storage_account_name = var.foundation_state.storage_account_name
    container_name       = var.foundation_state.container_name
    key                  = var.foundation_state.key
    use_azuread_auth     = try(var.foundation_state.use_azuread_auth, true)
  }
}
