module "sql_warehouses" {
  for_each = var.sql_warehouses
  source   = "../../modules/databricks/sql_warehouse"

  providers = {
    databricks = databricks.account
  }

  workspace_id             = local.landing_zones[each.value.workspace_key].workspace_id
  name                     = each.value.name
  cluster_size             = each.value.cluster_size
  min_num_clusters         = try(each.value.min_num_clusters, 1)
  max_num_clusters         = try(each.value.max_num_clusters, 1)
  auto_stop_mins           = try(each.value.auto_stop_mins, 30)
  enable_photon            = try(each.value.enable_photon, true)
  enable_serverless_compute = try(each.value.enable_serverless_compute, false)
  permissions              = try(each.value.permissions, {})

  depends_on = [databricks_entitlements.workspace_groups]
}
