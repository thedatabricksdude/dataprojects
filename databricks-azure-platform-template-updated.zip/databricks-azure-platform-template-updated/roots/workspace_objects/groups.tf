resource "databricks_group" "account_groups" {
  provider     = databricks.account
  for_each     = toset(local.all_group_names)
  display_name = each.value
}

resource "databricks_mws_permission_assignment" "workspace_groups" {
  provider     = databricks.account
  for_each     = { for item in local.workspace_personas : item.key => item }

  workspace_id = each.value.workspace_id
  principal_id = databricks_group.account_groups[each.value.group_name].id
  permissions  = each.value.permissions
}

resource "databricks_entitlements" "workspace_groups" {
  provider = databricks.account
  for_each = { for item in local.workspace_personas : item.key => item }

  group_id                  = databricks_group.account_groups[each.value.group_name].id
  workspace_access          = true
  databricks_sql_access     = contains(var.roles_with_sql_access, each.value.role)
  allow_cluster_create      = contains(var.roles_allowed_to_create_clusters, each.value.role)
  allow_instance_pool_create = contains(var.roles_allowed_to_create_instance_pools, each.value.role)

  provider_config {
    workspace_id = each.value.workspace_id
  }

  depends_on = [databricks_mws_permission_assignment.workspace_groups]
}
