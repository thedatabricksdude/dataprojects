locals {
  foundation    = data.terraform_remote_state.foundation.outputs
  platform      = local.foundation.platform
  landing_zones = local.foundation.landing_zones

  workspace_personas = flatten([
    for workspace_key, workspace in local.landing_zones : [
      for role in var.workspace_roles : {
        key           = "${workspace_key}|${role}"
        workspace_key = workspace_key
        workspace_id  = workspace.workspace_id
        workspace_name = workspace.workspace_name
        application   = workspace.application
        stage         = workspace.stage
        audit_variant = workspace.audit_variant
        role          = role
        group_name = format(
          "%s-%s-%s%s-%s-%s",
          var.asset_type,
          var.region_code,
          workspace.application,
          workspace.audit_variant ? "-audit" : "",
          workspace.stage,
          role,
        )
        permissions = lookup(var.workspace_role_to_permission, role, ["USER"])
      }
    ]
  ])

  platform_group_names = [
    for role in var.platform_roles : format("%s-%s-platform-%s", var.asset_type, var.region_code, role)
  ]

  catalog_group_names = flatten([
    for catalog_name, catalog in var.catalogs : [
      format("uc-%s-reader", lower(catalog_name)),
      format("uc-%s-writer", lower(catalog_name)),
      format("uc-%s-manager", lower(catalog_name))
    ]
  ])

  schema_group_names = flatten([
    for catalog_name, catalog in var.catalogs : flatten([
      for schema_name, schema in try(catalog.schemas, {}) : [
        format("uc-%s-%s-reader", lower(catalog_name), lower(schema_name)),
        format("uc-%s-%s-writer", lower(catalog_name), lower(schema_name)),
        format("uc-%s-%s-manager", lower(catalog_name), lower(schema_name))
      ]
    ])
  ])

  phi_group_names = distinct(concat(
    ["phi-reader-all"],
    [for catalog_name, catalog in var.catalogs : format("phi-reader-%s", lower(catalog_name))],
    flatten([
      for catalog_name, catalog in var.catalogs : [
        for schema_name, schema in try(catalog.schemas, {}) : format("phi-reader-%s-%s", lower(catalog_name), lower(schema_name))
      ]
    ])
  ))

  all_group_names = distinct(concat(
    local.platform_group_names,
    [for p in local.workspace_personas : p.group_name],
    local.catalog_group_names,
    local.schema_group_names,
    local.phi_group_names,
    tolist(var.additional_account_groups),
  ))

  admin_workspace_id = local.landing_zones[var.unity_catalog.admin_workspace_key].workspace_id

  metastore_storage_root = format(
    "abfss://%s@%s.dfs.core.windows.net/%s",
    var.unity_catalog.metastore_storage_container,
    local.landing_zones[var.unity_catalog.metastore_storage_workspace_key].storage_account_name,
    trim(try(var.unity_catalog.metastore_storage_subpath, "unity-catalog/metastore"), "/"),
  )
}
