variable "databricks_account_id" {
  description = "Azure Databricks account ID."
  type        = string
}

variable "foundation_state" {
  description = "AzureRM remote state location for the foundation root."
  type = object({
    resource_group_name  = string
    storage_account_name = string
    container_name       = string
    key                  = string
    use_azuread_auth     = optional(bool, true)
  })
}

variable "asset_type" {
  description = "Naming prefix for workspace persona groups."
  type        = string
  default     = "dbx"
}

variable "region_code" {
  description = "Short region code used in group names."
  type        = string
}

variable "platform_roles" {
  description = "Platform groups that are not tied to a single workspace."
  type        = list(string)
  default = [
    "account-admin",
    "metastore-admin",
    "security-admin",
    "audit-reviewer"
  ]
}

variable "workspace_roles" {
  description = "Workspace persona roles."
  type        = list(string)
  default = [
    "workspace-admin",
    "data-steward",
    "data-engineer",
    "analytics-engineer",
    "data-scientist",
    "ml-engineer",
    "bi-developer",
    "data-analyst",
    "business-consumer-readonly",
    "audit-reviewer"
  ]
}

variable "workspace_role_to_permission" {
  description = "Workspace assignment level for each persona role."
  type        = map(list(string))
  default = {
    workspace-admin            = ["ADMIN"]
    data-steward               = ["USER"]
    data-engineer              = ["USER"]
    analytics-engineer         = ["USER"]
    data-scientist             = ["USER"]
    ml-engineer                = ["USER"]
    bi-developer               = ["USER"]
    data-analyst               = ["USER"]
    business-consumer-readonly = ["USER"]
    audit-reviewer             = ["USER"]
  }
}

variable "roles_with_sql_access" {
  description = "Workspace persona roles that should receive Databricks SQL access."
  type        = set(string)
  default = [
    "workspace-admin",
    "data-steward",
    "data-engineer",
    "analytics-engineer",
    "bi-developer",
    "data-analyst",
    "business-consumer-readonly",
    "audit-reviewer"
  ]
}

variable "roles_allowed_to_create_clusters" {
  description = "Workspace persona roles that should receive cluster-create entitlement."
  type        = set(string)
  default = [
    "workspace-admin",
    "data-engineer",
    "analytics-engineer",
    "data-scientist",
    "ml-engineer"
  ]
}

variable "roles_allowed_to_create_instance_pools" {
  description = "Workspace persona roles that should receive instance-pool-create entitlement."
  type        = set(string)
  default     = ["workspace-admin"]
}

variable "additional_account_groups" {
  description = "Any extra account groups you want created without changing module code."
  type        = set(string)
  default     = []
}

variable "unity_catalog" {
  description = "Unity Catalog platform settings."
  type = object({
    enabled                            = bool
    metastore_name                     = string
    region                             = optional(string, null)
    owner                              = string
    force_destroy                      = optional(bool, false)
    admin_workspace_key                = string
    metastore_storage_workspace_key    = string
    metastore_storage_container        = string
    metastore_storage_subpath          = optional(string, "unity-catalog/metastore")
  })
}

variable "catalogs" {
  description = "Catalog definitions. The workspace-objects root will create matching uc-* and phi-reader-* groups automatically."
  type = map(object({
    comment               = optional(string, null)
    owner                 = optional(string, null)
    storage_workspace_key = string
    storage_container     = string
    storage_subpath       = optional(string, null)
    schemas = optional(map(object({
      comment = optional(string, null)
      owner   = optional(string, null)
    })), {})
  }))
  default = {}
}

variable "cluster_policy_templates" {
  description = "Policies to create."
  type = map(object({
    workspace_key          = string
    name                   = string
    template               = string
    max_dbu                = optional(number, 10)
    max_clusters_per_user  = optional(number, 3)
    autotermination_minutes = optional(number, 30)
    policy_overrides_json  = optional(string, "{}")
    permissions            = optional(map(string), {})
  }))
  default = {}
}

variable "sql_warehouses" {
  description = "SQL warehouses to create."
  type = map(object({
    workspace_key             = string
    name                      = string
    cluster_size              = string
    min_num_clusters          = optional(number, 1)
    max_num_clusters          = optional(number, 1)
    auto_stop_mins            = optional(number, 30)
    enable_photon             = optional(bool, true)
    enable_serverless_compute = optional(bool, false)
    permissions               = optional(map(string), {})
  }))
  default = {}
}
