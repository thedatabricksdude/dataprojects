resource "databricks_service_principal" "deployment" {
  provider       = databricks.account
  application_id = var.deployment_service_principal_client_id
  display_name   = var.deployment_service_principal_display_name
}

resource "databricks_service_principal_role" "account_admin" {
  count = var.grant_account_admin ? 1 : 0

  provider             = databricks.account
  service_principal_id = databricks_service_principal.deployment.id
  role                 = "account_admin"
}
