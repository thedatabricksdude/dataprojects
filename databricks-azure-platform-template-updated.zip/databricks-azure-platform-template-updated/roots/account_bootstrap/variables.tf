variable "databricks_account_id" {
  description = "Azure Databricks account ID."
  type        = string
}

variable "deployment_service_principal_client_id" {
  description = "Microsoft Entra application (client) ID for the Azure deployment service principal."
  type        = string
}

variable "deployment_service_principal_display_name" {
  description = "Friendly display name for the deployment service principal inside Databricks."
  type        = string
}

variable "grant_account_admin" {
  description = "Whether to grant the deployment service principal the Databricks account_admin role."
  type        = bool
  default     = true
}
