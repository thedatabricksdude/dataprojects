output "service_principal_id" {
  value = databricks_service_principal.deployment.id
}

output "application_id" {
  value = databricks_service_principal.deployment.application_id
}
