resource_group_name  = "rg-dbxlab-tfstate-prod"
storage_account_name = "stdbxlabtfprod001"
container_name       = "databricks-workspace-objects"
key                  = "prod/workspace-objects.tfstate"
use_azuread_auth     = true
