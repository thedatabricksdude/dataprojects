resource_group_name  = "rg-dbxlab-tfstate-prod"
storage_account_name = "stdbxlabtfprod001"
container_name       = "databricks-account-bootstrap"
key                  = "prod/account-bootstrap.tfstate"
use_azuread_auth     = true
