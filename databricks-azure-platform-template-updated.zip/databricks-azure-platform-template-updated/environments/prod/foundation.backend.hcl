resource_group_name  = "rg-dbxlab-tfstate-prod"
storage_account_name = "stdbxlabtfprod001"
container_name       = "databricks-foundation"
key                  = "prod/foundation.tfstate"
use_azuread_auth     = true
