resource_group_name  = "rg-dbxlab-tfstate-qa"
storage_account_name = "stdbxlabtfqa001"
container_name       = "databricks-account-bootstrap"
key                  = "qa/account-bootstrap.tfstate"
use_azuread_auth     = true
