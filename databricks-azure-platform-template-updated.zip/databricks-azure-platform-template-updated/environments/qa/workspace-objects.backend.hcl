resource_group_name  = "rg-dbxlab-tfstate-qa"
storage_account_name = "stdbxlabtfqa001"
container_name       = "databricks-workspace-objects"
key                  = "qa/workspace-objects.tfstate"
use_azuread_auth     = true
