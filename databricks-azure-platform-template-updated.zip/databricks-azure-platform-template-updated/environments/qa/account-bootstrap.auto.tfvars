databricks_account_id                     = "00000000-0000-0000-0000-000000000000"
deployment_service_principal_client_id   = "00000000-0000-0000-0000-000000000000"
deployment_service_principal_display_name = "spn-dbxlab-qa-terraform"
grant_account_admin                      = true
