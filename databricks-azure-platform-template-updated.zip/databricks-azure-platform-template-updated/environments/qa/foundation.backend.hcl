resource_group_name  = "rg-dbxlab-tfstate-qa"
storage_account_name = "stdbxlabtfqa001"
container_name       = "databricks-foundation"
key                  = "qa/foundation.tfstate"
use_azuread_auth     = true
