resource_group_name  = "rg-dbxlab-tfstate-dev"
storage_account_name = "stdbxlabtfdev001"
container_name       = "databricks-workspace-objects"
key                  = "dev/workspace-objects.tfstate"
use_azuread_auth     = true
