subscription_id = null
platform_name   = "enterprise-databricks-platform"
environment     = "dev"
location        = "westus2"
region_code     = "wus2"

resource_groups = {
  hub_network     = "rg-dbx-hub-dev"
  shared_services = "rg-dbx-shared-dev"
  web_auth        = "rg-dbx-webauth-dev"
  workspaces = {
    enterpriseapps-dev  = "rg-dbx-enterpriseapps-dev"
    enterpriseapps-prod = "rg-dbx-enterpriseapps-prod"
  }
}

hub_network = {
  vnet_name                        = "vnet-dbx-hub-dev"
  address_space                    = ["10.10.0.0/20"]
  private_endpoint_subnet_prefixes = ["10.10.0.0/24"]
  web_auth_public_subnet_prefixes  = ["10.10.1.0/24"]
  web_auth_private_subnet_prefixes = ["10.10.2.0/24"]
  create_route_table               = false
}

web_auth_workspace = {
  create                      = true
  workspace_name              = "dbx-wus2-private-web-auth-dev"
  managed_resource_group_name = "rg-dbx-webauth-managed-dev"
  compliance = {
    automatic_cluster_update_enabled      = true
    compliance_security_profile_enabled   = true
    compliance_security_profile_standards = ["NONE"]
    enhanced_security_monitoring_enabled  = true
  }
}

landing_zones = {
  enterpriseapps-dev = {
    workspace_name               = "dbx-wus2-enterpriseapps-dev"
    managed_resource_group_name  = "rg-dbx-enterpriseapps-dev-managed"
    application                  = "enterpriseapps"
    stage                        = "dev"
    audit_variant                = false
    vnet_name                    = "vnet-dbx-enterpriseapps-dev"
    vnet_address_space           = ["10.20.0.0/20"]
    public_subnet_prefixes       = ["10.20.1.0/24"]
    private_subnet_prefixes      = ["10.20.2.0/24"]
    private_endpoint_subnet_prefixes = ["10.20.3.0/24"]
    adls_account_name            = "stdbxeaappdev001"
    key_vault_name               = "kv-dbx-ea-dev-001"
    access_connector_name        = "ac-dbx-ea-dev-001"
    compliance = {
      automatic_cluster_update_enabled      = true
      compliance_security_profile_enabled   = true
      compliance_security_profile_standards = ["NONE"]
      enhanced_security_monitoring_enabled  = true
    }
  }

  enterpriseapps-prod = {
    workspace_name               = "dbx-wus2-enterpriseapps-prod"
    managed_resource_group_name  = "rg-dbx-enterpriseapps-prod-managed"
    application                  = "enterpriseapps"
    stage                        = "prod"
    audit_variant                = true
    vnet_name                    = "vnet-dbx-enterpriseapps-prod"
    vnet_address_space           = ["10.21.0.0/20"]
    public_subnet_prefixes       = ["10.21.1.0/24"]
    private_subnet_prefixes      = ["10.21.2.0/24"]
    private_endpoint_subnet_prefixes = ["10.21.3.0/24"]
    adls_account_name            = "stdbxeaappprod001"
    key_vault_name               = "kv-dbx-ea-prod-001"
    access_connector_name        = "ac-dbx-ea-prod-001"
    enable_delete_lock           = true
    compliance = {
      automatic_cluster_update_enabled      = true
      compliance_security_profile_enabled   = true
      compliance_security_profile_standards = ["HIPAA"]
      enhanced_security_monitoring_enabled  = true
    }
  }
}

create_private_dns_zones = true

# When create_private_dns_zones = false, populate these with pre-existing shared zone IDs instead.
# existing_private_dns_zone_ids = {
#   databricks = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-network-shared/providers/Microsoft.Network/privateDnsZones/privatelink.azuredatabricks.net"
#   blob       = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-network-shared/providers/Microsoft.Network/privateDnsZones/privatelink.blob.core.windows.net"
#   dfs        = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-network-shared/providers/Microsoft.Network/privateDnsZones/privatelink.dfs.core.windows.net"
#   key_vault  = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-network-shared/providers/Microsoft.Network/privateDnsZones/privatelink.vaultcore.azure.net"
# }

log_analytics_workspace_id = null

tags = {
  owner       = "platform-team"
  cost_center = "data-platform"
}
