resource_group_name  = "rg-dbxlab-tfstate-dev"
storage_account_name = "stdbxlabtfdev001"
container_name       = "databricks-account-bootstrap"
key                  = "dev/account-bootstrap.tfstate"
use_azuread_auth     = true
