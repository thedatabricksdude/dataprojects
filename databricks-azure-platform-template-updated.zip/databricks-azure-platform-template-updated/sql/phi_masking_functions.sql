-- =====================================================================
-- PHI governance UDFs
-- =====================================================================
-- Assumptions:
--   1. Group names are account-level Databricks groups.
--   2. PHI authorizer groups are NOT nested under each other.
--   3. The masking function is applied with constant scope values.
--
-- Group patterns:
--   phi-reader-all
--   phi-reader-<catalog>
--   phi-reader-<catalog>-<schema>
-- =====================================================================

CREATE SCHEMA IF NOT EXISTS sec;

CREATE OR REPLACE FUNCTION sec.can_read_phi(
  object_catalog STRING,
  object_schema  STRING
)
RETURNS BOOLEAN
RETURN
  is_account_group_member('phi-reader-all')
  OR is_account_group_member(concat('phi-reader-', lower(object_catalog), '-', lower(object_schema)))
  OR is_account_group_member(concat('phi-reader-', lower(object_catalog)));

-- Generic string redaction.
CREATE OR REPLACE FUNCTION sec.mask_phi_string(
  value          STRING,
  object_catalog STRING,
  object_schema  STRING
)
RETURNS STRING
RETURN CASE
  WHEN value IS NULL THEN NULL
  WHEN sec.can_read_phi(object_catalog, object_schema) THEN value
  ELSE 'REDACTED'
END;

-- Email-specific masking template.
CREATE OR REPLACE FUNCTION sec.mask_phi_email(
  value          STRING,
  object_catalog STRING,
  object_schema  STRING
)
RETURNS STRING
RETURN CASE
  WHEN value IS NULL THEN NULL
  WHEN sec.can_read_phi(object_catalog, object_schema) THEN value
  ELSE regexp_replace(value, '(^.).*(@.*$)', '$1***$2')
END;

-- Numeric token / redaction template.
CREATE OR REPLACE FUNCTION sec.mask_phi_numeric(
  value          BIGINT,
  object_catalog STRING,
  object_schema  STRING
)
RETURNS BIGINT
RETURN CASE
  WHEN value IS NULL THEN NULL
  WHEN sec.can_read_phi(object_catalog, object_schema) THEN value
  ELSE NULL
END;

-- Date redaction template.
CREATE OR REPLACE FUNCTION sec.mask_phi_date(
  value          DATE,
  object_catalog STRING,
  object_schema  STRING
)
RETURNS DATE
RETURN CASE
  WHEN value IS NULL THEN NULL
  WHEN sec.can_read_phi(object_catalog, object_schema) THEN value
  ELSE NULL
END;
