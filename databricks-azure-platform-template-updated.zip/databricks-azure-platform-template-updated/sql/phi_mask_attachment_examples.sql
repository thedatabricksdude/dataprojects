-- =====================================================================
-- Column mask attachment examples
-- =====================================================================
-- IMPORTANT:
--   Pass the catalog and schema as constant literals when applying the mask.
--   Do NOT rely on current_catalog() or current_schema() inside the UDF.
-- =====================================================================

-- Example 1: string PHI in telcor.claims
ALTER TABLE telcor.claims.patient_events
ALTER COLUMN patient_name
SET MASK sec.mask_phi_string USING COLUMNS ('telcor', 'claims');

ALTER TABLE telcor.claims.patient_events
ALTER COLUMN patient_email
SET MASK sec.mask_phi_email USING COLUMNS ('telcor', 'claims');

-- Example 2: numeric PHI in telcor.claims
ALTER TABLE telcor.claims.patient_events
ALTER COLUMN member_id
SET MASK sec.mask_phi_numeric USING COLUMNS ('telcor', 'claims');

-- Example 3: date PHI in telcor.claims
ALTER TABLE telcor.claims.patient_events
ALTER COLUMN patient_dob
SET MASK sec.mask_phi_date USING COLUMNS ('telcor', 'claims');

-- Example 4: different schema in the same catalog
ALTER TABLE telcor.finance.revenue_events
ALTER COLUMN patient_name
SET MASK sec.mask_phi_string USING COLUMNS ('telcor', 'finance');
