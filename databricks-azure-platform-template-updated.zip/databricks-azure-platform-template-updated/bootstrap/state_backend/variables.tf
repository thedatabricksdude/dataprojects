variable "subscription_id" {
  description = "Optional Azure subscription ID. If null, Azure CLI / managed identity context is used."
  type        = string
  default     = null
}

variable "resource_group_name" {
  description = "Existing resource group where the Terraform backend storage account should be created."
  type        = string
}

variable "location" {
  description = "Azure region for the backend storage account."
  type        = string
}

variable "storage_account_name" {
  description = "Globally unique name for the remote state storage account."
  type        = string
}

variable "container_names" {
  description = "Blob containers to create for state. Usually one shared container such as tfstate is enough."
  type        = set(string)
  default     = ["tfstate"]
}

variable "tags" {
  description = "Tags for the backend storage account."
  type        = map(string)
  default     = {}
}
