output "backend_storage_account_name" {
  value = azurerm_storage_account.this.name
}

output "backend_containers" {
  value = { for k, v in azurerm_storage_container.this : k => v.name }
}

output "backend_example" {
  value = {
    resource_group_name  = data.azurerm_resource_group.this.name
    storage_account_name = azurerm_storage_account.this.name
    container_name       = one(var.container_names)
  }
}
