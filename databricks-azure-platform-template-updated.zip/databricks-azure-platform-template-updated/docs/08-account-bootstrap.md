# One-time Databricks account bootstrap

## Why this root exists

Azure knows about your deployment service principal after the Azure bootstrap repository creates it.
Databricks does **not** automatically treat that Microsoft Entra service principal as a Databricks account principal.

Before unattended Terraform can manage account-level Databricks objects, the service principal must be registered inside the Databricks account and typically granted the `account_admin` role.

## What this root does

`roots/account_bootstrap`:
- uses your own Azure CLI login (`auth_type = "azure-cli"`)
- connects to `https://accounts.azuredatabricks.net`
- registers the Azure deployment service principal in the Databricks account
- optionally grants it `account_admin`

## When to run it

Run this root once after:
1. the Azure bootstrap repository has created the service principal
2. `roots/foundation` has created at least one Databricks workspace/account context

## After it succeeds

The deployment service principal can authenticate to Databricks account APIs by using the environment variables expected by the pipeline.
