# Deployment runbook

## Step 0 – Understand the two-repo bootstrap order

This repository is only one half of the design.
The full order is:

1. Azure bootstrap repo: create remote state backend
2. Azure bootstrap repo: create resource groups, Key Vault, Microsoft Entra deployment identity, and self-hosted agent VM
3. This repo: deploy `roots/foundation` from the self-hosted agent pipeline
4. Azure bootstrap repo: deploy `roots/agent_runtime` to add peerings and private DNS links
5. This repo: deploy `roots/account_bootstrap` once from a local/admin context
6. This repo: use the Azure DevOps pipeline for ongoing `workspace_objects` plan/apply operations

## Step 1 – Fill in environment files

For each environment:
- update the backend files under `environments/<env>/`
- update the tfvars files under `environments/<env>/`
- update the Azure DevOps pipeline vars file under `pipelines/vars/<env>.yml`
- confirm the remote-state locations match the Azure bootstrap repo outputs
- set the Databricks account ID
- set group names, catalogs, cluster policies, and warehouses

## Step 2 – Authenticate for the one-time local bootstrap

### Azure provider

For the one-time `account_bootstrap` root, use Azure CLI:

```bash
az login
az account set --subscription <your-subscription-id>
```

### Databricks provider

For `account_bootstrap`, use your own Azure CLI identity with Databricks account-admin rights.

## Step 3 – Run foundation from the pipeline

Once the self-hosted agent is online in Azure DevOps, run the pipeline with foundation apply enabled.

That stage talks to Azure Resource Manager and creates:
- hub network objects
- private DNS zones
- web-auth workspace
- landing-zone workspaces
- storage, access connectors, Key Vaults, and private endpoints

## Step 4 – Hand back to the Azure bootstrap repo

After `foundation` succeeds, return to the Azure bootstrap repo and deploy the `agent_runtime` root so the self-hosted Azure DevOps VM is peered into the Databricks network path and linked to the private DNS zones.

## Step 5 – Register the deployment service principal in Databricks

```bash
cd roots/account_bootstrap
terraform init -backend-config=../../environments/dev/account-bootstrap.backend.hcl
terraform plan -var-file=../../environments/dev/account-bootstrap.auto.tfvars
terraform apply -var-file=../../environments/dev/account-bootstrap.auto.tfvars
```

This step is what allows the later pipeline to authenticate to Databricks using the Microsoft Entra deployment service principal.

## Step 6 – Run the workspace-objects pipeline

Once the self-hosted agent has both network line-of-sight and Databricks account bootstrap is complete, rerun the pipeline for `workspace_objects`.

The pipeline will:
- pull Azure and Databricks credentials from Key Vault using the VM managed identity
- plan/apply `roots/workspace_objects`

## Step 7 – Validate

### Azure-side validation

- hub VNet exists
- each spoke VNet exists
- front-end, browser-auth, storage, and Key Vault private endpoints are present
- private DNS zones are populated and linked
- public network access is disabled where intended
- agent VNet peerings and private DNS links are present

### Databricks-side validation

- deployment service principal exists in the Databricks account
- account groups exist
- workspace persona groups are assigned
- Unity Catalog metastore is assigned
- catalogs and schemas exist
- grants match the expected model
- cluster policies and SQL warehouses appear in the target workspaces

## Change-management advice

### Safe sequence for most changes

1. Apply `foundation` when changing Azure resources or workspace settings.
2. Apply `workspace_objects` for Databricks account and workspace objects.

### When to be careful

- changing workspace names or landing-zone keys ripples through remote-state consumers
- changing compliance profile standards may force workspace replacement
- moving a catalog to different storage is usually disruptive
- `databricks_grants` is authoritative and overwrites grants on the securable it manages

## Destroy advice

Destroy in reverse dependency order when you truly need to remove an environment:
1. `roots/workspace_objects`
2. `roots/account_bootstrap`
3. `roots/foundation`
4. the Azure bootstrap repo's `agent_runtime`
5. the Azure bootstrap repo's `platform_bootstrap`
6. backend bootstrap only if the environment is fully retired
