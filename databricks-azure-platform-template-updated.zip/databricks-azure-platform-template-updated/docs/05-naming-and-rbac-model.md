# Naming and RBAC model

## Workspace persona groups

Pattern:

```text
<asset>-<region>-<application>[-audit]-<stage>-<role>
```

Examples:

- `dbx-wus2-enterpriseapps-prod-data-engineer`
- `dbx-wus2-enterpriseapps-audit-prod-audit-reviewer`
- `dbx-wus2-clinicaldatamanagement-dev-data-analyst`

## Platform groups

Pattern:

```text
dbx-<region>-platform-<role>
```

Examples:

- `dbx-wus2-platform-account-admin`
- `dbx-wus2-platform-metastore-admin`
- `dbx-wus2-platform-security-admin`
- `dbx-wus2-platform-audit-reviewer`

## Unity Catalog groups

### Catalog scope

- `uc-<catalog>-reader`
- `uc-<catalog>-writer`
- `uc-<catalog>-manager`

### Schema scope

- `uc-<catalog>-<schema>-reader`
- `uc-<catalog>-<schema>-writer`
- `uc-<catalog>-<schema>-manager`

## PHI groups

- `phi-reader-all`
- `phi-reader-<catalog>`
- `phi-reader-<catalog>-<schema>`

### Important PHI rule

Do **not** nest PHI groups inside each other.

If you do, group membership checks can become broader than intended.

## Effective access model

A user’s effective access should be explained as three separate layers:

1. **Workspace access**
   - granted by workspace persona group assignment and entitlements
2. **Data access**
   - granted by Unity Catalog groups and grants
3. **PHI visibility**
   - granted by PHI groups used by masking functions

That separation is deliberate. It stops “can log into the workspace” from automatically meaning “can read all data” or “can see unmasked PHI.”
