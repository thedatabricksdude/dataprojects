# Design defense notes

This file is written in “meeting language” so you can explain and justify the pattern.

## Why separate Terraform roots?

**Answer:** because Azure landing-zone resources and Databricks workspace objects are different lifecycles, different providers, and different failure domains.

A network or Private Link change should not require a plan that also touches Unity Catalog grants. A catalog or SQL warehouse change should not be blocked by unrelated Azure networking drift.

## Why use remote state between roots?

**Answer:** because the workspace objects root still needs facts created by the infrastructure root, especially workspace IDs, URLs, access connectors, and storage locations.

Remote state is the lightest coupling that still keeps the roots coordinated.

## Why not put everything in one apply?

**Answer:** because monolithic Terraform for Databricks often becomes fragile.

You get larger plans, noisier diffs, harder approvals, and provider-ordering issues. The split makes change scopes smaller and easier to reason about.

## Why a dedicated web-auth host workspace?

**Answer:** because browser-based SSO over Private Link depends on a `browser_authentication` endpoint, and production guidance strongly favors a dedicated workspace so that deleting a normal workload workspace does not break sign-in for every other workspace in the region.

## Why give each workload its own spoke VNet and storage account?

**Answer:** for blast-radius control and cleaner governance.

Per-workspace landing zones make it easier to:

- reason about data ownership
- restrict network paths
- attach diagnostics and RBAC cleanly
- avoid accidental cross-workspace dependency
- support workload-by-workload exceptions later

## Why create Databricks access connectors now?

**Answer:** because they are the cleanest bridge between Azure RBAC and Databricks Unity Catalog on Azure.

They let you grant storage access to a managed identity instead of putting secrets into Terraform.

## Why create Key Vaults even if Databricks secrets are not yet configured?

**Answer:** because platform teams usually need a private, governed place for certificates, application secrets, and future CMK inputs even if those are not all wired on day one.

## Why use authoritative grants?

**Answer:** because governance should be explicit.

The tradeoff is that authoritative resources will overwrite drift. That is usually the right answer for compliance, but it means you must manage grants intentionally and avoid “one-off” manual permissions in the UI.

## Why separate environments by backend key instead of only by var files?

**Answer:** because state separation is the real boundary.

A `prod.tfvars` file alone does not stop a mistaken plan from targeting the wrong environment. Separate backend keys make the boundary much stronger.

## Why not manage resource groups here?

**Answer:** because your deployment contract says IT pre-creates the resource groups.

Keeping RG ownership outside this project avoids conflicts about naming, policy attachment, locks, and subscription-level guardrails.
