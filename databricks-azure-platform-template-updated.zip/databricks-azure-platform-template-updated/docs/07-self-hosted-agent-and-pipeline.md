# Self-hosted agent and pipeline model

This repository's pipeline is designed for a **private-link** Azure Databricks implementation.

## Why the pipeline runs on a self-hosted agent

The workspace URLs, browser-auth endpoint, storage private endpoints, and other private-link resources are meant to be reachable only from approved VNets.
A Microsoft-hosted runner does not naturally live inside that network path.

That is why the companion Azure bootstrap repository creates a Linux VM self-hosted agent **before** the Databricks foundation pipeline runs.

## Why the first foundation run works from that VM

The self-hosted agent does not need existing peering to create the Azure foundation.
The `foundation` root talks to Azure Resource Manager and creates the Databricks infrastructure.

The follow-up `agent_runtime` root then adds the peerings and private DNS links that let the same VM resolve and reach the private Databricks endpoints afterward.

## How authentication works in the pipeline

The pipeline does not store Azure client secrets in Azure DevOps variable groups.
Instead, the self-hosted VM uses its **managed identity** to read the following secrets from Key Vault at job runtime:

- `ARM_CLIENT_ID`
- `ARM_CLIENT_SECRET`
- `ARM_TENANT_ID`
- `ARM_SUBSCRIPTION_ID`
- `DATABRICKS_ACCOUNT_ID`

The pipeline scripts then export those values as environment variables before Terraform runs.

## What the pipeline deploys

The pipeline included in this repo handles:
- `roots/foundation` plan/apply
- `roots/workspace_objects` plan/apply

The one-time `roots/account_bootstrap` helper is intentionally left as a local bootstrap step because you use your own Azure CLI identity to register the deployment service principal in the Databricks account for the first time.
