# Architecture overview

## What this repository implements

This template implements the **Databricks-side** of a private Azure Databricks platform pattern for private networking, workspace hardening, and repeatable governance.

The companion Azure bootstrap repository owns the shared Azure prerequisites such as:
- Terraform state storage
- Microsoft Entra deployment identity
- Key Vault for deployment secrets
- self-hosted Azure DevOps agent VNet and VM

This repository owns the Databricks platform itself.

## Main roots in this repository

### Root 1 – `roots/foundation`

This root creates the Azure Databricks platform foundation:
- hub VNet / transit network
- private DNS zones
- dedicated web-auth host workspace
- workload spoke VNets
- ADLS Gen2 accounts and filesystems
- Key Vaults
- Databricks access connectors
- Azure Databricks workspaces
- private endpoints for front-end and back-end connectivity

### Root 2 – `roots/workspace_objects`

This root creates the Databricks account and workspace objects:
- account groups
- workspace permission assignments
- workspace entitlements
- Unity Catalog metastore, storage credentials, external locations, catalogs, schemas, grants
- cluster policies
- SQL warehouses

### Helper root – `roots/account_bootstrap`

This is a one-time bootstrap helper that registers the Azure deployment service principal inside the Databricks account and can grant it the `account_admin` role.

It is not part of the steady-state operating model. It exists only because Azure knowing about a service principal does not automatically make Databricks trust it as an account principal.

## Why the split matters

This is not just a folder preference. It is an operating model.

- Azure resources change on a different cadence than Databricks objects.
- Databricks provider authentication and lazy workspace discovery are easier to reason about when workspace creation is already complete.
- Remote state gives the second root exactly the information it needs without forcing a monolithic plan.
- Keeping the pipeline runner in a separate Azure bootstrap repo prevents CI/CD concerns from contaminating the Databricks state model.

## High-level network pattern

### Hub / transit network

The hub network hosts:
- a private-endpoint subnet for Databricks front-end connectivity
- a VNet-injected web-auth host workspace
- the `browser_authentication` private endpoint
- private DNS zones (or links to pre-existing shared zones) shared across spoke workspaces

### Spoke / workload landing zones

Each workload landing zone creates:
- its own spoke VNet
- Databricks public and private subnets for VNet injection
- a spoke private-endpoint subnet
- its own ADLS Gen2 storage account
- its own Key Vault
- a Databricks access connector
- a Databricks workspace
- a front-end private endpoint in the hub
- a back-end private endpoint in the spoke

## What “private-link workspace” means here

For each workload workspace this template aims at the common “complete private isolation for classic compute” pattern:
- front-end private endpoint in the hub
- browser authentication endpoint in the hub
- back-end private endpoint in the spoke
- public network access disabled on the workspace
- VNet injection and Secure Cluster Connectivity

## Output contract between roots

The `foundation` root exports a stable map of landing-zone metadata. The `workspace_objects` root uses that map to discover:
- workspace IDs
- workspace names
- workspace URLs
- access connector IDs
- storage account names and ABFSS paths
- Key Vault IDs
- workspace metadata such as application, stage, and audit flag

That output contract is what lets the two main roots evolve independently.
