# What changed from the original two projects

This repository combines the original Azure workspace foundation and Databricks RBAC blueprint into one opinionated platform template.

## How the original Azure workspace project changed

The original workspace project created Azure Databricks workspaces, but it did not fully model the two-root operating pattern you wanted.

In this unified version it was expanded into the `roots/foundation` root and reusable Azure modules that now include:

- hub-and-spoke networking
- private DNS zones or links to existing shared zones
- dedicated browser-auth host workspace pattern
- spoke landing-zone modules
- ADLS Gen2, Key Vault, access connectors
- front-end and back-end private endpoints
- structured outputs for remote-state consumption

## How the original RBAC blueprint changed

The original RBAC blueprint described the governance model and included Terraform for groups and grants.

In this unified version it was expanded into the `roots/workspace_objects` root and reusable Databricks modules that now include:

- remote-state consumption from the foundation root
- account groups and workspace assignments
- workspace entitlements
- Unity Catalog metastore and storage credentials
- reusable catalog bundles, schema grants, cluster policies, and SQL warehouses
- preserved SQL masking examples
- preserved naming references under `reference/`

## What stayed intentionally separate

Even though the two source projects are now in one repository, the actual implementation remains intentionally split into two Terraform roots:

- `roots/foundation`
- `roots/workspace_objects`

That is the key architecture decision behind the final design.
