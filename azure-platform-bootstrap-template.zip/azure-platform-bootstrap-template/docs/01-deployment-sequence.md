# Deployment sequence

## Phase 0: prerequisites

Before running Terraform, make sure you have:
- an Azure subscription
- Azure CLI installed locally
- Terraform CLI installed locally
- rights in Microsoft Entra to create app registrations and service principals
- permission in Azure to create role assignments on the target scopes
- an Azure DevOps organization and a PAT you can use to register a self-hosted agent

## Phase 1: create the remote-state backend

Directory:
- `bootstrap/state_backend`

Run locally because this root creates the backend that later roots use.

Typical commands:

```bash
cd bootstrap/state_backend
cp ../../environments/dev/state-backend.auto.tfvars.example state-backend.auto.tfvars
# edit values
terraform init
terraform plan -var-file=state-backend.auto.tfvars
terraform apply -var-file=state-backend.auto.tfvars
```

## Phase 2: create shared Azure bootstrap resources and the self-hosted agent

Directory:
- `roots/platform_bootstrap`

This root should use the newly created backend.

Typical commands:

```bash
cd roots/platform_bootstrap
cp ../../environments/dev/platform-bootstrap.backend.hcl.example platform-bootstrap.backend.hcl
cp ../../environments/dev/platform-bootstrap.auto.tfvars.example platform-bootstrap.auto.tfvars
# edit values
terraform init -backend-config=platform-bootstrap.backend.hcl
terraform plan -var-file=platform-bootstrap.auto.tfvars
terraform apply -var-file=platform-bootstrap.auto.tfvars
```

This phase creates:
- the shared resource groups
- the Key Vault
- the Microsoft Entra app registration and service principal
- role assignments for the deployment identity
- the agent VNet and subnet
- the self-hosted Azure DevOps agent VM

Record these outputs for the Databricks repo:
- resource group names
- Key Vault name
- deployment service principal client ID
- agent VNet information
- state backend information

## Phase 3: create the Databricks foundation from Azure DevOps

Go to the Databricks repo, push it to Azure DevOps, and run the foundation pipeline against the self-hosted agent.

At this point the agent already exists, but it is not yet peered to the Databricks networks. That is fine for the `foundation` root because it talks to Azure Resource Manager, not to the private workspace endpoints.

## Phase 4: peer the agent network to the Databricks networks

Directory:
- `roots/agent_runtime`

This root reads remote state from both repos and can only run after the Databricks foundation exists.

Typical commands:

```bash
cd roots/agent_runtime
cp ../../environments/dev/agent-runtime.backend.hcl.example agent-runtime.backend.hcl
cp ../../environments/dev/agent-runtime.auto.tfvars.example agent-runtime.auto.tfvars
# edit values
terraform init -backend-config=agent-runtime.backend.hcl
terraform plan -var-file=agent-runtime.auto.tfvars
terraform apply -var-file=agent-runtime.auto.tfvars
```

This phase creates:
- peering between the agent VNet and the Databricks hub VNet
- optional direct peering between the agent VNet and each Databricks spoke VNet
- private DNS zone links from the agent VNet to the Databricks private DNS zones

## Phase 5: Databricks account bootstrap and workspace objects

Run the Databricks repo's `roots/account_bootstrap` once so the Azure deployment service principal exists inside the Databricks account.

After that, run the Databricks repo pipeline for `workspace_objects` on the same self-hosted agent.
