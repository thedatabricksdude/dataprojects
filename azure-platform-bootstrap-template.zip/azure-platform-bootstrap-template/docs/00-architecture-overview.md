# Architecture overview

This repo models the Azure-side prerequisites that surround a private Azure Databricks deployment.

## Root 1: bootstrap/state_backend

Purpose: create the remote-state landing zone.

Creates:
- a resource group for Terraform state
- a storage account with secure defaults
- one or more blob containers for separate root states

Why it exists:
- remote state cannot be used until the backend exists
- keeping it isolated makes the chicken-and-egg problem obvious and manageable

## Root 2: roots/platform_bootstrap

Purpose: create the Azure platform scaffolding that the Databricks repo expects.

Creates:
- resource groups for hub networking, shared services, web auth, agent hosting, and workspace landing zones
- Microsoft Entra app registration and service principal for Terraform deployments
- a Key Vault that stores the deployment service principal credentials
- role assignments so the deployment identity can manage Azure resources, RBAC, state, and secrets
- the agent VNet and subnet

Why it exists:
- the Databricks foundation root assumes these Azure prerequisites already exist
- the deployment identity must exist before pipelines can be unattended
- the agent VNet can exist before the Databricks VNets exist

## Root 3: roots/agent_runtime

Purpose: finish the CI/CD network path after the Databricks foundation exists.

Reads remote state from:
- this repo's `platform_bootstrap` root
- the Databricks repo's `foundation` root

Creates:
- private DNS links from the agent VNet to Databricks private DNS zones
- peering from the agent VNet to the Databricks hub VNet
- optional direct peering from the agent VNet to each Databricks spoke VNet
- the self-hosted Azure DevOps Linux agent VM

Why it exists:
- you cannot peer to VNets that do not exist yet
- a self-hosted runner must have network line-of-sight to private Databricks endpoints

## Identity model

There are two distinct identities in play:

1. **Terraform deployment service principal**
   - stored in Key Vault
   - used by Terraform to authenticate to Azure and Azure Databricks
   - granted Azure RBAC over the platform scopes

2. **Agent VM managed identity**
   - used only to retrieve secrets from Key Vault at runtime
   - lets the pipeline fetch the deployment service principal credentials without storing them in Azure DevOps variable groups

That separation keeps Azure DevOps itself out of the secret-distribution path.
