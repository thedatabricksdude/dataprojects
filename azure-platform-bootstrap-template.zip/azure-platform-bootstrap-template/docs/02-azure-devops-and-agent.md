# Azure DevOps and self-hosted agent setup

## Why a self-hosted agent is required here

A Microsoft-hosted agent is convenient, but a private-link-only Databricks implementation needs the runner to have line-of-sight to private endpoints and the private DNS zones that resolve them.

Because of that, this design uses a self-hosted Linux VM inside an Azure VNet that is later linked and peered into the Databricks network path.

## Why the VM is created before peering

The VM can safely exist before the Databricks workspaces exist.

That matters because it lets you:
- register the self-hosted agent early
- run the `foundation` pipeline from that agent
- add the VNet peerings later, after the Databricks VNets exist

This is the key staging trick that avoids a bootstrap deadlock.

## What the agent VM does

The VM's cloud-init bootstrap script:
- signs in with the VM's managed identity
- reads the Azure DevOps PAT from Key Vault
- installs Terraform if needed
- downloads the Azure Pipelines agent package
- registers the VM into the configured Azure DevOps agent pool
- installs the agent as a service

## What Azure DevOps still needs manually

Azure DevOps is a separate control plane. You still need to create these items yourself:
- Azure DevOps organization
- Azure DevOps project
- two Git repos (one for shared Azure infra, one for Databricks)
- a self-hosted agent pool with the name expected by the VM bootstrap
- pipeline environments for approvals, if you want them

## Suggested manual bootstrap order

1. Create Azure DevOps organization.
2. Create project.
3. Create a self-hosted agent pool, for example `ado-self-hosted-dev`.
4. Create your repos.
5. Put the Azure DevOps PAT value into `platform-bootstrap.auto.tfvars` or add it to Key Vault before applying `platform_bootstrap`.
6. Apply `roots/platform_bootstrap`.
7. Wait for the VM to register into the pool.
8. Push the Databricks repo and run the `foundation` pipeline.
9. Apply `roots/agent_runtime`.
10. Run the Databricks account bootstrap and workspace-objects stages.

## Why the pipeline does not need an Azure service connection

The pipeline runs on the VM.
The VM has a managed identity.
That managed identity reads the deployment service principal client ID and client secret from Key Vault at job runtime.
Terraform then authenticates with those values.

That means Azure DevOps does not need to hold long-lived Azure credentials itself for this pattern.
