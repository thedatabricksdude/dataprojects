# deployment_identity

Reusable Microsoft Entra app registration + service principal + rotating client secret module.
