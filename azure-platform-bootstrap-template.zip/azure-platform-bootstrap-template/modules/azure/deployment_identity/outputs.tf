output "display_name" {
  value = azuread_application.this.display_name
}

output "application_id" {
  value = azuread_application.this.client_id
}

output "service_principal_object_id" {
  value = azuread_service_principal.this.object_id
}

output "client_secret" {
  value     = azuread_application_password.this.value
  sensitive = true
}
