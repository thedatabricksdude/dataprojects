variable "display_name" {
  type = string
}

variable "password_rotation_days" {
  description = "Rotate the generated application password on this interval."
  type        = number
  default     = 180
}
