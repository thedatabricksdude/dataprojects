resource "azuread_application" "this" {
  display_name = var.display_name
}

resource "azuread_service_principal" "this" {
  client_id = azuread_application.this.client_id
}

resource "time_rotating" "password_rotation" {
  rotation_days = var.password_rotation_days
}

resource "azuread_application_password" "this" {
  application_id = azuread_application.this.id
  display_name   = "terraform"

  rotate_when_changed = {
    rotation = time_rotating.password_rotation.id
  }
}
