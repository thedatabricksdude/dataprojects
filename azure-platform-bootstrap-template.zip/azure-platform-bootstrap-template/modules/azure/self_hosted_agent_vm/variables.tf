variable "name" {
  type = string
}

variable "location" {
  type = string
}

variable "resource_group_name" {
  type = string
}

variable "subnet_id" {
  type = string
}

variable "admin_username" {
  type    = string
  default = "azureuser"
}

variable "ssh_public_key" {
  type = string
}

variable "size" {
  type    = string
  default = "Standard_B2s"
}

variable "enable_public_ip" {
  type    = bool
  default = true
}

variable "allowed_ssh_cidrs" {
  type    = list(string)
  default = []
}

variable "key_vault_id" {
  type = string
}

variable "key_vault_name" {
  type = string
}

variable "ado_org_url" {
  type = string
}

variable "ado_agent_pool" {
  type = string
}

variable "ado_pat_secret_name" {
  type = string
}

variable "terraform_version" {
  type    = string
  default = "1.9.8"
}

variable "agent_name" {
  type    = string
  default = null
}

variable "tags" {
  type    = map(string)
  default = {}
}
