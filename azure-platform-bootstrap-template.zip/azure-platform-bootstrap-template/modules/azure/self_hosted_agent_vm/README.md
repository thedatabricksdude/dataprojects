# self_hosted_agent_vm

Reusable Linux VM module that bootstraps a self-hosted Azure DevOps agent using a Key Vault-stored PAT.
