# state_backend

Use this root once, locally, to create the Terraform backend that later roots will use.

This root intentionally uses local state for the first apply.
