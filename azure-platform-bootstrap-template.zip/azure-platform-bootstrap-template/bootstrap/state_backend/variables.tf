variable "subscription_id" {
  description = "Optional subscription ID. Leave null to use the current Azure CLI context."
  type        = string
  default     = null
}

variable "location" {
  description = "Azure region for the state backend."
  type        = string
}

variable "resource_group_name" {
  description = "Resource group that will host the Terraform state storage account."
  type        = string
}

variable "storage_account_name" {
  description = "Globally unique storage account name for Terraform state."
  type        = string
}

variable "container_names" {
  description = "Blob containers to create for separate Terraform states."
  type        = set(string)
}

variable "allow_public_network_access" {
  description = "Whether the state storage account should allow public network access. Dev/test often needs this during bootstrap."
  type        = bool
  default     = true
}

variable "tags" {
  description = "Common tags."
  type        = map(string)
  default     = {}
}
