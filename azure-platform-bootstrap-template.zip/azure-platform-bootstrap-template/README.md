# Azure platform bootstrap template

This repository is the **shared Azure-side companion** to the Databricks platform repository.

It exists to solve the bootstrapping problems that show up in a real private-link Azure Databricks rollout:

- Terraform state must exist before remote-state roots can be used.
- A deployment identity must exist before pipelines can run unattended.
- A self-hosted Azure DevOps agent must exist **inside Azure networking** before it can reach private-link-only Databricks workspaces.
- The agent VNet cannot be peered to Databricks VNets until those VNets exist.

That leads to a staged design:

1. `bootstrap/state_backend` creates the Terraform state resource group, storage account, and containers. Run this **locally** the first time.
2. `roots/platform_bootstrap` creates the shared resource groups, Key Vault, Microsoft Entra app registration / service principal, role assignments, the agent VNet, and the **self-hosted Azure DevOps agent VM**. Run this **locally** the first time.
3. The Databricks repository's `roots/foundation` creates the private-link Databricks platform. This can now be run from the self-hosted agent because the VM already exists.
4. `roots/agent_runtime` adds peerings from the agent VNet to the Databricks hub/spoke VNets and links the agent VNet to the Databricks private DNS zones.
5. After that, Azure DevOps pipelines can take over normal foundation and workspace-object plan/apply operations.

## Why this repo is separate

The core operating model remains:

- **Azure infrastructure** and workspace creation live in one Terraform project.
- **Databricks account / workspace objects** live in another Terraform project.
- Remote state passes identifiers across roots instead of tightly coupling them in one state file.

This repo owns the Azure-side prerequisites and shared platform services. The Databricks repo owns workspace creation and Databricks objects.

## Repository layout

- `bootstrap/state_backend`: one-time local bootstrap for the remote-state backend.
- `roots/platform_bootstrap`: shared Azure prerequisites that the Databricks repo depends on, including the self-hosted agent VM.
- `roots/agent_runtime`: post-foundation networking between the agent network and Databricks networks.
- `modules/azure/deployment_identity`: reusable Entra app registration and service principal module.
- `modules/azure/self_hosted_agent_vm`: reusable Linux VM module that installs and registers an Azure DevOps agent.
- `environments/<env>`: example backend files and tfvars.
- `docs`: step-by-step explanation and gotchas.

## First-time deployment order

1. Create an Azure subscription suitable for testing.
2. Run `bootstrap/state_backend` locally.
3. Copy the example backend and tfvars files under `environments/dev` and fill in real values.
4. Run `roots/platform_bootstrap` locally. This creates the service principal, Key Vault, and self-hosted agent VM.
5. Push both repos into Azure DevOps.
6. Run the Databricks repository's `foundation` pipeline on the self-hosted agent.
7. Run `roots/agent_runtime` to add the peerings and private DNS links from the agent network into the newly created Databricks networks.
8. Run the Databricks repository's `account_bootstrap` root once, then run the `workspace_objects` pipeline.

## What this repo intentionally does not do

- It does **not** create Azure DevOps organizations for you. Azure DevOps org creation is still a manual sign-up step.
- It does **not** create your Databricks workspaces. That belongs to the Databricks repository.
- It does **not** automatically register the Azure deployment service principal inside the Databricks account. The Databricks repository contains a one-time helper root for that bootstrap step.
