resource_group_name  = "rg-dbxlab-tfstate-dev"
storage_account_name = "stdbxlabtfdev001"
container_name       = "agent-runtime"
key                  = "dev/agent-runtime.tfstate"
use_azuread_auth     = true
