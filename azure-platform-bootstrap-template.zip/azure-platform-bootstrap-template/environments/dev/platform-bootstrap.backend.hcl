resource_group_name  = "rg-dbxlab-tfstate-dev"
storage_account_name = "stdbxlabtfdev001"
container_name       = "platform-bootstrap"
key                  = "dev/platform-bootstrap.tfstate"
use_azuread_auth     = true
