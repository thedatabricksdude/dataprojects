location    = "westus2"
environment = "dev"

platform_bootstrap_remote_state = {
  resource_group_name  = "rg-dbxlab-tfstate-dev"
  storage_account_name = "stdbxlabtfdev001"
  container_name       = "platform-bootstrap"
  key                  = "dev/platform-bootstrap.tfstate"
}

databricks_foundation_remote_state = {
  resource_group_name  = "rg-dbxlab-tfstate-dev"
  storage_account_name = "stdbxlabtfdev001"
  container_name       = "databricks-foundation"
  key                  = "dev/foundation.tfstate"
}

create_spoke_peerings = true

tags = {
  environment = "dev"
  owner       = "your-name"
  cost_center = "sandbox"
}
