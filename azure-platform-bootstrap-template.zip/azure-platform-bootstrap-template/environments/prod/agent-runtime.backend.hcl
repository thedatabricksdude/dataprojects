resource_group_name  = "rg-dbxlab-tfstate-prod"
storage_account_name = "stdbxlabtfprod001"
container_name       = "agent-runtime"
key                  = "prod/agent-runtime.tfstate"
use_azuread_auth     = true
