location            = "westus2"
resource_group_name = "rg-dbxlab-tfstate-prod"
storage_account_name = "stdbxlabtfprod001"
container_names = [
  "platform-bootstrap",
  "agent-runtime",
  "databricks-foundation",
  "databricks-workspace-objects",
  "databricks-account-bootstrap",
]
allow_public_network_access = true

tags = {
  environment = "prod"
  owner       = "your-name"
  cost_center = "prod"
}
