resource_group_name  = "rg-dbxlab-tfstate-prod"
storage_account_name = "stdbxlabtfprod001"
container_name       = "platform-bootstrap"
key                  = "prod/platform-bootstrap.tfstate"
use_azuread_auth     = true
