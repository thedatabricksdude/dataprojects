location    = "westus2"
environment = "prod"

platform_bootstrap_remote_state = {
  resource_group_name  = "rg-dbxlab-tfstate-prod"
  storage_account_name = "stdbxlabtfprod001"
  container_name       = "platform-bootstrap"
  key                  = "prod/platform-bootstrap.tfstate"
}

databricks_foundation_remote_state = {
  resource_group_name  = "rg-dbxlab-tfstate-prod"
  storage_account_name = "stdbxlabtfprod001"
  container_name       = "databricks-foundation"
  key                  = "prod/foundation.tfstate"
}

create_spoke_peerings = true

tags = {
  environment = "prod"
  owner       = "your-name"
  cost_center = "sandbox"
}
