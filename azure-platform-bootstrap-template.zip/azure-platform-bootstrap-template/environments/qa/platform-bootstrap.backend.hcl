resource_group_name  = "rg-dbxlab-tfstate-qa"
storage_account_name = "stdbxlabtfqa001"
container_name       = "platform-bootstrap"
key                  = "qa/platform-bootstrap.tfstate"
use_azuread_auth     = true
