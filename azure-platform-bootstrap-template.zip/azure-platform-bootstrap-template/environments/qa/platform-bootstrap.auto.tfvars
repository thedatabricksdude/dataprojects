platform_name = "dbxlab"
environment   = "qa"
location      = "westus2"

state_backend = {
  resource_group_name  = "rg-dbxlab-tfstate-qa"
  storage_account_name = "stdbxlabtfqa001"
}

resource_groups = {
  shared_services = "rg-dbxlab-shared-qa"
  hub_network     = "rg-dbxlab-hub-qa"
  web_auth        = "rg-dbxlab-webauth-qa"
  agent           = "rg-dbxlab-agent-qa"
  workspaces = {
    analytics = "rg-dbxlab-analytics-qa"
  }
}

key_vault = {
  name                          = "kv-dbxlab-qa"
  sku_name                      = "standard"
  public_network_access_enabled = true
  purge_protection_enabled      = true
}

deployment_identity = {
  display_name           = "spn-dbxlab-qa-terraform"
  password_rotation_days = 180
}

agent_network = {
  vnet_name         = "vnet-dbxlab-agent-qa"
  address_space     = ["10.10.0.0/24"]
  subnet_name       = "snet-ado-agent"
  subnet_prefixes   = ["10.10.0.0/26"]
  allowed_ssh_cidrs = ["203.0.113.10/32"]
}

self_hosted_agent = {
  name                 = "vm-ado-agent-qa"
  admin_username       = "azureuser"
  ssh_public_key       = "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQ...replace-me"
  size                 = "Standard_B2s"
  enable_public_ip     = true
  ado_org_url          = "https://dev.azure.com/your-org"
  ado_agent_pool       = "ado-self-hosted-qa"
  ado_pat_secret_name  = "azure-devops-agent-pat"
  ado_pat_secret_value = "replace-with-a-real-azure-devops-pat"
  terraform_version    = "1.9.8"
}

key_vault_secret_names = {
  arm_client_id          = "arm-client-id"
  arm_client_secret      = "arm-client-secret"
  arm_tenant_id          = "arm-tenant-id"
  arm_subscription_id    = "arm-subscription-id"
  databricks_account_id  = "databricks-account-id"
  azure_devops_agent_pat = "azure-devops-agent-pat"
}

databricks_account_id = null

tags = {
  environment = "qa"
  owner       = "your-name"
  cost_center = "sandbox"
}
