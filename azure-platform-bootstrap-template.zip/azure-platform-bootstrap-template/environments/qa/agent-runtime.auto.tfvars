location    = "westus2"
environment = "qa"

platform_bootstrap_remote_state = {
  resource_group_name  = "rg-dbxlab-tfstate-qa"
  storage_account_name = "stdbxlabtfqa001"
  container_name       = "platform-bootstrap"
  key                  = "qa/platform-bootstrap.tfstate"
}

databricks_foundation_remote_state = {
  resource_group_name  = "rg-dbxlab-tfstate-qa"
  storage_account_name = "stdbxlabtfqa001"
  container_name       = "databricks-foundation"
  key                  = "qa/foundation.tfstate"
}

create_spoke_peerings = true

tags = {
  environment = "qa"
  owner       = "your-name"
  cost_center = "sandbox"
}
