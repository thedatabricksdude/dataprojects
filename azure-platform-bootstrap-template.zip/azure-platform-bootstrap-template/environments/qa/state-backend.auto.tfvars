location            = "westus2"
resource_group_name = "rg-dbxlab-tfstate-qa"
storage_account_name = "stdbxlabtfqa001"
container_names = [
  "platform-bootstrap",
  "agent-runtime",
  "databricks-foundation",
  "databricks-workspace-objects",
  "databricks-account-bootstrap",
]
allow_public_network_access = true

tags = {
  environment = "qa"
  owner       = "your-name"
  cost_center = "qa"
}
