resource_group_name  = "rg-dbxlab-tfstate-qa"
storage_account_name = "stdbxlabtfqa001"
container_name       = "agent-runtime"
key                  = "qa/agent-runtime.tfstate"
use_azuread_auth     = true
