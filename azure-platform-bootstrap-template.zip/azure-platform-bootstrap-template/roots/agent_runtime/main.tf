resource "azurerm_private_dns_zone_virtual_network_link" "agent" {
  for_each = local.private_dns_zone_ids

  name                  = "link-${local.agent_network.vnet_name}-${each.key}"
  resource_group_name   = split("/", each.value)[4]
  private_dns_zone_name = split("/", each.value)[8]
  virtual_network_id    = local.agent_network.vnet_id
}

resource "azurerm_virtual_network_peering" "agent_to_hub" {
  name                      = "peer-${local.agent_network.vnet_name}-to-${local.hub_network.vnet_name}"
  resource_group_name       = local.agent_network.resource_group_name
  virtual_network_name      = local.agent_network.vnet_name
  remote_virtual_network_id = local.hub_network.vnet_id

  allow_virtual_network_access = true
  allow_forwarded_traffic      = true
}

resource "azurerm_virtual_network_peering" "hub_to_agent" {
  name                      = "peer-${local.hub_network.vnet_name}-to-${local.agent_network.vnet_name}"
  resource_group_name       = split("/", local.hub_network.vnet_id)[4]
  virtual_network_name      = local.hub_network.vnet_name
  remote_virtual_network_id = local.agent_network.vnet_id

  allow_virtual_network_access = true
  allow_forwarded_traffic      = true
}

resource "azurerm_virtual_network_peering" "agent_to_spokes" {
  for_each = var.create_spoke_peerings ? local.landing_zones : {}

  name                      = "peer-${local.agent_network.vnet_name}-to-${basename(each.value.vnet_id)}"
  resource_group_name       = local.agent_network.resource_group_name
  virtual_network_name      = local.agent_network.vnet_name
  remote_virtual_network_id = each.value.vnet_id

  allow_virtual_network_access = true
  allow_forwarded_traffic      = true
}

resource "azurerm_virtual_network_peering" "spokes_to_agent" {
  for_each = var.create_spoke_peerings ? local.landing_zones : {}

  name                      = "peer-${basename(each.value.vnet_id)}-to-${local.agent_network.vnet_name}"
  resource_group_name       = each.value.resource_group_name
  virtual_network_name      = basename(each.value.vnet_id)
  remote_virtual_network_id = local.agent_network.vnet_id

  allow_virtual_network_access = true
  allow_forwarded_traffic      = true
}
