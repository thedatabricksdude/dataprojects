locals {
  platform_state   = data.terraform_remote_state.platform_bootstrap.outputs
  foundation_state = data.terraform_remote_state.databricks_foundation.outputs

  agent_network = local.platform_state.agent_network
  key_vault     = local.platform_state.key_vault
  hub_network   = local.foundation_state.hub_network
  landing_zones = local.foundation_state.landing_zones
  private_dns_zone_ids = local.foundation_state.private_dns_zone_ids

  common_tags = merge(var.tags, {
    environment = var.environment
    managed_by  = "terraform"
    workload    = "azure-devops-agent"
  })
}
