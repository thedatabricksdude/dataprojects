variable "subscription_id" {
  description = "Optional subscription ID. Leave null to use the current Azure CLI context."
  type        = string
  default     = null
}

variable "location" {
  type = string
}

variable "environment" {
  type = string
}

variable "platform_bootstrap_remote_state" {
  description = "Remote state location for this repo's platform_bootstrap root."
  type = object({
    resource_group_name  = string
    storage_account_name = string
    container_name       = string
    key                  = string
  })
}

variable "databricks_foundation_remote_state" {
  description = "Remote state location for the Databricks repo foundation root."
  type = object({
    resource_group_name  = string
    storage_account_name = string
    container_name       = string
    key                  = string
  })
}

variable "create_spoke_peerings" {
  description = "Whether to create direct peerings between the agent VNet and each Databricks workspace VNet."
  type        = bool
  default     = true
}

variable "tags" {
  type    = map(string)
  default = {}
}
