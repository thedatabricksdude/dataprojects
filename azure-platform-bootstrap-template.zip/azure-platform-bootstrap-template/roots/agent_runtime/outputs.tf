output "agent_vnet" {
  value = local.agent_network
}

output "hub_vnet_peering" {
  value = {
    agent_to_hub = azurerm_virtual_network_peering.agent_to_hub.id
    hub_to_agent = azurerm_virtual_network_peering.hub_to_agent.id
  }
}

output "spoke_peerings" {
  value = {
    agent_to_spokes = { for k, v in azurerm_virtual_network_peering.agent_to_spokes : k => v.id }
    spokes_to_agent = { for k, v in azurerm_virtual_network_peering.spokes_to_agent : k => v.id }
  }
}

output "private_dns_links" {
  value = { for k, v in azurerm_private_dns_zone_virtual_network_link.agent : k => v.id }
}
