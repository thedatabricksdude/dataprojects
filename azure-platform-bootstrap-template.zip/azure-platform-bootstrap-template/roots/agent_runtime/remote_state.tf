data "terraform_remote_state" "platform_bootstrap" {
  backend = "azurerm"

  config = {
    resource_group_name  = var.platform_bootstrap_remote_state.resource_group_name
    storage_account_name = var.platform_bootstrap_remote_state.storage_account_name
    container_name       = var.platform_bootstrap_remote_state.container_name
    key                  = var.platform_bootstrap_remote_state.key
    use_azuread_auth     = true
  }
}

data "terraform_remote_state" "databricks_foundation" {
  backend = "azurerm"

  config = {
    resource_group_name  = var.databricks_foundation_remote_state.resource_group_name
    storage_account_name = var.databricks_foundation_remote_state.storage_account_name
    container_name       = var.databricks_foundation_remote_state.container_name
    key                  = var.databricks_foundation_remote_state.key
    use_azuread_auth     = true
  }
}
