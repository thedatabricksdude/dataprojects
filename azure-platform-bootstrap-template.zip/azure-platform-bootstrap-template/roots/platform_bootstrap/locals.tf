locals {
  effective_subscription_id = coalesce(var.subscription_id, data.azurerm_subscription.current.subscription_id)
  effective_tenant_id       = coalesce(var.tenant_id, data.azurerm_client_config.current.tenant_id)

  common_tags = merge(var.tags, {
    platform    = var.platform_name
    environment = var.environment
    managed_by  = "terraform"
    repository  = "azure-platform-bootstrap-template"
  })

  resource_group_names = merge(
    {
      shared_services = var.resource_groups.shared_services
      hub_network     = var.resource_groups.hub_network
      web_auth        = var.resource_groups.web_auth
      agent           = var.resource_groups.agent
    },
    { for key, value in var.resource_groups.workspaces : "workspace_${key}" => value }
  )
}
