data "azurerm_client_config" "current" {}

data "azurerm_subscription" "current" {}

data "azurerm_storage_account" "state" {
  name                = var.state_backend.storage_account_name
  resource_group_name = var.state_backend.resource_group_name
}
